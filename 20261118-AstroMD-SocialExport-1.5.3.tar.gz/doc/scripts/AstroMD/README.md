# AstroMD Social Export

Version 1.5.3 for PixInsight 1.8.9 and later, including 1.9.x.

Copyright (c) 2026 Astrophotography MD LLC. All rights reserved.

AstroMD Social Export turns a finished astrophotograph into social media files in one step. You pick the platforms, drag a crop box for each one, and click Export. Each file is cropped, resized to the platform's exact pixels, optionally sharpened, converted to sRGB, and saved as a JPEG at the highest quality that still fits the file size target you set. Carousel mode makes a numbered set of matching slides for Instagram, TikTok, Facebook, Threads, X, or a custom target, including a seamless panorama or a 2x2 or 3x3 grid split across slides.

One script covers both the free version and the full version. Without a license you can export unlimited Instagram files, with a small AstroMD Social Export credit on each one. A license key unlocks every platform, custom presets, saved jobs, your own watermark, exporting several open images at once, carousel export, a full frame size target, and logo-only export.

## Files

| File | What it is |
| --- | --- |
| `AstroMD-SocialExport.js` | The script. This is the only file PixInsight needs. |
| `README.md` | This guide. |
| `TESTING.md` | Step by step test checklist. |
| `tools/strip-preprocessor.js` | Developer tool: removes `#include` style lines so Node.js can syntax check the script. |
| `tools/test-logic.js` | Developer tool: offline tests of file naming, crop math, carousel panorama and grid geometry, platform slide limits, crop max-fit, detail overlap, slide numbering, the Don't-upscale hint, watermark positions, logo format notes, license keys, single-export batch plans, JPEG quality limits, and the size-fit scale search. Run with `node tools/test-logic.js`. |
| `tools/test-dialog.js` | Developer tool: runs the dialog, both export paths, and the single-export Images list against a mock PixInsight to catch script errors. Run with `node tools/test-dialog.js`. |
| `tools/check-pjsr-pitfalls.py` | Developer tool: flags code PixInsight's preprocessor misreads, and property reads that PJSR warns about if the property is missing. |
| `tools/keygen.js` | Developer tool: issues a license key from a buyer email. It is not included in the customer zip or the update package. |
| `tools/build-repo.js` | Developer tool: builds the PixInsight update repository folder (updates.xri plus a dated package). |

The `tools` folder is not needed inside PixInsight and does not need to ship to customers.

## Install

1. Copy the `AstroMD-SocialExport` folder anywhere on your computer, for example `Documents/PixInsight Scripts/AstroMD-SocialExport`.
2. In PixInsight, open **Script > Feature Scripts...**
3. Click **Add**, choose the `AstroMD-SocialExport` folder, then click **Done**.
4. The script now appears under **Script > Astrophotography MD > Social Export**.

To run it once without installing, use **Script > Execute Script File...** and pick `AstroMD-SocialExport.js`.

To update to a new version by hand, replace the `.js` file in the same folder. If the menu entry does not appear or looks out of date, open **Script > Feature Scripts...** again and click **Regenerate**. The recommended way to get updates is to add the update repository, described below.

## Free version and full version

| Feature | Free | Full (license key) |
| --- | --- | --- |
| Single exports | Unlimited | Unlimited |
| Platforms | Instagram presets only. Other targets are visible but locked, with an "Unlock with a license" note. | All built-in platforms, plus custom presets |
| Watermark | A small "AstroMD Social Export" credit is added at the bottom right. It cannot be removed or changed. | Your own text or logo, any position |
| Several open images in Single exports | The current image only. Other open images are listed and marked "Unlock with a license." | Check any open images. Each keeps its own crop and base name. One Export writes every checked image for every checked target |
| Carousel, panorama, grid, and detail slides | You can preview and arrange them | Preview and export |
| Sharpening and file size control | Yes. Preset pixel size is kept. JPEG quality starts at 90 to 100 (default 95) and can drop to 75. The image is resized only if quality 75 is still over the target. | Yes |
| Full frame, fit to file size | The choice is visible but disabled, with "Requires a license key." | Whole image, no crop. Target (MB) and Priority sit next to the choice. Highest quality holds 90 to 100 and shrinks to fit. Largest size keeps pixels, drops quality to 75, then shrinks at 75 if needed |
| Add logo only | The choice is visible but disabled, with "Requires a license key." | Watermark or logo only. No crop and no sharpening. Original size (Same as source, JPEG, or PNG) or fit to a file size with Priority. Same as source is the default and keeps the file type and bit depth. JPEG quality sits with those controls |
| Saved jobs | Locked, same as custom presets | Save the current mode and its settings under a name, then load, update, rename, or delete it |

### Enter a license key

1. Click **Enter license key** at the bottom of the window.
2. Type the email address you used when you bought the script, and the key from your receipt (it looks like `ASMD-XXXX-XXXX-XXXX-XXXX`).
3. Click **Unlock**. The banner at the top of the right column should read "Licensed to" followed by your email.
4. **Remove license** takes this computer back to the free version. Your saved crops and other settings stay.

The key is checked on your computer. You do not need to be online. Use the same email that appears on the order, including typographic differences only in capitalization or spaces; those are ignored.

### Add the update repository

This is the way PixInsight is meant to keep scripts up to date.

1. In PixInsight, open **Resources > Updates > Manage Repositories** (the exact menu wording can vary slightly by version).
2. Click **Add** and enter:

   `https://updates.astrophotographymd.com/`

3. Click **OK**, then run **Resources > Updates > Check for Updates**. When an update is offered, install it and restart PixInsight if you are asked to.

The repository URL must have no redirect. After you add it once, PixInsight will check for new versions on startup.


## Usage

At the top of the window, above the preview and the target list, **What do you want to do?** picks the export. A line under the choices describes the one you picked. The last mode you used comes back the next time you open the script.

* **Social media export** is the usual crop-to-a-platform workflow, including Single exports and Carousel. JPEG quality stays in **Processing**.
* **Full frame, fit to file size** (license required) exports the whole image with no crop. **Target (MB)**, **Priority**, and **JPEG quality** appear on the next line. **Highest quality** (the default) holds that JPEG quality and shrinks the pixel size just enough to fit. **Largest size** keeps the original pixel size and lowers quality to fit, down to 75. If quality 75 is still over, it resizes just enough at quality 75. The console reports the final dimensions, quality, and file size. The target list and the crop box are hidden. One JPEG is written per checked image. Output sharpening still applies if you open **Processing** and check it.
* **Add logo only** (license required) adds a watermark or logo and nothing else. No crop, no sharpening, and no preset resize. **Watermark / signature** opens for you. On the next lines, choose **Original size** or **Fit to file size**. **Format** is **Same as source** (the default), **JPEG**, or **PNG**. Same as source writes the same kind of file as the image you opened (TIFF, PNG, JPEG, XISF, or FITS), at the original pixel size and bit depth, with the ICC profile and FITS keywords when that format can store them. It does not convert to 8-bit sRGB. The file name is the base name plus `_logo`, and the original file is never overwritten. An image that has not been saved is written as 16-bit TIFF, and the script says so. Choose JPEG or PNG in **Format** if you want one of those instead. A JPEG keeps the original pixel size and can drop quality to 75, and is resized only if quality 75 is still over. PNG stays at the original pixel size. Fit to file size saves a JPEG and uses **Target (MB)** and **Priority**, the same two choices as full frame. Format shows JPEG while that option is selected. JPEG and PNG at the original size are still converted to 8-bit sRGB.

In the free version the full frame and logo choices are visible but disabled, with the note **Requires a license key.** Social media export works as before.

**Jobs**, on the next row, saves the current mode and the settings that go with it: platform checks, size target, priority, quality, logo file, position, size, opacity, sharpening, output folder, file name template, and format. The watermark margin is not a separate setting. It stays a small automatic inset (about 2.5 percent of the short edge). Pick a job and click **Load**, or **Save as...**, **Update**, **Delete**, and **Rename**. Saved jobs need a license, the same rule as custom presets. They are stored with your other PixInsight settings and come back next time.

1. Open your finished image. It should be stretched (nonlinear), color calibrated and fully processed. The preview shows the real pixel values without a screen stretch, so a linear image will look black. The script warns you if the image looks linear.
2. Run **Script > Astrophotography MD > Social Export**.
3. With **Social media export** selected, in **Targets**, check every platform you want. Click a target's name to show its crop box in the preview. In the free version, only Instagram targets can be checked.
4. In **Images** (Single exports only, licensed for more than the current image), check every open image you want to include. The current image is checked by default. Click an image to preview it and edit its crop and base name. Each image keeps its own crop per target. Other images show "Unlock with a license" until you enter a key. `{name}` uses that image's base name (edit the Base name column, or the Output field for the selected image). Unvisited images keep their file name or window id. Export writes every checked image for every checked target, and the status line reads like "Image 2 of 3, preset 4 of 7". The watermark applies to all of them.
5. Position the crop box:
   * Drag inside the box to move it.
   * Drag a corner handle to resize it.
   * Use the mouse wheel to grow or shrink it. Hold Shift for fine steps.
   * Click outside the box to center it on that spot.
   * **Center** centers the box, **Max size** makes it as large as possible, **Reset** goes back to the largest centered box, and **Same center for all** moves every target's box to this one's center.
   * The aspect ratio always stays locked to the target. Each target remembers its own crop while the dialog is open.
   * The line under the preview shows the crop size in source pixels and the scale. If the crop is smaller than the output, a hint under **Don't upscale small crops** explains whether the file will stay at the crop's real size or be enlarged.
6. In **Output**, check the folder, base name and name template:
   * The folder defaults to a `Social` subfolder next to your image. **Browse...**, **Image folder** and **Social subfolder** change it. The folder is created if it does not exist.
   * **Base name** applies to the selected image in the Images list. It defaults to that image's file name or window id. Each image has its own base name, used for `{name}` when that image is exported.
   * The default template is `{name}_{platform}_{w}x{h}_{date}.jpg`, which gives names like `FishHead_Instagram-Portrait_1080x1350_2026-11-15.jpg`. Available tokens: `{name}`, `{platform}`, `{preset}`, `{w}`, `{h}`, `{date}` (YYYY-MM-DD), `{time}` (HHMMSS) and `{kb}` (target KB). The `.jpg` or `.png` extension is set automatically from each target's format. The **Example** line shows the result live.
   * **Subfolder per image** puts each image's files in their own folder named after the base name.
   * Existing files are never overwritten unless you check **Overwrite existing files**. Otherwise `_2`, `_3` and so on are added.
7. In **Processing**:
   * **Resampling**: Auto (recommended) uses the Mitchell-Netravali filter for reductions, because it filters out fine detail that would otherwise alias into jagged stars, and clamped Lanczos-3 for enlargements.
   * **Apply output sharpening**: off by default. Nothing is sharpened unless you check this box.
   * **Sharpening**: strength from 0 to 1, used only when the box above is checked. 0.25 is gentle, 0.5 is moderate, and 1.0 is strong. The actual UnsharpMask settings scale with how much the image is reduced. Sharpening works on luminance only and uses deringing to avoid dark halos around stars. Each preset can turn sharpening off.
   * **Don't upscale small crops (recommended)**: on by default for first-time use. If a crop is smaller than the target, the file is saved at the crop's real size, which stays sharper and is usually a smaller file. The platform may stretch it slightly when it displays the image. Uncheck it to enlarge the crop to the exact platform size, which can look soft. A hint under the box appears only when the crop is smaller than the output, and names the real export size. If you already saved a choice in an earlier version, that saved choice is kept (the old default was off).
   * **JPEG quality**: 95 by default, and the control only goes from 90 to 100. This is the starting quality for social presets and carousel slides. They search downward from it to 75 so they can keep their exact pixel size. If quality 75 is still over the target, the image is resized smaller (Mitchell-Netravali) and the Process Console says so. Full frame and Add logo only show this control next to their size target instead of here.
8. Optional **Watermark / signature**: check the group title to turn it on. Choose **Text** or **Logo image** (this used to be labeled PNG logo; your saved choice is unchanged). For a logo, a PNG with a transparent background at least 1000 px wide works best. JPEG, BMP, GIF, TIFF, XISF, and FITS also work; JPEG has no transparency, so the whole rectangle shows. SVG is not supported, so export it to PNG first. That list is also in the hover tip on the type menu, the logo path, and **Browse...**. **Browse...** lists those image types, plus All files. If the chosen file is a JPEG, an SVG, has no transparency, or is under 400 px wide, a note appears under the path. Then pick the position (any corner, Top center, Bottom center, Center, Left center, or Right center), the opacity, and the size as a percent of the image's short edge.
9. Click **Export**. The Process Console shows each step, each JPEG quality tried, and a final line with dimensions, quality, and file size. A preset that had to shrink says that quality 75 was still over the target. To stop, use the Process Console's abort button.

Your settings, custom presets, saved jobs, and checked targets are saved and come back the next time you run the script. The last export mode comes back too.

### Custom presets

* **Add...** creates a preset. Set a name, a file name tag (used for `{platform}`), either exact pixels or an aspect ratio plus long edge (for example `4:5` and `2000`, or `native` to keep the image's own shape), the maximum file size in MB (for example 2.4), JPEG or PNG, and whether to sharpen.
* **Edit...** changes a custom preset. Built-in presets can't be changed, but Edit offers to make an editable copy.
* **Delete** removes a custom preset. Built-in presets can only be unchecked.
* To change the built-in defaults for everyone (for example, for a new release), edit the `ASMD_BUILTIN_PRESETS` table near the top of the script.

### What happens to each file

For every checked target, the script:

1. Copies only the crop rectangle into a new hidden 32-bit image. Your original image is never modified.
2. Resizes it to the exact target pixels with the Resample process, unless **Don't upscale small crops** is checked and the crop is smaller than the target, in which case the file is saved at the crop's real size.
3. Applies output sharpening only if the Apply output sharpening box is checked and the preset allows it.
4. Converts to sRGB with ICCProfileTransformation (color images).
5. Draws the watermark, if any.
6. Converts to 8-bit and tags the file with the sRGB profile so it is embedded.
7. For JPEG: saves at the JPEG quality set in Processing (95 unless you changed it, from 90 to 100). If that file is at or under the target, it is kept at the pixel size from the steps above. If it is over, quality is searched downward to 75 and the highest quality that fits is kept, still at that pixel size. If quality 75 is still over, the image is resized just enough at quality 75. The Process Console names the final size, quality, and file size, and says when a resize was required. If even the smallest size it will try is still over, the file is saved and flagged OVER. Temporary files are written next to the final file and deleted at the end.
8. For PNG: saves once at the pixel size from the steps above and flags the file if it is over the target. PNG is not resized to chase the target.

Sizes are shown in MB in the dialog and the Process Console (2.4 MB = 2400 KB). The script counts 1 KB as 1024 bytes, so Windows Explorer may show a file a few percent larger in KB than the MB figure suggests, and the file is always at or under the target.

## Carousel mode

Choose **Carousel** at the top of the right side of the window (next to **Single exports**) to build a numbered set of slides. The Targets list is replaced by the Carousel panel, but your checked single-export targets are kept and come back when you return to **Single exports**. They are also saved when you switch modes or close the window. Output folder, base name, processing, and watermark settings below the panel are shared with single exports. The window opens large enough to show that column without scrolling when your screen allows, up to about 95% of the screen. If the settings are still taller than that, the column scrolls. On Windows, the mouse wheel scrolls it when the pointer is over a label, a section bar, or a group box. The Images list, dropdowns, number boxes, text fields, and the preview keep their own wheel. The Export, Close, Open folder, and license buttons, and the preview's Center, Max size, and Reset buttons, stay visible at the bottom. The Processing section starts collapsed (click its bar to open it). The Watermark / signature section starts open. Both states are saved between runs. **Don't upscale small crops** does not shrink carousel slides: every slide stays at the platform size so the set matches. The hint under the box says so when a crop is smaller than the output.

### Platform

**Platform** is the first control in the Carousel panel. It sets the allowed slide shapes, the default shape, the slide limit, and the suggested file size. Checked November 15, 2026.

| Platform | Slide limit | Default shape | Target size | Swipe? | Source |
| --- | --- | --- | --- | --- | --- |
| Instagram (default) | 20 | 4:5, 1080 x 1350 | 1.6 MB | Yes | Official: Instagram Help Center, up to 20 photos or videos [15]. App aspect range 1.91:1 to 3:4 [1]. API/schedulers 4:5 to 1.91:1, 8 MB, JPEG [see Instagram API docs]. 3:4 is app only. |
| TikTok | 35 | 9:16, 1080 x 1920 | 2.4 MB | Yes | Official: Content Posting API, up to 35 photo URLs, JPEG or WebP, maximum 1080p, 20 MB each [13]. 1080 x 1920 is common practice, not an official pixel size [14]. |
| Facebook | 20 (script cap) | 1:1, 1080 x 1080 | 1.5 MB | No | Official: albums allow 1,000 photos [16]. Facebook does not publish a cap for photos in one regular post, so the script caps an export at 20. Facebook shows several photos as a collage, not a swipeable carousel, so panorama and grid seams will not line up as a swipe. |
| Threads | 20 | 3:4, 1440 x 1920 | 4 MB | Yes | Official: Threads API, updated October 30, 2026, up to 20 images or videos, width 320 to 1440, 8 MB, JPEG or PNG [17]. Slides are exported 1440 px wide. |
| X | 4 | 4:5, 1080 x 1350 | 3 MB | No | Official long-standing cap is 4 photos per post, 5 MB, and a single photo between 2:1 and 3:4 shows in full [9][10]. News reports on November 12, 2026 said X raised the cap to 20 [18], but that could not be confirmed on an official Help page (the Help page returned an error when checked), so the script stays at 4. A 3x3 grid (9 tiles) is refused. Multiple photos are arranged in a grid in the timeline, so panorama and grid seams may not swipe. |
| Custom | 35 | 4:5, 1080 x 1350 | 1.6 MB | Yes | No platform cap beyond 35. You choose the shape and size. |

The note under the platform is a short 2-3 line summary of the limit, including the Facebook collage warning and the X 4-slide cap. Hover the note to read the full text. If a layout would go over the limit (for example a 3x3 grid on X), the script refuses it and tells you why.

### Slide shape

Every slide in a carousel has the same shape and pixel size. The shape list depends on the platform. **Instagram uses the first slide's shape for the whole carousel** and crops the rest to match, so the script makes every slide the same size.

| Shape | Pixels (Instagram, TikTok, Facebook, X, Custom) | Notes |
| --- | --- | --- |
| 4:5 portrait | 1080 x 1350 | Instagram app and schedulers. The safest Instagram choice. |
| 3:4 portrait | 1080 x 1440 | Instagram app only. Scheduling tools reject it. On Threads this becomes 1440 x 1920. |
| 1:1 square | 1080 x 1080 | Instagram, Facebook. On Threads this becomes 1440 x 1440. |
| 9:16 full screen | 1080 x 1920 | TikTok photo carousels. Fills the phone screen. Not offered for Instagram, because Instagram crops 9:16 carousel slides. |
| Custom | any W x H | Anything else. Not scaled to 1440 on Threads, so you keep the pixels you type. |

**Max size (MB)** is the target for each slide. Changing the platform sets the suggested size in the table above. You can still type a different target. Slides keep the platform pixel size, so a set still matches. JPEG quality starts at the Processing setting and can drop to 75. A slide is resized only if quality 75 is still over the target. The console says so, and that slide may then differ in pixel size from the others.

The slide list stops at the platform's limit (20 for Instagram, Facebook, and Threads; 35 for TikTok and Custom; 4 for X).

### Layout

**Layout** chooses how the main crop is split into slides. A carousel can have one panorama or one grid, not both. You can still add detail slides and other images after it.

### Seamless panorama

The panorama turns one wide crop into slides that line up perfectly when someone swipes, so the nebula flows from one slide to the next.

1. Set **Layout** to **Panorama**, then set the number of slides (2 to 10). The crop box is locked to that many slides side by side, for example 3 slides of 4:5 make a 2.4:1 box.
2. Select the panorama in the slide list and drag, resize, or wheel the box in the preview like any other crop. Cyan lines show where the image will be cut, with slide numbers along the bottom.
3. On export, the whole crop is resized once to exactly N x 1080 pixels wide (for example 3240 x 1350 for 3 slides), sharpened once if sharpening is on, and then cut at exact 1080 pixel steps. Because the panels come from one image, there are no seams, gaps, or overlaps between slides.

If you drop the panel count, for example from 6 slides to 2, the crop box grows to the largest 2-panel size that still fits the image, centered where the old box was. You can still drag or resize it smaller after that. The same thing happens when you change the slide shape.

The panorama is added automatically the first time you switch to Carousel (if Layout is still set to Panorama). If you remove it, **Add panorama** puts it back at the start.

### 2x2 and 3x3 grid

A grid cuts one crop into 4 or 9 tiles in reading order (row by row, left to right), so a wide or tall object can be posted as a square of tiles that the viewer swipes through.

1. Set **Layout** to **2x2 grid** or **3x3 grid**. The crop box locks to the grid's overall shape, which is the slide shape repeated across the columns and rows. For any square grid, that overall shape matches the slide shape itself, so a 2x2 of 4:5 slides is still a 4:5 box, just cut into four tiles.
2. Cyan cut lines show both the rows and the columns, with tile numbers 1 to 4 or 1 to 9 in reading order. Each number sits at the bottom center of its tile on a dark patch, so the top-row numbers stay visible.
3. On export, the crop is resized once to (columns x slide width) by (rows x slide height), for example 2160 x 2700 for a 2x2 of 1080 x 1350 slides, or 3240 x 4050 for a 3x3, then cut into tiles at exact slide-sized steps.

The tiles count toward the platform's slide limit. A 3x3 grid (9 tiles) is refused on X, which is capped at 4 slides. If you remove the grid, **Add 2x2 grid** or **Add 3x3 grid** puts it back at the start.

### Detail slides

**Add detail** adds a zoom-in on the current image, for example the Fish Head core or a dust lane. Its box is locked to the slide shape and can be any size and anywhere on the image. Each detail is resized to the slide size. If a detail box is so small that it would be enlarged more than 2x, the line under the preview and the Process Console warn you that it may look soft.

When you have more than one detail on the same image, every detail box stays visible in the preview. The selected box is the bright orange one you can drag and resize. The others are drawn as dim cyan outlines with their slide numbers, so you can see where they already sit. If two detail boxes overlap, the intersection is tinted orange and the line under the preview says something like "Slides 3 and 5 overlap by 42%." The percent is of the smaller box. Overlap is allowed; the warning is only there so you do not do it by accident. The same outlines appear if you add more than one cropped slide from the same other open image.

### Other images

Open the other version in PixInsight before you start the script (for example the starless or RGB version). Pick it in **Other image**, then click **Add image**:

* With **Whole image** checked, the entire image is fitted inside the slide with black bars, so nothing is cut off.
* With it unchecked, the slide gets a crop box you position on that image. Selecting the slide switches the preview to that image.

### Slide list

The list shows each slide's number in swipe order, its type, and its source image. The panorama or grid takes one row but counts as N slides (for example 01-03 or 01-04).

* **Select** (or clicking a row) shows that slide's crop in the preview so you can edit it. **Center**, **Max size**, and **Reset** work on the selected slide.
* **Move up** and **Move down** change the swipe order. **Remove** deletes the selected slide.
* Detail and other image crops are kept while the window is open. They are not saved between runs.

### Watermark choices

**Watermark** picks which slides get the watermark: **None**, **First slide only** (the default), **Every slide**, or **Last slide only**. It uses the text or logo, position, opacity, and size from **Watermark / signature**, and only applies when that group is checked. On a grid, First slide only is the top left tile. If that looks odd on your image, try Every slide or Last slide only.

### File names

In Carousel mode the single-export Name template and its Example are hidden, because carousel files use their own File names field in the Carousel panel. The default is `{name}_Carousel_{slide}_{w}x{h}_{date}.jpg`, which gives `FishHead_Carousel_01_1080x1350_2026-11-15.jpg`, `FishHead_Carousel_02_1080x1350_2026-11-15.jpg`, and so on in swipe order. `{slide}` is the slide number with two digits, and is added automatically if your template leaves it out. `{count}` is the number of slides. `{platform}` is optional and becomes `Instagram`, `TikTok`, `Facebook`, `Threads`, `X`, or `Carousel` (for Custom), for example `{name}_{platform}_{slide}_{w}x{h}_{date}.jpg`. `{date}` and `{time}` are the same for every slide of one export. Files go to the same output folder, subfolder, and overwrite rules as single exports, and **Open folder** opens it afterward.

The Process Console shows each slide's steps and ends with the same summary table as single exports.

Carousel settings (platform, shape, custom size, layout, number of panorama slides, watermark choice, max size, and file name template) and the last mode you used are saved between runs. Checked single-export targets are saved when you switch to Carousel or close the window, and they are still there when you come back.

## Presets and sources

Sizes were checked against current platform help pages and 2026 size guides in November 2026. The **Max size** values are practical targets set by Astrophotography MD, well below each platform's hard upload limit. Every platform recompresses uploads, so the goal is to give it a clean, correctly sized file at high quality, not to hit the hard limit.

| Preset | Pixels | Max KB (shown in MB in the script) | Platform facts that set it |
| --- | --- | --- | --- |
| Instagram Portrait 4:5 (app + schedulers) | 1080 x 1350 | 1600 | Instagram keeps photos at their own resolution up to 1080 px wide when the aspect ratio is between 1.91:1 and 3:4 [1]. 4:5 is the tallest shape the Instagram publishing API accepts, so use this one for Meta Business Suite and other schedulers. |
| Instagram Portrait 3:4 (app only) | 1080 x 1440 | 1800 | 3:4 is the tallest shape the Instagram app keeps (1080 x 1440) [1]. Scheduling tools that use the API reject it, so post this from the app. Off by default. |
| Instagram Square 1:1 | 1080 x 1080 | 1300 | Same rules as above [1][2]. |
| Instagram Landscape 1.91:1 | 1080 x 566 | 800 | 1.91:1 is the widest ratio Instagram keeps without cropping (1080 x 566) [1]. |
| Instagram Story/Reel 9:16 | 1080 x 1920 | 2400 | Stories and Reels use 1080 x 1920 at 9:16 [2][4]. |
| TikTok Photo 9:16 | 1080 x 1920 | 2400 | TikTok's developer documentation for photo posts accepts JPEG or WebP images up to 1080p and 20 MB each, with up to 35 photos per post [13]. TikTok does not publish a recommended pixel size; 1080 x 1920 (9:16) is the common size that fills the phone screen [14]. Off by default. |
| Facebook Feed (2048 long edge) | image's own ratio, 2048 long edge | 1000 | Facebook recommends regular photos 720, 960 or 2048 px wide [6][7]. Facebook keeps a master capped at 2048 px on the long edge, so larger files gain nothing [8]. Facebook recommends uploads under 15 MB and PNGs under 1 MB [5]. The 1000 KB target follows the photographer rule of thumb that smaller, already well compressed files get recompressed less. Facebook does not publish an exact threshold, so treat it as a starting point. |
| Facebook Feed 4:5 | 1638 x 2048 | 1500 | 4:5 portrait is the standard Meta feed shape [4]. 2048 on the long edge matches the size Facebook is commonly observed to keep (a photographer rule of thumb, not an official Meta number). Off by default. |
| Facebook Cover 16:9 | 1920 x 1080 | 400 | Facebook's current Help Center says Page covers display at 16:9 on computers and 2.4:1 on phones, at least 400 x 150 (https://www.facebook.com/help/125379114252045). Keep the subject in the middle band, away from the left side (profile picture) and the top and bottom (cropped on phones). Facebook says covers load fastest under 100 KB, but that is a speed tip, not a limit, and star fields look poor that small. Off by default. |
| X/Twitter 16:9 | 1600 x 900 | 3000 | 1600 x 900 is the usual recommended single image size [10]. X photos can be up to 5 MB, and single photos between 2:1 and 3:4 display in full [9][10]. |
| X/Twitter 4:5 | 1600 x 2000 | 3000 | 4:5 is inside the 2:1 to 3:4 range X shows in full [9]. 5 MB limit [9][10]. Matches the Instagram crop for cross-posting. |
| X/Twitter 3:4 | 1536 x 2048 | 3000 | 3:4 is the tallest single photo X shows in full [9]. Off by default. |
| Threads 3:4 | 1440 x 1920 | 4000 | Threads' native portrait shape is 3:4, up to 1440 px wide, files under 8 MB [11]. |
| Pinterest 2:3 | 1000 x 1500 | 2000 | Pinterest recommends 2:3 at 1000 x 1500 and accepts files up to 20 MB [12]. |

Note: X and Facebook do not publish exact pixel sizes for ordinary posts. The pixel sizes for those presets are common practice inside the official ratio and file size limits. All Max size values are our quality targets, not platform limits, and every platform still recompresses after upload.

Sources:

1. Instagram Help Center, "Image resolution of photos you share on Instagram": https://help.instagram.com/1631821640426723
2. Buffer, "Instagram Post Size Guide 2026": https://buffer.com/resources/instagram-image-size/
3. Sprout Social, "The Ultimate 2026 Social Media Image Sizes Guide": https://sproutsocial.com/insights/social-media-image-sizes-guide/
4. Ventanix, "Meta Post Sizes 2026: Facebook and Instagram Cheat Sheet": https://ventanix.com/meta-graphic-sizes-for-2026-the-complete-facebook-instagram-cheat-sheet/
5. Facebook Help Center, "I can't upload photos on Facebook": https://www.facebook.com/help/167931376599294/
6. Adobe Express, "Facebook Image Sizes": https://www.adobe.com/express/discover/sizes/facebook
7. Fstoppers, "How To Size Your Images So They Show Their Best on Facebook": https://fstoppers.com/pictures/how-size-your-images-so-they-show-their-best-facebook-2993
8. imgcruncher, "Facebook Image Sizes Guide (2026)": https://imgcruncher.com/blog/facebook-image-sizes-2026
9. AdaptlyPost, "The Right X Image Size for Posts and Headers" (summarizes the X Help Center and X API media limits): https://adaptlypost.com/blog/x-image-size
10. MediaSizes, "Twitter/X Image Size (2026)": https://mediasizes.com/twitter-image-size/
11. Hootsuite, "Social media image sizes for all networks [November 2026]": https://blog.hootsuite.com/social-media-image-sizes-guide/
12. Pinterest Help, "Review Pin specs": https://help.pinterest.com/en/article/review-pin-specs
13. TikTok for Developers, "Media Transfer Guide" (Image restrictions) and "Photo" Content Posting API reference: https://developers.tiktok.com/doc/content-posting-api-media-transfer-guide and https://developers.tiktok.com/docs/en/content-posting-api-reference-photo-post
14. Operimage, "TikTok Image Size 2026": https://operimage.com/learn/tiktok-image-size/
15. Instagram Help Center, "Share a post with multiple photos or videos on Instagram": https://help.instagram.com/269314186824048
16. Facebook Help Center, "Photos" (albums, up to 1,000 photos): https://www.facebook.com/help/488347411285861
17. Meta Threads API, "Threads posts" (updated October 30, 2026): https://developers.facebook.com/docs/threads/posts/
18. 9to5Mac, "X now lets you share 5x more photos and videos per post" (November 12, 2026, news report, not an official Help page): https://9to5mac.com/2026/11/12/x-now-lets-you-share-5x-more-photos-and-videos-per-post/

Platforms change these numbers. Check them about once a year and update the preset table and the carousel platform limits.

## Testing checklist (short version)

The full step by step list is in `TESTING.md`. In short:

* The script installs, appears in the Script menu, and opens on a stretched image.
* The crop box moves, resizes by corner and wheel, keeps its ratio, and the Center, Max size, Reset and Same center buttons work.
* Each target keeps its own crop. In Single exports, you can check several open images; each keeps its own crop per target, and Export writes every checked image for every checked target.
* One Instagram Portrait export gives a 1080 x 1350 JPEG under 1600 KB, sRGB embedded, and the original image unchanged. Quality is 95 when that fits, or lower down to 75 if that is what the size needs. The pixel size stays 1080 x 1350 unless quality 75 is still over.
* A small target (for example 0.2 MB) drops quality toward 75 and keeps 1080 x 1350 when quality 75 fits. If quality 75 is still over, the console says the image was resized, and the file is smaller.
* A target so small that even a tiny image cannot reach it is flagged OVER, and the console shows the size that was saved.
* PNG custom presets, watermark text and logo, subfolders, file name templates and overwrite protection work.
* Settings and custom presets come back after closing and reopening.

## Known limits

* **Carousel mode is part of the full version; the free version can still preview slides.** Version 1.5.3 puts the expand and collapse arrow on the left of each section title, and keeps the settings scrollbar from covering the controls in that column. Version 1.5.2 scrolls the right-hand settings column with the mouse wheel on Windows, including when the pointer is over a label, a section bar, or a group box. Lists, dropdowns, number boxes, text fields, and the preview keep their own wheel. Version 1.5.1 keeps the window from opening tiny, puts the line under the preview in its own row, and adds Same as source for Add logo only (original format and bit depth, file name ending in `_logo`). Version 1.5.0 puts Social media export, Full frame, and Add logo only at the top of the window, and adds saved jobs (licensed, same as custom presets). Version 1.4.0 adds licensed full frame fit (with a Highest quality or Largest size priority) and logo-only export. Preset and carousel JPEGs keep their pixel size. Quality starts at 90 to 100 (default 95) and can drop to 75. The image is resized only if quality 75 is still over the target. Version 1.3.2 updates the documentation that ships with the script. Version 1.3.1 adds a little extra height so the settings column does not open with a leftover scrollbar, including when Windows display scaling is 125% or 150%. Version 1.3.0 adds an Images list in Single exports so a license holder can export several open images, each with its own crop, in one click. The free version shows the list with other images locked. Version 1.2.3 opens the window large enough to show the settings column without scrolling when the screen allows (up to 95% of the screen), and keeps grid tile numbers visible on every tile. Version 1.2.2 puts the right-hand settings in a vertical scroll box and makes Processing and Watermark sections collapsible. Version 1.2.1 keeps the Carousel panel layout stable when you change Platform (the note stays a fixed height, and the slide list and button rows no longer overlap). Version 1.2.0 adds the free and licensed split in a single script, with a license key you enter once. Version 1.1.5 fixes a PixInsight warning that appeared when a logo file was selected (a missing hasAlpha property). Version 1.1.4 renames the watermark type to Logo image and adds format tips for the logo file. Version 1.1.3 clarifies the Don't-upscale checkbox and adds Top center and Bottom center watermark positions. Version 1.1.2 keeps single-export checkmarks when you switch to Carousel and back, and adds a Platform dropdown with current slide limits. Version 1.1.1 added 2x2 and 3x3 grids, crop box grow, and visible detail overlap. Single exports, watermarks, logo images, the Open folder button, and Carousel mode have been tested in PixInsight on Windows. Version 1.2.1 fixes a layout break that showed up when switching Platform in Carousel mode.
* **Color profiles on older PixInsight versions.** PixInsight 1.9.6 and later let the script carry the image's own ICC profile into the export. On older versions, the export assumes PixInsight's default RGB profile, which is normally sRGB. If your image has a different profile assigned (Adobe RGB, for example), convert it to sRGB with ICCProfileTransformation before running the script.
* **Embedded profile depends on a PixInsight setting.** The script asks the JPEG writer to embed the sRGB profile. If the JPEG format's preferences in Format Explorer are set to override embedding and never embed ICC profiles, the profile is left out. The colors are still sRGB values.
* **Grayscale images** are exported without sRGB conversion.
* **Crops are remembered only while the dialog is open.** Checked targets, presets and options are saved between runs.
* **Speed.** Each JPEG may be saved several times while quality is searched, and again if quality 75 is still too big and the image has to be resized. Expect a few seconds per target on a typical laptop.
* **Platforms always recompress.** The script gives each platform the best possible starting file, but Instagram, Facebook and the others will still re-encode it.
* **No rotation and no free-shape crop.** Every crop is locked to its target's ratio. Use a custom preset for other shapes.
