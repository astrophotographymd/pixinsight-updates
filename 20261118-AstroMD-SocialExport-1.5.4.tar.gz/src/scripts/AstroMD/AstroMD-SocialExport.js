// ============================================================================
// AstroMD Social Export
// ----------------------------------------------------------------------------
// AstroMD-SocialExport.js
//
// Crops, resizes, sharpens, converts to sRGB, watermarks and saves a finished
// (stretched, nonlinear) image as social media ready JPEG or PNG files.
// The dialog asks what to do: social media export (the default), full frame
// fit to a file size, or add a logo only. Add logo only can keep the source
// file type, bit depth, and pixel size. Preset JPEGs keep their pixel size.
// Quality starts at the chosen value (default 95, range 90 to 100) and can
// drop to 75. Only if quality 75 is still over the target is the image
// resized smaller. Full frame fit can instead hold that quality and shrink
// the pixel size. Full frame and logo only are licensed. Saved jobs store a
// named copy of the current mode and its settings.
//
// Copyright (c) 2026 Astrophotography MD LLC. All rights reserved.
//
// This script is proprietary software. Redistribution or resale without the
// written permission of Astrophotography MD LLC is prohibited.
//
// Target platform: PixInsight 1.8.9 and later, including 1.9.x.
// Written for the classic PJSR API (ECMAScript 5 syntax only: no let, const,
// arrow functions or classes) so it runs on the older SpiderMonkey engine.
// ============================================================================

#feature-id    Astrophotography MD > Social Export

#feature-info  AstroMD Social Export: crop, resize, sharpen and save a finished \
               image for Instagram, Facebook, X, Threads, Pinterest and custom \
               targets. Choose social export, a full frame size fit, or logo \
               only. Logo only can save in the same format as the source file. \
               Preset JPEGs keep their pixel size and can drop quality \
               to 75. Full frame, logo only, and saved jobs need a license.<br/>\
               Copyright (c) 2026 Astrophotography MD LLC. All rights reserved.

#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/SectionBar.jsh>

// ----------------------------------------------------------------------------
// Version and identity
// ----------------------------------------------------------------------------

var ASMD_TITLE        = "AstroMD Social Export";
var ASMD_VERSION      = "1.5.4";
var ASMD_SETTINGS_KEY = "AstroMD_SocialExport";   // Settings key prefix

// Description of the sRGB profile installed with PixInsight. The
// ICCProfileTransformation and AssignICCProfile processes look profiles up
// by description. If this lookup fails, the script falls back to the
// PixInsight default RGB profile (normally sRGB) and logs a warning.
var ASMD_SRGB_PROFILE = "sRGB IEC61966-2.1";

// JPEG quality control: the starting (maximum) quality. The user can set
// 90 to 100. The default is 95. Presets search downward from that value
// to ASMD_JPEG_SEARCH_FLOOR. They are resized smaller only if quality 75
// is still over the target.
var ASMD_JPEG_QUALITY       = 95;
var ASMD_JPEG_QUALITY_FLOOR = 90;
var ASMD_JPEG_QUALITY_MAX   = 100;
var ASMD_JPEG_SEARCH_FLOOR  = 75;
// Scale search stops when the gap is within about 1.5 percent, then keeps
// the largest size that already fit.
var ASMD_SCALE_TOLERANCE    = 0.015;

// Dialog floor, in logical pixels. asmdScaledPx turns these into physical
// pixels with logicalPixelsToPhysical, or displayPixelRatio when that
// helper is missing. The real floor is also clamped to the screen.
var ASMD_DIALOG_MIN_W   = 1100;
var ASMD_DIALOG_MIN_H   = 750;
var ASMD_PREVIEW_MIN_W  = 560;
var ASMD_PREVIEW_MIN_H  = 400;
var ASMD_CROPINFO_MIN_H = 48;
// One mouse wheel notch is 120 units (Windows WHEEL_DELTA). Scroll this
// many text lines per notch. Small trackpad steps scale with delta/120.
var ASMD_WHEEL_LINES    = 3;

// ============================================================================
// BUILT-IN PRESETS (edit this table to change the defaults)
// ----------------------------------------------------------------------------
// Each preset uses EITHER exact pixels:   width, height
//                    OR a ratio + edge:   ratio ("4:5", "16:9" or "native"),
//                                         longEdge
// "native" means: keep the image's own aspect ratio (no aspect crop).
//
//   id        unique key (never change it once released; settings use it)
//   name      label shown in the dialog
//   platform  short tag used in file names ({platform} token)
//   maxKB     target file size in kilobytes (1 KB = 1024 bytes)
//   format    "JPEG" or "PNG"
//   sharpen   apply output sharpening (true/false)
//   enabled   checked by default on first run
//
// Sources for every number are listed in README.md, "Presets and sources".
// ============================================================================

var ASMD_BUILTIN_PRESETS = [
   { id: "ig-portrait",  name: "Instagram Portrait 4:5 (app + schedulers)", platform: "Instagram-Portrait",
     width: 1080, height: 1350, maxKB: 1600, format: "JPEG", sharpen: true, enabled: true  },
   { id: "ig-portrait34", name: "Instagram Portrait 3:4 (app only)", platform: "Instagram-Portrait34",
     width: 1080, height: 1440, maxKB: 1800, format: "JPEG", sharpen: true, enabled: false },
   { id: "ig-square",    name: "Instagram Square 1:1",      platform: "Instagram-Square",
     width: 1080, height: 1080, maxKB: 1300, format: "JPEG", sharpen: true, enabled: false },
   { id: "ig-landscape", name: "Instagram Landscape 1.91:1", platform: "Instagram-Landscape",
     width: 1080, height: 566,  maxKB: 800,  format: "JPEG", sharpen: true, enabled: false },
   { id: "ig-story",     name: "Instagram Story/Reel 9:16", platform: "Instagram-Story",
     width: 1080, height: 1920, maxKB: 2400, format: "JPEG", sharpen: true, enabled: false },
   { id: "tiktok-photo", name: "TikTok Photo 9:16",         platform: "TikTok",
     width: 1080, height: 1920, maxKB: 2400, format: "JPEG", sharpen: true, enabled: false },
   { id: "fb-feed",      name: "Facebook Feed (2048 long edge)", platform: "Facebook-Feed",
     ratio: "native", longEdge: 2048, maxKB: 1000, format: "JPEG", sharpen: true, enabled: true  },
   { id: "fb-portrait",  name: "Facebook Feed 4:5",         platform: "Facebook-Portrait",
     width: 1638, height: 2048, maxKB: 1500, format: "JPEG", sharpen: true, enabled: false },
   { id: "fb-cover",     name: "Facebook Cover 16:9",       platform: "Facebook-Cover",
     width: 1920, height: 1080, maxKB: 400,  format: "JPEG", sharpen: true, enabled: false },
   { id: "x-landscape",  name: "X/Twitter 16:9",            platform: "X-Landscape",
     width: 1600, height: 900,  maxKB: 3000, format: "JPEG", sharpen: true, enabled: false },
   { id: "x-portrait",   name: "X/Twitter 4:5",             platform: "X-Portrait",
     width: 1600, height: 2000, maxKB: 3000, format: "JPEG", sharpen: true, enabled: false },
   { id: "x-portrait34", name: "X/Twitter 3:4",             platform: "X-Portrait34",
     width: 1536, height: 2048, maxKB: 3000, format: "JPEG", sharpen: true, enabled: false },
   { id: "threads",      name: "Threads 3:4",               platform: "Threads",
     width: 1440, height: 1920, maxKB: 4000, format: "JPEG", sharpen: true, enabled: false },
   { id: "pinterest",    name: "Pinterest 2:3",             platform: "Pinterest",
     width: 1000, height: 1500, maxKB: 2000, format: "JPEG", sharpen: true, enabled: false }
];

// Default option values (used on first run).
var ASMD_DEFAULTS = {
   template:          "{name}_{platform}_{w}x{h}_{date}.jpg",
   subfolderPerImage: false,
   overwrite:         false,
   noUpscale:         true,   // don't enlarge small crops; saved values still win
   interpolation:     0,      // index into ASMD_INTERPOLATIONS
   sharpenEnabled:    false,  // master switch; off unless the box is checked
   sharpenStrength:   0.25,   // 0 = off, 1 = strongest
   wmEnabled:         false,
   wmMode:            0,      // 0 = text, 1 = logo image (stored index kept)
   wmText:            "\u00A9 Astrophotography MD",
   wmLogoPath:        "",
   wmCorner:          3,      // index into ASMD_CORNERS
   wmOpacity:         0.60,
   wmSizePercent:     3.0,    // text height or logo height, % of short edge
   mode:              0,      // 0 = single exports, 1 = carousel
   carShape:          0,      // index into ASMD_CAROUSEL_SHAPES
   carCustomW:        1080,
   carCustomH:        1350,
   carPanels:         3,      // panorama slides
   carLayout:         0,      // index into ASMD_CAROUSEL_LAYOUTS (0 = panorama)
   carPlatform:       0,      // index into ASMD_CAROUSEL_PLATFORMS (0 = Instagram)
   carWatermark:      1,      // index into ASMD_CAROUSEL_WATERMARKS
   carMaxKB:          1600,   // per slide
   carTemplate:       "{name}_Carousel_{slide}_{w}x{h}_{date}.jpg",
   processingExpanded: false,  // Processing section starts collapsed
   watermarkExpanded:  true,   // Watermark / signature starts expanded
   jpegQuality:       95,     // held for every JPEG; never under the floor
   fullFrameFit:      false,  // derived: whole image, fit to a size target
   fullFrameMaxMB:    10,     // target for full frame fit, in MB (1000 KB)
   fullFramePriority: 0,      // 0 = highest quality, 1 = largest size
   logoOnly:          false,  // derived: watermark only, no other edits
   exportMode:        0,      // 0 social, 1 full frame fit, 2 add logo only
   logoFit:           false,  // logo only: false = original size, true = fit to MB
   logoFormat:        "SOURCE", // logo only, original size: SOURCE, JPEG, or PNG
   logoMaxMB:         10,     // logo only size target, in MB
   logoPriority:      0       // logo only, fit to MB: 0 highest quality, 1 largest size
};

// Resampling choices shown in the dialog. "Auto" uses Mitchell-Netravali
// for reductions (it low-pass filters, which avoids aliasing on star fields)
// and clamped Lanczos-3 for enlargements or very mild reductions.
var ASMD_INTERPOLATIONS = [
   "Auto (recommended)",
   "Mitchell-Netravali filter",
   "Lanczos-3 (clamped)",
   "Bicubic spline"
];

// Stored indices stay stable: 0 TL, 1 TR, 2 BL, 3 BR, 4 Center,
// 5 Left center, 6 Right center, 7 Top center, 8 Bottom center.
var ASMD_CORNERS = [ "Top left", "Top right", "Bottom left", "Bottom right",
                     "Center", "Left center", "Right center",
                     "Top center", "Bottom center" ];

// Dropdown order (rows of left, center, right, top to bottom).
var ASMD_CORNER_ORDER = [ 0, 7, 1, 5, 4, 6, 2, 8, 3 ];

var ASMD_LOGO_TOOLTIP = "<p>Best: PNG with a transparent background, at least 1000 px wide. " +
   "Also works: JPEG, BMP, GIF, TIFF, XISF, FITS. JPEG has no transparency, so the whole " +
   "rectangle shows. SVG is not supported; export it to PNG first.</p>";

var ASMD_LOGO_FILTERS = [
   [ "Images", "*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff *.xisf *.fits *.fit" ],
   [ "All files", "*" ]
];

function asmdCornerComboIndex( corner )
{
   for ( var i = 0; i < ASMD_CORNER_ORDER.length; ++i )
      if ( ASMD_CORNER_ORDER[i] == corner )
         return i;
   return asmdCornerComboIndex( 3 );
}

function asmdCornerFromCombo( comboIndex )
{
   if ( comboIndex >= 0 && comboIndex < ASMD_CORNER_ORDER.length )
      return ASMD_CORNER_ORDER[comboIndex];
   return 3;
}

// Top-left of the watermark box, using the same margin on every edge.
function asmdWatermarkPosition( pos, W, H, bw, bh, margin )
{
   var x, y;
   if ( pos == 0 || pos == 2 || pos == 5 )
      x = margin;
   else if ( pos == 4 || pos == 7 || pos == 8 )
      x = Math.round( (W - bw)/2 );
   else
      x = W - margin - bw;
   if ( pos == 0 || pos == 1 || pos == 7 )
      y = margin;
   else if ( pos == 2 || pos == 3 || pos == 8 )
      y = H - margin - bh;
   else
      y = Math.round( (H - bh)/2 );
   return { x: x, y: y };
}

// ============================================================================
// Small utilities
// ============================================================================

function asmdTrim( s )
{
   return String( s ).replace( /^\s+|\s+$/g, "" );
}

function asmdPad( s, n, right )
{
   s = String( s );
   while ( s.length < n )
      s = right ? (" " + s) : (s + " ");
   return s;
}

function asmdTwo( n )
{
   return (n < 10 ? "0" : "") + n;
}

function asmdDateString()
{
   var d = new Date;
   return d.getFullYear() + "-" + asmdTwo( d.getMonth() + 1 ) + "-" + asmdTwo( d.getDate() );
}

function asmdTimeString()
{
   var d = new Date;
   return asmdTwo( d.getHours() ) + asmdTwo( d.getMinutes() ) + asmdTwo( d.getSeconds() );
}

// Make a string safe for a file name on Windows, macOS and Linux.
function asmdSafeFileToken( s )
{
   s = asmdTrim( s ).replace( /\s+/g, "-" );
   s = s.replace( /[^A-Za-z0-9._\-]/g, "-" );
   s = s.replace( /-{2,}/g, "-" ).replace( /^[-.]+|[-.]+$/g, "" );
   return s.length > 0 ? s : "image";
}

// Normalize a directory path: forward slashes, no trailing slash.
function asmdCleanDir( dir )
{
   dir = asmdTrim( dir ).replace( /\\/g, "/" );
   while ( dir.length > 1 && dir.charAt( dir.length - 1 ) == "/" && !/^[A-Za-z]:\/$/.test( dir ) )
      dir = dir.substring( 0, dir.length - 1 );
   return dir;
}

// File size in bytes. FileInfo is used when available; the File object is
// the fallback for older cores.
function asmdFileSize( path )
{
   try
   {
      var info = new FileInfo( path );
      if ( info.exists )
         return info.size;
   }
   catch ( x ) {}
   var f = new File;
   f.openForReading( path );
   var n = f.size;
   f.close();
   return n;
}

function asmdRemoveFile( path )
{
   try
   {
      if ( File.exists( path ) )
         File.remove( path );
   }
   catch ( x ) {}
}

// Formats a size given in KB as MB for display (1 MB = 1000 KB here, so a
// 2400 KB target reads as 2.4 MB).
function asmdMB( kb )
{
   var mb = kb/1000;
   return ((mb < 10) ? mb.toFixed( 2 ).replace( /0$/, "" ) : mb.toFixed( 1 )) + " MB";
}

// Console text for a saved file. Numeric quality is a JPEG quality. PNG and
// bit-depth labels are printed as themselves.
function asmdSummaryQuality( q )
{
   if ( q == "PNG" )
      return "PNG";
   var s = String( q );
   if ( /^[0-9]+$/.test( s ) )
      return "quality " + s;
   return s;
}

// The JPEG quality control, 90 to 100. Missing or invalid values use 95.
// Numbers under 90 are raised to 90. The search floor of 75 is separate.
function asmdClampJpegQuality( q )
{
   q = Math.round( Number( q ) );
   if ( !(q > 0) )
      return ASMD_JPEG_QUALITY;
   if ( q < ASMD_JPEG_QUALITY_FLOOR )
      return ASMD_JPEG_QUALITY_FLOOR;
   if ( q > ASMD_JPEG_QUALITY_MAX )
      return ASMD_JPEG_QUALITY_MAX;
   return q;
}

// Highest JPEG quality in [minQ, maxQ] whose measure(q) is at or under
// maxBytes. measure(q) returns a byte count. If maxQ fits, it is kept.
// If minQ does not fit, fits is false and quality is minQ.
function asmdPickJpegQuality( measure, maxBytes, maxQ, minQ )
{
   maxQ = Math.round( maxQ );
   minQ = Math.round( minQ );
   if ( !(maxQ >= minQ) )
      maxQ = minQ;
   var top = measure( maxQ );
   if ( top <= maxBytes )
      return { quality: maxQ, bytes: top, fits: true };
   var bottom = measure( minQ );
   if ( bottom > maxBytes )
      return { quality: minQ, bytes: bottom, fits: false };
   var lo = minQ, hi = maxQ, best = bottom;
   while ( hi - lo > 1 )
   {
      var mid = Math.floor( (lo + hi)/2 );
      var n = measure( mid );
      if ( n <= maxBytes )
      {
         lo = mid;
         best = n;
      }
      else
         hi = mid;
   }
   return { quality: lo, bytes: best, fits: true };
}

// Console line when quality 75 is still too big and the image is resized.
function asmdLastResortText( fromW, fromH, toW, toH, quality, bytes, maxKB )
{
   return "Quality " + quality + " is still over " + asmdMB( maxKB ) + " at " +
          fromW + " x " + fromH + ", so the image was resized to " +
          toW + " x " + toH + " at quality " + quality + ", " + asmdMB( bytes/1024 ) + ".";
}

// Pixel size at a scale of the starting image. Scale 1 keeps the start size.
// Both edges use the same factor so the aspect ratio stays put.
function asmdScaledSize( w, h, scale )
{
   if ( !(scale > 0) || scale >= 0.9995 )
      return { w: w, h: h, scale: 1 };
   var outW = Math.max( 1, Math.round( w*scale ) );
   var outH = Math.max( 1, Math.round( h*scale ) );
   if ( outW > w ) outW = w;
   if ( outH > h ) outH = h;
   if ( outW == w && outH == h )
      return { w: w, h: h, scale: 1 };
   return { w: outW, h: outH, scale: outW/w };
}

// Smallest scale the size search will try: 8 percent, or whatever keeps the
// long edge at about 64 px, whichever is larger. Below that we stop and warn.
function asmdMinFitScale( w, h )
{
   var longEdge = Math.max( w, h );
   if ( !(longEdge > 0) )
      return 1;
   var for64 = 64/longEdge;
   if ( for64 > 1 )
      for64 = 1;
   var s = (for64 > 0.08) ? for64 : 0.08;
   return (s > 1) ? 1 : s;
}

// Largest scale in (0, 1] whose measure().bytes is at or under maxBytes.
// measure(scale) returns { w, h, scale, bytes, path }. The search stops
// within about 1 to 2 percent and returns the largest size that passed,
// not an untested midpoint. If even the minimum scale is over, fits is false.
function asmdFitScale( measure, maxBytes, tolerance, minScale )
{
   if ( !(tolerance > 0) )
      tolerance = ASMD_SCALE_TOLERANCE;
   if ( !(minScale > 0) || minScale > 1 )
      minScale = 0.08;
   var full = measure( 1 );
   if ( full.bytes <= maxBytes )
      return { scale: (full.scale > 0) ? full.scale : 1, w: full.w, h: full.h,
               bytes: full.bytes, path: full.path, fits: true };
   var hi = 1;
   var lo = (minScale > 0.5) ? minScale : 0.5;
   var loM = (Math.abs( lo - 1 ) < 1e-9) ? full : measure( lo );
   var guard = 0;
   while ( loM.bytes > maxBytes && lo > minScale + 1e-6 && guard < 8 )
   {
      hi = lo;
      lo = Math.max( minScale, lo*0.5 );
      loM = measure( lo );
      ++guard;
   }
   if ( loM.bytes > maxBytes )
      return { scale: (loM.scale > 0) ? loM.scale : lo, w: loM.w, h: loM.h,
               bytes: loM.bytes, path: loM.path, fits: false };
   var best = loM;
   var iter = 0;
   while ( hi > 0 && (hi - lo)/hi > tolerance && iter < 16 )
   {
      var mid = (lo + hi)/2;
      var m = measure( mid );
      if ( m.bytes <= maxBytes )
      {
         lo = mid;
         best = m;
      }
      else
         hi = mid;
      ++iter;
   }
   return { scale: (best.scale > 0) ? best.scale : lo, w: best.w, h: best.h,
            bytes: best.bytes, path: best.path, fits: true };
}

// One line for the Process Console and the status text.
function asmdFitStatusText( fromW, fromH, toW, toH, quality, bytes )
{
   var size = asmdMB( bytes/1024 );
   if ( fromW == toW && fromH == toH )
      return "Kept " + fromW + " x " + fromH + " at quality " + quality + ", " + size;
   return "Resized " + fromW + " x " + fromH + " to " + toW + " x " + toH +
          " at quality " + quality + ", " + size;
}

// If the file name contains the starting pixel size, swap in the final size.
function asmdPathWithSize( path, fromW, fromH, toW, toH, overwrite )
{
   if ( fromW == toW && fromH == toH )
      return path;
   var slash = path.lastIndexOf( "/" );
   var bslash = path.lastIndexOf( "\\" );
   if ( bslash > slash )
      slash = bslash;
   var dir = (slash >= 0) ? path.substring( 0, slash ) : "";
   var file = (slash >= 0) ? path.substring( slash + 1 ) : path;
   var fromTok = String( fromW ) + "x" + String( fromH );
   var toTok = String( toW ) + "x" + String( toH );
   if ( file.indexOf( fromTok ) < 0 )
      return path;
   var renamed = file.split( fromTok ).join( toTok );
   var next = (dir.length > 0) ? (dir + "/" + renamed) : renamed;
   return asmdUniquePath( next, !!overwrite );
}

// Crop-info line when an export ignores the crop box.
function asmdWholeFrameNote( fullFrame, logoOnly )
{
   if ( fullFrame && logoOnly )
      return "Logo only, full frame: the whole image is exported and fit to the size target. The crop box is not used.";
   if ( logoOnly )
      return "Logo only: the whole image is exported with the watermark only. The crop box is not used.";
   if ( fullFrame )
      return "Full frame: the whole image is exported and fit to the size target. The crop box is not used.";
   return "";
}

// 0 = social media export, 1 = full frame fit, 2 = add logo only.
// A missing mode (older settings) is recovered from the 1.4.0 checkboxes.
function asmdNormalizeExportMode( mode, fullFrameFit, logoOnly )
{
   var m = parseInt( mode, 10 );
   if ( m == 0 || m == 1 || m == 2 )
      return m;
   if ( logoOnly )
      return 2;
   if ( fullFrameFit )
      return 1;
   return 0;
}

function asmdExportModeHelp( mode )
{
   if ( mode == 1 )
      return "No crop. The whole image is fit to the file size next to this choice.";
   if ( mode == 2 )
      return "Add a logo or signature only. No crop and no sharpening.";
   return "Crop to a platform preset, then resize and save.";
}

function asmdMessage( text, icon )
{
   (new MessageBox( text, ASMD_TITLE, (icon === undefined) ? StdIcon_Information : icon,
                    StdButton_Ok )).execute();
}

function asmdConfirm( text )
{
   return (new MessageBox( text, ASMD_TITLE, StdIcon_Question,
                           StdButton_Yes, StdButton_No )).execute() == StdButton_Yes;
}

// Parse "4:5", "1.91:1", "16x9" or a plain number. Returns width/height,
// -1 for "native", or 0 when the text is not a valid ratio.
function asmdParseRatio( s )
{
   s = asmdTrim( s ).toLowerCase();
   if ( s == "native" || s == "original" || s == "source" )
      return -1;
   var m = s.match( /^([0-9]*\.?[0-9]+)\s*[:x\/]\s*([0-9]*\.?[0-9]+)$/ );
   if ( m )
   {
      var a = parseFloat( m[1] ), b = parseFloat( m[2] );
      return (a > 0 && b > 0) ? a/b : 0;
   }
   var v = parseFloat( s );
   return (v > 0) ? v : 0;
}

// ============================================================================
// Preset model
// ============================================================================

// Clone a preset so the built-in table is never modified at run time.
function asmdClonePreset( p )
{
   return {
      id:       p.id,
      name:     p.name,
      platform: p.platform,
      width:    p.width    || 0,
      height:   p.height   || 0,
      ratio:    p.ratio    || "",
      longEdge: p.longEdge || 0,
      maxKB:    p.maxKB    || 0,
      format:   (p.format == "PNG") ? "PNG" : "JPEG",
      sharpen:  p.sharpen !== false,
      enabled:  !!p.enabled,
      builtIn:  !!p.builtIn
   };
}

// Output pixel size and crop aspect (width/height) for a preset, given the
// source image size. Returns { w, h, aspect }.
function asmdPresetGeometry( p, srcW, srcH )
{
   var w, h, aspect;
   if ( p.width > 0 && p.height > 0 )
   {
      w = Math.round( p.width );
      h = Math.round( p.height );
      aspect = w/h;
   }
   else
   {
      aspect = asmdParseRatio( p.ratio );
      if ( aspect <= 0 )
         aspect = srcW/srcH;               // "native" (or invalid ratio)
      var L = (p.longEdge > 0) ? p.longEdge : 2048;
      if ( aspect >= 1 )
      {
         w = L;
         h = Math.max( 1, Math.round( L/aspect ) );
      }
      else
      {
         h = L;
         w = Math.max( 1, Math.round( L*aspect ) );
      }
   }
   return { w: w, h: h, aspect: aspect };
}

// Human readable size column for the targets list.
function asmdPresetSizeText( p )
{
   if ( p.width > 0 && p.height > 0 )
      return p.width + " x " + p.height;
   var r = asmdTrim( p.ratio ).toLowerCase();
   return ((r == "" || r == "native") ? "native ratio" : p.ratio) + ", " + p.longEdge + " long edge";
}

// ============================================================================
// Persistent settings
// ============================================================================

function asmdReadSetting( key, type, def )
{
   try
   {
      var v = Settings.read( ASMD_SETTINGS_KEY + "/" + key, type );
      if ( Settings.lastReadOK && v !== null && v !== undefined )
         return v;
   }
   catch ( x ) {}
   return def;
}

function asmdWriteSetting( key, type, value )
{
   try
   {
      Settings.write( ASMD_SETTINGS_KEY + "/" + key, type, value );
   }
   catch ( x )
   {
      console.warningln( "** Could not save setting " + key + ": " + x.message );
   }
}


// Usable screen rectangle in the same pixels Control.resize uses.
// availableScreenRect is physical pixels. x and y default to 0 when the
// rect does not report an origin (the test mock is width and height only).
function asmdScreenRect( dlg )
{
   var w = 0, h = 0, x = 0, y = 0;
   try
   {
      if ( dlg && ("availableScreenRect" in dlg) )
      {
         var r = dlg.availableScreenRect;
         if ( r )
         {
            if ( ("width" in r) && r.width > 0 )
               w = r.width;
            if ( ("height" in r) && r.height > 0 )
               h = r.height;
            if ( ("x0" in r) )
               x = r.x0;
            else if ( ("x" in r) )
               x = r.x;
            if ( ("y0" in r) )
               y = r.y0;
            else if ( ("y" in r) )
               y = r.y;
         }
      }
   }
   catch ( e ) {}
   return { x: x, y: y, w: w, h: h };
}

// Cap the dialog to the usable screen minus a margin, and never more than
// about 95% of that screen, so the settings column can show without
// scrolling while the window still fits on a laptop. If availableScreenRect
// is missing (older PixInsight, or a test mock), the cap is 1280 x 900
// logical pixels converted with the scaling helpers.
function asmdDialogCap( dlg )
{
   var screen = asmdScreenRect( dlg );
   var capW = screen.w, capH = screen.h;
   var defW = asmdScaledPx( dlg, 1280 );
   var defH = asmdScaledPx( dlg, 900 );
   if ( !(defW > 0) )
      defW = 1280;
   if ( !(defH > 0) )
      defH = 900;
   if ( capW >= 400 && capH >= 400 )
   {
      var margin = asmdScaledPx( dlg, 16 );
      if ( !(margin > 0) )
         margin = 16;
      var fitW = capW - 2*margin;
      var fitH = capH - 2*margin;
      var pctW = Math.floor( capW * 0.95 );
      var pctH = Math.floor( capH * 0.95 );
      if ( fitW > pctW )
         fitW = pctW;
      if ( fitH > pctH )
         fitH = pctH;
      capW = Math.max( 640, fitW );
      capH = Math.max( 480, fitH );
   }
   else
   {
      capW = defW;
      capH = defH;
   }
   return { w: capW, h: capH };
}

// Logical pixels to the pixels Control.resize and setMinHeight expect.
// logicalPixelsToPhysical is the PJSR helper. displayPixelRatio is the
// fallback, and it also corrects a helper that returned the logical value
// unchanged on a scaled display.
function asmdScaledPx( dlg, logical )
{
   var n = Number( logical );
   if ( !(n >= 0) )
      return 0;
   var byMethod = 0, haveMethod = false;
   try
   {
      if ( dlg && ("logicalPixelsToPhysical" in dlg) )
      {
         var p = dlg.logicalPixelsToPhysical( n );
         if ( p == p && p >= 0 )
         {
            byMethod = p;
            haveMethod = true;
         }
      }
   }
   catch ( x ) {}
   var ratio = 0;
   try
   {
      if ( dlg && ("displayPixelRatio" in dlg) && dlg.displayPixelRatio > 0 )
         ratio = dlg.displayPixelRatio;
   }
   catch ( x ) {}
   var byRatio = (ratio > 0) ? (n * ratio) : 0;
   if ( haveMethod && byRatio > 0 )
   {
      if ( Math.abs( byMethod - n ) < 0.5 && Math.abs( ratio - 1 ) > 0.01 )
         return Math.round( byRatio );
      return Math.round( byMethod );
   }
   if ( haveMethod )
      return Math.round( byMethod );
   if ( byRatio > 0 )
      return Math.round( byRatio );
   return Math.round( n );
}

// 1100 x 750 logical pixels, or the screen cap when that is smaller.
function asmdDialogMinimumSize( dlg )
{
   var cap = asmdDialogCap( dlg );
   var w = asmdScaledPx( dlg, ASMD_DIALOG_MIN_W );
   var h = asmdScaledPx( dlg, ASMD_DIALOG_MIN_H );
   if ( !(w > 0) )
      w = ASMD_DIALOG_MIN_W;
   if ( !(h > 0) )
      h = ASMD_DIALOG_MIN_H;
   if ( w > cap.w )
      w = cap.w;
   if ( h > cap.h )
      h = cap.h;
   return { w: w, h: h };
}

function asmdResizeDialog( dlg, w, h )
{
   dlg._asmdEnsuring = true;
   try
   {
      dlg.resize( w, h );
   }
   catch ( x ) {}
   finally
   {
      dlg._asmdEnsuring = false;
   }
}

// Width of a vertical scrollbar, in physical pixels.
function asmdScrollBarExtent( dlg, scroll )
{
   var ext = 0;
   try
   {
      if ( scroll )
      {
         if ( ("verticalScrollBarWidth" in scroll) && scroll.verticalScrollBarWidth > 0 )
            ext = scroll.verticalScrollBarWidth;
         else if ( ("scrollBarWidth" in scroll) && scroll.scrollBarWidth > 0 )
            ext = scroll.scrollBarWidth;
      }
   }
   catch ( x ) {}
   if ( !(ext > 0) )
      ext = asmdScaledPx( dlg, 16 );
   return ext;
}

// Extra height so rounding, ScrollBox frames, and a leftover bar do not
// leave a slider that only moves a few pixels.
function asmdFitSafetyMargin( dlg, scroll )
{
   return asmdScaledPx( dlg, 24 ) + asmdScrollBarExtent( dlg, scroll );
}

// Width the settings pane may use without sliding under the vertical bar.
// Pass barVisible to measure a bar state that is not stored on the control
// yet. When the viewport is already narrower than the ScrollBox, that width
// is the visible area. When the viewport is still as wide as the ScrollBox,
// the bar is drawn on top of it, so the pane is inset by the bar width.
// The old code added the bar width back, which parked the section arrows
// under the bar.
function asmdScrollContentWidth( dlg, scroll, barVisible )
{
   var w = 0, vp = null, host = 0, showing = false;
   var force = arguments.length >= 3;
   try
   {
      if ( scroll && ("viewport" in scroll) && scroll.viewport )
         vp = scroll.viewport;
   }
   catch ( x ) {}
   try
   {
      w = vp ? vp.width : 0;
   }
   catch ( x ) {}
   if ( !(w > 0) )
   {
      try { w = scroll ? scroll.width : 0; } catch ( x ) {}
   }
   try
   {
      if ( scroll && ("width" in scroll) )
         host = scroll.width;
   }
   catch ( x ) {}
   if ( force )
      showing = !!barVisible;
   else
   {
      try
      {
         if ( scroll && ("verticalScrollBarVisible" in scroll) )
            showing = !!scroll.verticalScrollBarVisible;
      }
      catch ( x ) {}
   }
   if ( showing && w > 0 )
   {
      var bar = asmdScrollBarExtent( dlg, scroll );
      var room = w;
      if ( host > bar )
         room = host - bar;
      else if ( w > bar )
         room = w - bar;
      if ( room < w )
         w = room;
      if ( !(w > 0) )
         w = 1;
   }
   return w;
}

function asmdApplySettingsPaneWidth( dlg, width )
{
   if ( !dlg || !dlg.rightPane || !(width > 0) )
      return;
   try
   {
      dlg.rightPane.setFixedWidth( width );
   }
   catch ( x )
   {
      try { dlg.rightPane.width = width; } catch ( y ) {}
   }
}

// PixInsight's own section bars put the arrow first, then the title.
// The script SectionBar ships the arrow after a stretch, on the right,
// where the settings scrollbar covers it. Rebuild the row as arrow,
// optional checkbox, then title.
function asmdPlaceSectionArrowLeft( bar )
{
   if ( !bar )
      return false;
   var button = null, label = null, check = null;
   try
   {
      if ( ("button" in bar) && bar.button )
         button = bar.button;
   }
   catch ( e ) {}
   try
   {
      if ( ("label" in bar) && bar.label )
         label = bar.label;
   }
   catch ( e2 ) {}
   try
   {
      if ( ("checkBox" in bar) && bar.checkBox )
         check = bar.checkBox;
   }
   catch ( e3 ) {}
   if ( !button || !label )
      return false;
   var row = null, outer = null;
   try
   {
      row = new HorizontalSizer;
      outer = new VerticalSizer;
   }
   catch ( e4 )
   {
      return false;
   }
   if ( !row || !outer )
      return false;
   row.addSpacing( 4 );
   row.add( button );
   row.addSpacing( 4 );
   if ( check )
   {
      row.add( check );
      row.addSpacing( 2 );
   }
   row.add( label );
   row.addStretch();
   row.addSpacing( 4 );
   outer.addSpacing( 1 );
   outer.add( row );
   outer.addSpacing( 1 );
   try { bar.hSizer = row; } catch ( e5 ) {}
   try { bar.sizer = outer; } catch ( e6 ) {}
   try
   {
      if ( ("adjustToContents" in bar) && bar.adjustToContents )
         bar.adjustToContents();
   }
   catch ( e7 ) {}
   try
   {
      if ( ("setFixedHeight" in bar) && bar.setFixedHeight )
         bar.setFixedHeight();
   }
   catch ( e8 ) {}
   return true;
}

// True when ctor is a constructor and ctrl is one of its instances.
// instanceof is wrapped because a host object can throw on a bad check.
function asmdIsInstance( ctrl, ctor )
{
   if ( !ctrl || typeof ctor != "function" )
      return false;
   try
   {
      return ctrl instanceof ctor;
   }
   catch ( e )
   {
      return false;
   }
}

// Read a property only after an in-check. A bare read warns in PJSR when
// the property is missing.
function asmdHas( ctrl, prop )
{
   try
   {
      return !!(ctrl && (prop in ctrl));
   }
   catch ( e )
   {
      return false;
   }
}

// Controls that already use the wheel. The settings column must not take
// those events. TreeBox (Images, Targets, slide list) scrolls itself.
// ComboBox and SpinBox change the current item or number. NumericControl
// moves its slider. Edit keeps the caret. The crop preview zooms the box.
function asmdControlConsumesWheel( ctrl )
{
   if ( !ctrl )
      return true;
   if ( (typeof TreeBox == "function" && asmdIsInstance( ctrl, TreeBox )) ||
        (asmdHas( ctrl, "setHeaderText" ) && asmdHas( ctrl, "numberOfColumns" )) )
      return true;
   if ( (typeof ComboBox == "function" && asmdIsInstance( ctrl, ComboBox )) ||
        (asmdHas( ctrl, "addItem" ) && asmdHas( ctrl, "currentItem" ) &&
         !asmdHas( ctrl, "setHeaderText" )) )
      return true;
   if ( asmdIsNumericControl( ctrl ) )
      return true;
   if ( typeof SpinBox == "function" && asmdIsInstance( ctrl, SpinBox ) )
      return true;
   // NumericEdit also has setRange. It is not a SpinBox. The edit inside
   // it is an Edit and is left alone; the NumericEdit frame can scroll.
   if ( asmdHas( ctrl, "setRange" ) && asmdHas( ctrl, "value" ) &&
        !asmdHas( ctrl, "setReal" ) && !asmdHas( ctrl, "slider" ) &&
        !asmdHas( ctrl, "addItem" ) && !asmdHas( ctrl, "setHeaderText" ) &&
        !(typeof NumericEdit == "function" && asmdIsInstance( ctrl, NumericEdit )) )
      return true;
   if ( typeof Edit == "function" && asmdIsInstance( ctrl, Edit ) )
      return true;
   if ( typeof Slider == "function" && asmdIsInstance( ctrl, Slider ) )
      return true;
   if ( typeof HorizontalSlider == "function" && asmdIsInstance( ctrl, HorizontalSlider ) )
      return true;
   if ( typeof VerticalSlider == "function" && asmdIsInstance( ctrl, VerticalSlider ) )
      return true;
   if ( typeof TextBox == "function" && asmdIsInstance( ctrl, TextBox ) )
      return true;
   if ( typeof AsmdCropPreview == "function" && asmdIsInstance( ctrl, AsmdCropPreview ) )
      return true;
   return false;
}

// Signed pixels to subtract from verticalScrollPosition. Positive delta
// (wheel forward, away from the user) yields a positive step, which moves
// toward the top of the settings column.
function asmdWheelScrollStep( delta, linePx )
{
   var line = linePx;
   if ( !(line > 0) )
      line = 16;
   return Math.round( (delta / 120) * line * ASMD_WHEEL_LINES );
}

function asmdClampVerticalScroll( y, maxY )
{
   if ( !(maxY >= 0) )
      maxY = 0;
   if ( !(y >= 0) )
      y = 0;
   if ( y > maxY )
      y = maxY;
   return y;
}

// One text line, in pixels. ScrollBox lineHeight is often 1 until somebody
// sets it, which would make a notch move only a few pixels. Prefer the
// control font in that case.
function asmdSettingsLineHeight( scroll )
{
   var fontH = 0;
   var line = 0;
   try
   {
      if ( scroll && ("font" in scroll) && scroll.font && ("height" in scroll.font) &&
           scroll.font.height > 0 )
         fontH = scroll.font.height;
   }
   catch ( e ) {}
   try
   {
      if ( scroll && ("lineHeight" in scroll) && scroll.lineHeight > 0 )
         line = scroll.lineHeight;
   }
   catch ( e2 ) {}
   if ( fontH > 0 && (!(line > 0) || line < fontH) )
      line = fontH;
   if ( !(line > 0) )
      line = 16;
   return line;
}

// Move the settings pane. Setting verticalScrollPosition does not emit
// onVerticalScrollPosUpdated, so the wheel path has to move the pane too.
function asmdMoveScrolledPane( pane, y )
{
   if ( !pane )
      return;
   if ( !(y >= 0) )
      y = 0;
   try
   {
      if ( "move" in pane )
         pane.move( 0, -y );
      else
         pane.y = -y;
   }
   catch ( x ) {}
}

function asmdScrollByWheel( scroll, pane, delta )
{
   if ( !scroll || !delta )
      return;
   var maxY = 0;
   var cur = 0;
   try
   {
      if ( "maxVerticalScrollPosition" in scroll )
         maxY = scroll.maxVerticalScrollPosition;
   }
   catch ( e ) {}
   try
   {
      if ( "verticalScrollPosition" in scroll )
         cur = scroll.verticalScrollPosition;
   }
   catch ( e2 ) {}
   var next = asmdClampVerticalScroll(
      cur - asmdWheelScrollStep( delta, asmdSettingsLineHeight( scroll ) ), maxY );
   try
   {
      scroll.verticalScrollPosition = next;
   }
   catch ( e3 ) {}
   asmdMoveScrolledPane( pane, next );
}

function asmdAttachWheelScroll( ctrl, scroll, pane )
{
   if ( !ctrl || !scroll || asmdControlConsumesWheel( ctrl ) )
      return;
   try
   {
      if ( ("_asmdWheelScroll" in ctrl) && ctrl._asmdWheelScroll )
         return;
      if ( ("onMouseWheel" in ctrl) && ctrl.onMouseWheel )
         return;
      ctrl.onMouseWheel = function( x, y, delta, buttons, modifiers )
      {
         asmdScrollByWheel( scroll, pane, delta );
      };
      ctrl._asmdWheelScroll = true;
   }
   catch ( e ) {}
}

function asmdBindChildWheel( ctrl, prop, scroll, pane )
{
   try
   {
      if ( ctrl && (prop in ctrl) && ctrl[prop] && typeof ctrl[prop] == "object" )
         asmdAttachWheelScroll( ctrl[prop], scroll, pane );
   }
   catch ( e ) {}
}

// Bind the control, and for compound controls bind only the parts that do
// not use the wheel (a NumericControl label, a section title, a checkbox).
function asmdIsNumericControl( ctrl )
{
   if ( typeof NumericControl == "function" && asmdIsInstance( ctrl, NumericControl ) )
      return true;
   // Slider plus a value label is a NumericControl even if instanceof
   // is unavailable. The slider keeps the wheel; the caption scrolls.
   return asmdHas( ctrl, "slider" ) && asmdHas( ctrl, "setValue" ) && asmdHas( ctrl, "label" );
}

function asmdBindSettingsWheel( ctrl, scroll, pane )
{
   if ( !ctrl || !scroll )
      return;
   if ( asmdIsNumericControl( ctrl ) )
   {
      asmdBindChildWheel( ctrl, "label", scroll, pane );
      return;
   }
   if ( typeof SectionBar == "function" && asmdIsInstance( ctrl, SectionBar ) )
   {
      asmdAttachWheelScroll( ctrl, scroll, pane );
      asmdBindChildWheel( ctrl, "label", scroll, pane );
      asmdBindChildWheel( ctrl, "title", scroll, pane );
      asmdBindChildWheel( ctrl, "titleLabel", scroll, pane );
      asmdBindChildWheel( ctrl, "title_Label", scroll, pane );
      asmdBindChildWheel( ctrl, "checkBox", scroll, pane );
      asmdBindChildWheel( ctrl, "button", scroll, pane );
      return;
   }
   if ( typeof NumericEdit == "function" && asmdIsInstance( ctrl, NumericEdit ) )
   {
      asmdAttachWheelScroll( ctrl, scroll, pane );
      asmdBindChildWheel( ctrl, "label", scroll, pane );
      return;
   }
   asmdAttachWheelScroll( ctrl, scroll, pane );
}

function asmdPushWheelTarget( dlg, ctrl )
{
   if ( !dlg || !ctrl )
      return;
   if ( !dlg._asmdWheelTargets )
      dlg._asmdWheelTargets = [];
   dlg._asmdWheelTargets.push( ctrl );
}

// Names of controls that live in the right-hand settings column. TreeBox,
// ComboBox, SpinBox, Edit, and NumericControl are included so the installer
// sees them and leaves their wheel alone.
function asmdSettingsWheelNames()
{
   return [
      "rightPane",
      "licenseBanner_Label",
      "mode_Control",
      "modeSingle_Radio",
      "modeCarousel_Radio",
      "images_Group",
      "images_Tree",
      "targets_Group",
      "targets_Tree",
      "add_Button",
      "edit_Button",
      "delete_Button",
      "all_Button",
      "none_Button",
      "carousel_Group",
      "carPlatform_Combo",
      "carShape_Combo",
      "carCustom_Control",
      "carW_Spin",
      "carH_Spin",
      "carNote_Control",
      "carNote_Label",
      "carMaxMB_Edit",
      "carLayout_Combo",
      "carPanels_Spin",
      "carAddLayout_Button",
      "car_Tree",
      "carTotal_Label",
      "carButtons_Control",
      "carAddDetail_Button",
      "carSelect_Button",
      "carUp_Button",
      "carDown_Button",
      "carRemove_Button",
      "carOther_Control",
      "carOther_Combo",
      "carFit_Check",
      "carAddOther_Button",
      "carWm_Combo",
      "carTemplate_Edit",
      "carExample_Label",
      "output_Group",
      "outDir_Edit",
      "outDir_Button",
      "imgDir_Button",
      "social_Button",
      "baseName_Edit",
      "template_Control",
      "template_Edit",
      "example_Control",
      "example_Label",
      "subfolder_Check",
      "overwrite_Check",
      "processing_Section",
      "processing_Control",
      "interp_Combo",
      "sharpenEnable_Check",
      "sharpen_Control",
      "upscale_Control",
      "noUpscale_Check",
      "upscaleHint_Label",
      "jpegProcessing_Control",
      "jpegQuality_Spin",
      "jpegQuality_Label",
      "wm_Section",
      "wm_Control",
      "wmMode_Combo",
      "wmText_Edit",
      "wmLogo_Control",
      "wmLogo_Edit",
      "wmLogo_Button",
      "logoHint_Label",
      "wmCorner_Combo",
      "wmOpacity_Control",
      "wmSize_Control"
   ];
}

// On Windows the wheel is delivered to the control under the pointer, not
// to the ScrollBox. Wire the viewport and every child that does not use
// the wheel, so labels, section bars, and group boxes scroll the column.
function asmdInstallSettingsWheel( dlg )
{
   if ( !dlg || !dlg.right_Scroll )
      return;
   var scroll = dlg.right_Scroll;
   var pane = dlg.rightPane;
   var vp = null;
   try
   {
      if ( ("viewport" in scroll) && scroll.viewport )
         vp = scroll.viewport;
   }
   catch ( e ) {}
   asmdAttachWheelScroll( vp, scroll, pane );
   var names = asmdSettingsWheelNames();
   var i;
   for ( i = 0; i < names.length; ++i )
   {
      var key = names[i];
      try
      {
         if ( (key in dlg) && dlg[key] )
            asmdBindSettingsWheel( dlg[key], scroll, pane );
      }
      catch ( e2 ) {}
   }
   var extras = null;
   try
   {
      if ( ("_asmdWheelTargets" in dlg) && dlg._asmdWheelTargets )
         extras = dlg._asmdWheelTargets;
   }
   catch ( e3 ) {}
   if ( !extras )
      return;
   for ( i = 0; i < extras.length; ++i )
      asmdBindSettingsWheel( extras[i], scroll, pane );
}

function asmdControlHeight( ctrl )
{
   var h = 0;
   if ( !ctrl )
      return 0;
   try
   {
      if ( ("visible" in ctrl) && ctrl.visible === false )
         return 0;
   }
   catch ( x ) {}
   try
   {
      if ( ("sizeHint" in ctrl) && ctrl.sizeHint && ("height" in ctrl.sizeHint) &&
           ctrl.sizeHint.height > 0 )
         h = ctrl.sizeHint.height;
   }
   catch ( x ) {}
   try
   {
      if ( ("minHeight" in ctrl) && ctrl.minHeight > h )
         h = ctrl.minHeight;
   }
   catch ( x ) {}
   try
   {
      if ( ctrl.height > h )
         h = ctrl.height;
   }
   catch ( x ) {}
   return h;
}

function asmdChromeHeight( dlg )
{
   var titleH = asmdControlHeight( dlg.title_Label );
   var actionH = asmdControlHeight( dlg.action_Control );
   var modeH = asmdControlHeight( dlg.exportMode_Control );
   var jobsH = asmdControlHeight( dlg.jobs_Control );
   if ( !(titleH > 0) )
      titleH = asmdScaledPx( dlg, 24 );
   if ( !(actionH > 0) )
      actionH = asmdScaledPx( dlg, 32 );
   // Dialog sizer: margin 6+6 and spacing 6 between title, mode, jobs, main, actions.
   var items = 3;
   if ( modeH > 0 )
      items += 1;
   if ( jobsH > 0 )
      items += 1;
   return titleH + actionH + modeH + jobsH + asmdScaledPx( dlg, 6 ) * (items - 1) + asmdScaledPx( dlg, 12 );
}

function asmdRightPaneContentHeight( dlg )
{
   if ( !dlg.rightPane )
      return 0;
   var measureW = asmdScaledPx( dlg, 460 );
   try
   {
      if ( dlg.right_Scroll && dlg.right_Scroll.minWidth > measureW )
         measureW = dlg.right_Scroll.minWidth;
   }
   catch ( x ) {}
   try
   {
      var vw = asmdScrollContentWidth( dlg, dlg.right_Scroll );
      if ( vw > measureW )
         measureW = vw;
   }
   catch ( x ) {}
   try
   {
      dlg.rightPane.setFixedWidth( measureW );
   }
   catch ( x )
   {
      try { dlg.rightPane.width = measureW; } catch ( y ) {}
   }
   try
   {
      dlg.rightPane.adjustToContents();
   }
   catch ( x ) {}
   return asmdControlHeight( dlg.rightPane );
}

function asmdPreferredDialogSize( dlg )
{
   var cap = asmdDialogCap( dlg );
   dlg.dialogCapW = cap.w;
   dlg.dialogCapH = cap.h;
   var paneH = asmdRightPaneContentHeight( dlg );
   var chromeH = asmdChromeHeight( dlg );
   var pad = asmdFitSafetyMargin( dlg, dlg.right_Scroll );
   var wantH = paneH + chromeH + pad;
   if ( !(wantH > 0) )
      wantH = asmdScaledPx( dlg, 800 );
   var wantW = asmdScaledPx( dlg, 1280 );
   var minSz = asmdDialogMinimumSize( dlg );
   var minW = asmdScaledPx( dlg, 700 ) + asmdScaledPx( dlg, 460 ) + asmdScaledPx( dlg, 20 );
   if ( wantW < minW )
      wantW = minW;
   if ( wantW < minSz.w )
      wantW = minSz.w;
   if ( wantH < minSz.h )
      wantH = minSz.h;
   if ( wantW > cap.w )
      wantW = cap.w;
   if ( wantH > cap.h )
      wantH = cap.h;
   return {
      w: wantW, h: wantH, capW: cap.w, capH: cap.h,
      paneH: paneH, chromeH: chromeH,
      needsScroll: (paneH + chromeH > cap.h),
      pad: pad
   };
}

// Size the dialog to the settings column, up to the screen cap.
// allowShrink is true only on the first show. After that, the window
// may grow (up to the cap) when the content needs it, but it is never
// shrunk below the current size, so a manual resize is kept.
// It is also never shrunk below the 1100 x 750 floor (clamped to the screen).
// A saved size is used on the first show when it still fits that floor.
function asmdFitDialogSize( dlg, allowShrink )
{
   if ( ("_asmdFitting" in dlg) && dlg._asmdFitting )
      return asmdPreferredDialogSize( dlg );
   dlg._asmdFitting = true;
   try
   {
      var pref = asmdPreferredDialogSize( dlg );
      var floor = asmdDialogMinimumSize( dlg );
      var w = pref.w, h = pref.h;
      if ( allowShrink )
      {
         var saved = asmdSavedWindowSize( dlg );
         if ( saved )
         {
            w = saved.w;
            h = saved.h;
         }
      }
      if ( w < floor.w )
         w = floor.w;
      if ( h < floor.h )
         h = floor.h;
      if ( !allowShrink )
      {
         var curW = 0, curH = 0;
         try
         {
            curW = dlg.width;
            curH = dlg.height;
         }
         catch ( x ) {}
         if ( curW > w )
            w = curW;
         if ( curH > h )
            h = curH;
      }
      if ( w > pref.capW )
         w = pref.capW;
      if ( h > pref.capH )
         h = pref.capH;
      if ( w < floor.w )
         w = Math.min( floor.w, pref.capW );
      if ( h < floor.h )
         h = Math.min( floor.h, pref.capH );
      try
      {
         if ( "setMaxWidth" in dlg )
            dlg.setMaxWidth( pref.capW );
         if ( "setMaxHeight" in dlg )
            dlg.setMaxHeight( pref.capH );
      }
      catch ( x ) {}
      dlg._asmdWantW = w;
      dlg._asmdWantH = h;
      asmdResizeDialog( dlg, w, h );
      if ( allowShrink )
         asmdRestoreWindowPosition( dlg );
      if ( dlg.updateSettingsScroll )
         dlg.updateSettingsScroll();
      asmdSettleSettingsScroll( dlg );
      return pref;
   }
   finally
   {
      dlg._asmdFitting = false;
   }
}

// If the window opened below the floor (adjustToContents, or a size hint
// applied after resize), grow it back to the size chosen above. A window
// that is already at or above the floor is left alone, including a manual
// resize.
function asmdEnsureDialogSize( dlg )
{
   if ( !dlg || (("_asmdEnsuring" in dlg) && dlg._asmdEnsuring) )
      return;
   var floor = asmdDialogMinimumSize( dlg );
   var cap = asmdDialogCap( dlg );
   var w = 0, h = 0;
   try
   {
      w = dlg.width;
      h = dlg.height;
   }
   catch ( x ) {}
   if ( w >= floor.w && h >= floor.h )
      return;
   var wantW = (("_asmdWantW" in dlg) && dlg._asmdWantW > 0) ? dlg._asmdWantW : floor.w;
   var wantH = (("_asmdWantH" in dlg) && dlg._asmdWantH > 0) ? dlg._asmdWantH : floor.h;
   if ( w < floor.w )
      w = wantW;
   if ( h < floor.h )
      h = wantH;
   if ( w < floor.w )
      w = floor.w;
   if ( h < floor.h )
      h = floor.h;
   if ( w > cap.w )
      w = cap.w;
   if ( h > cap.h )
      h = cap.h;
   asmdResizeDialog( dlg, w, h );
}

function asmdDialogPosition( dlg )
{
   var x = 0, y = 0, ok = false;
   try
   {
      if ( dlg && ("position" in dlg) && dlg.position )
      {
         var p = dlg.position;
         if ( p && ("x" in p) && ("y" in p) )
         {
            x = p.x;
            y = p.y;
            ok = (x == x) && (y == y);
         }
      }
   }
   catch ( e ) {}
   if ( !ok )
   {
      try
      {
         if ( dlg && ("x" in dlg) && ("y" in dlg) )
         {
            x = dlg.x;
            y = dlg.y;
            ok = (x == x) && (y == y);
         }
      }
      catch ( e2 ) {}
   }
   return { x: x, y: y, ok: ok };
}

function asmdReadWindowGeometry()
{
   var w = asmdReadSetting( "windowWidth", DataType_Int32, 0 );
   var h = asmdReadSetting( "windowHeight", DataType_Int32, 0 );
   var x = 0, y = 0, hasPos = false;
   try
   {
      var px = Settings.read( ASMD_SETTINGS_KEY + "/windowX", DataType_Int32 );
      if ( Settings.lastReadOK && px == px )
      {
         var py = Settings.read( ASMD_SETTINGS_KEY + "/windowY", DataType_Int32 );
         if ( Settings.lastReadOK && py == py )
         {
            x = Number( px );
            y = Number( py );
            hasPos = true;
         }
      }
   }
   catch ( e ) {}
   return { w: Number( w ) || 0, h: Number( h ) || 0, x: x, y: y, hasPos: hasPos };
}

// A saved size is valid when it is at least the floor and not larger than
// the current screen cap. Anything else (the old tiny window, or a size
// from a bigger monitor) is ignored and the default size is used.
function asmdWindowSizeValid( dlg, geo )
{
   if ( !geo )
      return false;
   var floor = asmdDialogMinimumSize( dlg );
   var cap = asmdDialogCap( dlg );
   if ( !(geo.w >= floor.w) || !(geo.h >= floor.h) )
      return false;
   if ( geo.w > cap.w || geo.h > cap.h )
      return false;
   return true;
}

function asmdWindowPositionValid( dlg, geo )
{
   if ( !geo || !geo.hasPos )
      return false;
   var s = asmdScreenRect( dlg );
   if ( !(s.w >= 400) || !(s.h >= 400) )
      return false;
   var ww = geo.w, hh = geo.h;
   if ( !(ww > 0) || !(hh > 0) )
      return false;
   // Keep the title bar on the screen, with some of the window visible.
   if ( geo.x + ww < s.x + 80 )
      return false;
   if ( geo.y < s.y )
      return false;
   if ( geo.x > s.x + s.w - 80 )
      return false;
   if ( geo.y > s.y + s.h - 80 )
      return false;
   return true;
}

function asmdSavedWindowSize( dlg )
{
   var geo = asmdReadWindowGeometry();
   if ( !asmdWindowSizeValid( dlg, geo ) )
      return null;
   return geo;
}

function asmdRestoreWindowPosition( dlg )
{
   var geo = asmdReadWindowGeometry();
   if ( !asmdWindowSizeValid( dlg, geo ) || !asmdWindowPositionValid( dlg, geo ) )
      return;
   try
   {
      if ( "move" in dlg )
         dlg.move( geo.x, geo.y );
      else
      {
         dlg.x = geo.x;
         dlg.y = geo.y;
      }
   }
   catch ( e ) {}
}

function asmdSaveWindowGeometry( dlg )
{
   if ( !dlg )
      return;
   var w = 0, h = 0;
   try
   {
      w = Math.round( dlg.width );
      h = Math.round( dlg.height );
   }
   catch ( e ) {}
   if ( !(w > 0) || !(h > 0) )
      return;
   asmdWriteSetting( "windowWidth", DataType_Int32, w );
   asmdWriteSetting( "windowHeight", DataType_Int32, h );
   var pos = asmdDialogPosition( dlg );
   if ( pos.ok )
   {
      asmdWriteSetting( "windowX", DataType_Int32, Math.round( pos.x ) );
      asmdWriteSetting( "windowY", DataType_Int32, Math.round( pos.y ) );
   }
}

// Keep the preview from collapsing. 400 logical pixels when the screen
// has room; otherwise whatever is left under the title, buttons, and the
// status line, so the dialog can still fit the cap.
function asmdApplyPreviewMin( dlg )
{
   if ( !dlg || !dlg.preview )
      return;
   var w = asmdScaledPx( dlg, ASMD_PREVIEW_MIN_W );
   var h = asmdScaledPx( dlg, ASMD_PREVIEW_MIN_H );
   var cap = asmdDialogCap( dlg );
   var chrome = asmdChromeHeight( dlg );
   var info = asmdScaledPx( dlg, ASMD_CROPINFO_MIN_H );
   var buttons = asmdScaledPx( dlg, 32 );
   var gaps = asmdScaledPx( dlg, 24 );
   var room = cap.h - chrome - info - buttons - gaps;
   if ( room > 0 && h > room )
      h = room;
   if ( !(h > 0) )
      h = 1;
   var logicalH = ASMD_PREVIEW_MIN_H;
   var fullH = asmdScaledPx( dlg, ASMD_PREVIEW_MIN_H );
   if ( fullH > 0 && h < fullH )
      logicalH = Math.max( 80, Math.round( ASMD_PREVIEW_MIN_H * h / fullH ) );
   try { dlg.preview.setScaledMinSize( ASMD_PREVIEW_MIN_W, logicalH ); } catch ( e ) {}
   try { dlg.preview.setMinWidth( w ); } catch ( e2 ) {}
   try { dlg.preview.setMinHeight( h ); } catch ( e3 ) {}
}

// After the dialog is shown, the real viewport can be a few pixels
// shorter than the estimate (Windows scaling, ScrollBox frame). If the
// leftover is small and there is room under the cap, grow to hide it.
function asmdSettleSettingsScroll( dlg )
{
   if ( !dlg || (("_asmdSettling" in dlg) && dlg._asmdSettling) )
      return;
   dlg._asmdSettling = true;
   try
   {
      if ( dlg.updateSettingsScroll )
         dlg.updateSettingsScroll();
      var scroll = dlg.right_Scroll;
      var pane = dlg.rightPane;
      if ( !scroll || !pane )
         return;
      var vh = 0, ph = 0;
      try
      {
         var vp = (("viewport" in scroll) && scroll.viewport) ? scroll.viewport : null;
         vh = vp ? vp.height : scroll.height;
         ph = pane.height;
      }
      catch ( x ) {}
      var slack = ph - vh;
      var growLimit = asmdScaledPx( dlg, 40 );
      if ( slack > 0 && slack <= growLimit )
      {
         var curH = 0, curW = 0;
         try
         {
            curH = dlg.height;
            curW = dlg.width;
         }
         catch ( x ) {}
         var cap = asmdDialogCap( dlg );
         if ( curH > 0 && curH < cap.h )
         {
            var newH = curH + slack + asmdFitSafetyMargin( dlg, scroll );
            if ( newH > cap.h )
               newH = cap.h;
            if ( newH > curH )
               asmdResizeDialog( dlg, curW > 0 ? curW : cap.w, newH );
         }
      }
      if ( dlg.updateSettingsScroll )
         dlg.updateSettingsScroll();
   }
   finally
   {
      dlg._asmdSettling = false;
   }
}

// Background box for a grid or panorama tile number, placed at the
// bottom center of the tile and clamped inside the tile and the
// visible image view so top-row numbers stay on screen.
function asmdTileLabelBox( tileX0, tileY0, tileX1, tileY1, textW, fontH, viewX0, viewY0, viewX1, viewY1 )
{
   var padX = 4, padY = 2, inset = 8, edge = 3;
   var boxW = textW + padX*2;
   var boxH = fontH + padY*2;
   if ( boxW < 8 )
      boxW = 8;
   if ( boxH < 8 )
      boxH = 8;
   var bx = Math.round( tileX0 + (tileX1 - tileX0 - boxW)/2 );
   var by = Math.round( tileY1 - inset - boxH );
   var minX = tileX0 + edge, minY = tileY0 + edge;
   var maxX = tileX1 - edge - boxW, maxY = tileY1 - edge - boxH;
   if ( viewX0 + 1 > minX ) minX = viewX0 + 1;
   if ( viewY0 + 1 > minY ) minY = viewY0 + 1;
   if ( viewX1 - 1 - boxW < maxX ) maxX = viewX1 - 1 - boxW;
   if ( viewY1 - 1 - boxH < maxY ) maxY = viewY1 - 1 - boxH;
   if ( maxX < minX )
      bx = minX;
   else
   {
      if ( bx < minX ) bx = minX;
      if ( bx > maxX ) bx = maxX;
   }
   if ( maxY < minY )
      by = minY;
   else
   {
      if ( by < minY ) by = minY;
      if ( by > maxY ) by = maxY;
   }
   return { x: bx, y: by, w: boxW, h: boxH, padX: padX, padY: padY };
}

// Crop map key: each open image keeps its own crop per preset.
function asmdCropKey( imageId, presetId )
{
   return String( imageId ) + "\t" + String( presetId );
}

function asmdBatchProgressText( imageIndex, imageCount, presetIndex, presetCount )
{
   return "Image " + imageIndex + " of " + imageCount + ", preset " + presetIndex +
          " of " + presetCount;
}

// Ordered jobs for a single-export batch: checked images (source only if
// unlicensed) times checked presets (Instagram only if unlicensed).
function asmdBatchExportPlan( images, presets, licensed )
{
   var imgs = [], pres = [], plan = [], i, j;
   for ( i = 0; i < images.length; ++i )
   {
      if ( !images[i].checked )
         continue;
      if ( !licensed && !images[i].isSource )
         continue;
      imgs.push( images[i] );
   }
   for ( j = 0; j < presets.length; ++j )
   {
      if ( !presets[j].enabled )
         continue;
      if ( !licensed && !asmdPresetIsFree( presets[j] ) )
         continue;
      pres.push( presets[j] );
   }
   for ( i = 0; i < imgs.length; ++i )
      for ( j = 0; j < pres.length; ++j )
         plan.push( {
            imageId:     imgs[i].id,
            baseName:    imgs[i].baseName,
            isSource:    !!imgs[i].isSource,
            window:      imgs[i].window,
            w:           imgs[i].w,
            h:           imgs[i].h,
            preset:      pres[j],
            imageIndex:  i + 1,
            imageCount:  imgs.length,
            presetIndex: j + 1,
            presetCount: pres.length
         } );
   return plan;
}

// One file per checked image, using the whole frame. Licensed callers pass
// every checked image. The free version keeps the current image only.
function asmdWholeImagePlan( images, licensed, preset )
{
   var imgs = [], plan = [], i;
   for ( i = 0; i < images.length; ++i )
   {
      if ( !images[i].checked )
         continue;
      if ( !licensed && !images[i].isSource )
         continue;
      imgs.push( images[i] );
   }
   for ( i = 0; i < imgs.length; ++i )
      plan.push( {
         imageId:     imgs[i].id,
         baseName:    imgs[i].baseName,
         isSource:    !!imgs[i].isSource,
         window:      imgs[i].window,
         w:           imgs[i].w,
         h:           imgs[i].h,
         preset:      preset,
         imageIndex:  i + 1,
         imageCount:  imgs.length,
         presetIndex: 1,
         presetCount: 1
      } );
   return plan;
}

// One JPEG per checked image, at the full frame, fit to maxKB. Licensed only.
function asmdFullFramePlan( images, licensed, maxKB )
{
   return asmdWholeImagePlan( images, licensed, {
      id: "full-frame", name: "Full frame", platform: "Full-Frame",
      width: 0, height: 0, ratio: "native", longEdge: 0,
      maxKB: maxKB, format: "JPEG", sharpen: true, enabled: true, builtIn: false
   } );
}

// Logo only: one file per checked image, whole frame, no preset crop.
// format is SOURCE, JPEG, or PNG. Fit-to-size is decided by the runtime options.
function asmdLogoOnlyPlan( images, licensed, format, maxKB )
{
   var fmt = "JPEG";
   if ( format == "PNG" )
      fmt = "PNG";
   else if ( format == "SOURCE" )
      fmt = "SOURCE";
   return asmdWholeImagePlan( images, licensed, {
      id: "logo-only", name: "Logo only", platform: "Logo",
      width: 0, height: 0, ratio: "native", longEdge: 0,
      maxKB: maxKB, format: fmt, sharpen: false, enabled: true, builtIn: false
   } );
}

function asmdCollectOpenImages( srcWindow )
{
   var list = [];
   if ( !srcWindow || srcWindow.isNull )
      return list;
   var srcPath = srcWindow.filePath;
   var hasFile = (srcPath && srcPath.length > 0);
   var srcName = hasFile ? File.extractName( srcPath ) : srcWindow.mainView.id;
   list.push( {
      id:       srcWindow.mainView.id,
      window:   srcWindow,
      w:        srcWindow.mainView.image.width,
      h:        srcWindow.mainView.image.height,
      checked:  true,
      baseName: asmdSafeFileToken( srcName ),
      isSource: true
   } );
   try
   {
      var wins = ImageWindow.windows;
      for ( var i = 0; i < wins.length; ++i )
      {
         if ( !wins[i] || wins[i].isNull )
            continue;
         if ( wins[i].mainView.id == srcWindow.mainView.id )
            continue;
         var im = wins[i].mainView.image;
         if ( im.width < 16 || im.height < 16 )
            continue;
         var wpath = wins[i].filePath;
         var hasW = (wpath && wpath.length > 0);
         var wname = hasW ? File.extractName( wpath ) : wins[i].mainView.id;
         list.push( {
            id:       wins[i].mainView.id,
            window:   wins[i],
            w:        im.width,
            h:        im.height,
            checked:  false,
            baseName: asmdSafeFileToken( wname ),
            isSource: false
         } );
      }
   }
   catch ( x ) {}
   return list;
}

var ASMD_PRODUCT_ID   = "AstroMD-SocialExport";
var ASMD_CREDIT_TEXT  = "AstroMD Social Export";
var ASMD_LICENSE      = { email: "", key: "" };

// ---------------------------------------------------------------------------
// License keys (offline HMAC-SHA256). PJSR has CryptographicHash, but a pure
// implementation is used so the Node keygen and the script always agree.
// The pepper is stored as an obfuscated byte list, not as a literal string.
// ---------------------------------------------------------------------------

function asmdRotr( x, n )
{
   return ((x >>> n) | (x << (32 - n))) >>> 0;
}

function asmdUtf8Bytes( str )
{
   var s = String( str || "" ), out = [], i, c, c2, u;
   for ( i = 0; i < s.length; ++i )
   {
      c = s.charCodeAt( i );
      if ( c < 128 )
         out.push( c );
      else if ( c < 2048 )
         out.push( 192 | (c >> 6), 128 | (c & 63) );
      else if ( c >= 55296 && c <= 56319 && i + 1 < s.length )
      {
         c2 = s.charCodeAt( ++i );
         u = 65536 + ((c & 1023) << 10) + (c2 & 1023);
         out.push( 240 | (u >> 18), 128 | ((u >> 12) & 63),
                   128 | ((u >> 6) & 63), 128 | (u & 63) );
      }
      else
         out.push( 224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63) );
   }
   return out;
}

function asmdSha256Bytes( bytes )
{
   var K = [
      0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
      0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
      0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
      0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
      0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
      0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
      0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
      0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
   ];
   var H = [ 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 ];
   var len = bytes.length;
   var bitLenHi = Math.floor( len / 536870912 );
   var bitLenLo = (len * 8) >>> 0;
   var padded = [];
   var i;
   for ( i = 0; i < len; ++i )
      padded.push( bytes[i] & 255 );
   padded.push( 128 );
   while ( (padded.length % 64) != 56 )
      padded.push( 0 );
   padded.push( (bitLenHi >>> 24) & 255, (bitLenHi >>> 16) & 255, (bitLenHi >>> 8) & 255, bitLenHi & 255,
                (bitLenLo >>> 24) & 255, (bitLenLo >>> 16) & 255, (bitLenLo >>> 8) & 255, bitLenLo & 255 );

   var w = new Array( 64 ), a, b, c, d, e, f, g, h, t1, t2, s0, s1, ch, maj, off;
   for ( off = 0; off < padded.length; off += 64 )
   {
      for ( i = 0; i < 16; ++i )
         w[i] = ((padded[off + 4*i] << 24) | (padded[off + 4*i + 1] << 16) |
                 (padded[off + 4*i + 2] << 8) | padded[off + 4*i + 3]) >>> 0;
      for ( i = 16; i < 64; ++i )
      {
         s0 = asmdRotr( w[i - 15], 7 ) ^ asmdRotr( w[i - 15], 18 ) ^ (w[i - 15] >>> 3);
         s1 = asmdRotr( w[i - 2], 17 ) ^ asmdRotr( w[i - 2], 19 ) ^ (w[i - 2] >>> 10);
         w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      a = H[0]; b = H[1]; c = H[2]; d = H[3]; e = H[4]; f = H[5]; g = H[6]; h = H[7];
      for ( i = 0; i < 64; ++i )
      {
         s1 = asmdRotr( e, 6 ) ^ asmdRotr( e, 11 ) ^ asmdRotr( e, 25 );
         ch = (e & f) ^ ((~e) & g);
         t1 = (h + s1 + ch + K[i] + w[i]) >>> 0;
         s0 = asmdRotr( a, 2 ) ^ asmdRotr( a, 13 ) ^ asmdRotr( a, 22 );
         maj = (a & b) ^ (a & c) ^ (b & c);
         t2 = (s0 + maj) >>> 0;
         h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
      H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
   }
   var out = [];
   for ( i = 0; i < 8; ++i )
      out.push( (H[i] >>> 24) & 255, (H[i] >>> 16) & 255, (H[i] >>> 8) & 255, H[i] & 255 );
   return out;
}

function asmdBytesToHex( bytes )
{
   var hex = "0123456789abcdef", s = "", i, b;
   for ( i = 0; i < bytes.length; ++i )
   {
      b = bytes[i] & 255;
      s += hex.charAt( b >> 4 ) + hex.charAt( b & 15 );
   }
   return s;
}

function asmdHmacSha256( keyBytes, msgBytes )
{
   var block = 64, i, k = keyBytes.slice( 0 );
   if ( k.length > block )
      k = asmdSha256Bytes( k );
   while ( k.length < block )
      k.push( 0 );
   var ipad = [], opad = [];
   for ( i = 0; i < block; ++i )
   {
      ipad.push( k[i] ^ 0x36 );
      opad.push( k[i] ^ 0x5c );
   }
   return asmdSha256Bytes( opad.concat( asmdSha256Bytes( ipad.concat( msgBytes ) ) ) );
}

function asmdLicensePepperBytes()
{
   var a = [ 0x17, 0x15, 0xA5, 0x25, 0xF3, 0xC6, 0x51, 0x9B, 0xD9, 0x2E, 0xEB, 0x3C, 0x22, 0xD7, 0x72, 0x48,
             0x14, 0x7E, 0xAE, 0x81, 0xD7, 0x81, 0x8B, 0xC8, 0x98, 0x89, 0x8C, 0xB4, 0xDB, 0x84, 0x9A, 0x4A ];
   var i, out = [];
   for ( i = 0; i < a.length; ++i )
      out.push( (a[i] ^ (0x5C ^ ((i * 13 + 7) & 0xFF))) & 255 );
   return out;
}

function asmdNormalizeEmail( email )
{
   var s = asmdTrim( String( email || "" ) ).toLowerCase();
   s = s.replace( /\s+/g, "" );
   return s;
}

function asmdCanonicalLicenseKey( key )
{
   var t = asmdTrim( String( key || "" ) ).toUpperCase();
   if ( t.indexOf( "ASMD-" ) == 0 )
      t = t.substring( 5 );
   t = t.split( "-" ).join( "" );
   if ( t.length != 16 )
      return "";
   var i, c, hex = "0123456789ABCDEF";
   for ( i = 0; i < 16; ++i )
   {
      c = t.charAt( i );
      if ( hex.indexOf( c ) < 0 )
         return "";
   }
   return "ASMD-" + t.substring( 0, 4 ) + "-" + t.substring( 4, 8 ) + "-" +
          t.substring( 8, 12 ) + "-" + t.substring( 12, 16 );
}

function asmdMakeLicenseKey( email )
{
   var em = asmdNormalizeEmail( email );
   if ( em.length == 0 || em.indexOf( "@" ) < 1 || em.indexOf( "@" ) == em.length - 1 )
      return "";
   var mac = asmdHmacSha256( asmdLicensePepperBytes(), asmdUtf8Bytes( em + "|" + ASMD_PRODUCT_ID ) );
   var hex = asmdBytesToHex( mac ).substring( 0, 16 ).toUpperCase();
   return "ASMD-" + hex.substring( 0, 4 ) + "-" + hex.substring( 4, 8 ) + "-" +
          hex.substring( 8, 12 ) + "-" + hex.substring( 12, 16 );
}

function asmdLicenseValid( email, key )
{
   var expect = asmdMakeLicenseKey( email );
   var got = asmdCanonicalLicenseKey( key );
   return expect.length > 0 && got.length > 0 && got == expect;
}

function asmdLoadLicense()
{
   ASMD_LICENSE.email = asmdReadSetting( "licenseEmail", DataType_String, "" );
   ASMD_LICENSE.key   = asmdReadSetting( "licenseKey",   DataType_String, "" );
}

function asmdSaveLicense( email, key )
{
   ASMD_LICENSE.email = email;
   ASMD_LICENSE.key = key;
   asmdWriteSetting( "licenseEmail", DataType_String, email );
   asmdWriteSetting( "licenseKey",   DataType_String, key );
}

function asmdClearLicense()
{
   asmdSaveLicense( "", "" );
}

function asmdIsLicensed()
{
   return asmdLicenseValid( ASMD_LICENSE.email, ASMD_LICENSE.key );
}

function asmdLicensedEmail()
{
   return asmdIsLicensed() ? asmdNormalizeEmail( ASMD_LICENSE.email ) : "";
}

function asmdPresetIsFree( p )
{
   if ( !p || !p.builtIn )
      return false;
   var id = String( p.id || "" );
   return id.length >= 3 && id.substring( 0, 3 ) == "ig-";
}

function asmdCopyOptions( opts )
{
   var o = {}, k;
   for ( k in opts )
      if ( opts.hasOwnProperty( k ) && typeof opts[k] != "function" )
         o[k] = opts[k];
   return o;
}

// Forced credit used on every free-version export. Does not change saved settings.
function asmdApplyFreeExportOptions( opts )
{
   var o = asmdCopyOptions( opts );
   o.wmEnabled     = true;
   o.wmMode        = 0;
   o.wmText        = ASMD_CREDIT_TEXT;
   o.wmCorner      = 3;
   o.wmOpacity     = 0.55;
   o.wmSizePercent = 2.5;
   o.wmLogoPath    = "";
   // The free credit stays. Full frame fit, logo only, and saved jobs stay locked.
   // JPEG quality is still the starting quality for the free Instagram export.
   o.exportMode    = 0;
   o.fullFrameFit  = false;
   o.logoOnly      = false;
   o.logoFit       = false;
   return o;
}

// Export-time copy. Logo only can fit to its own size target without
// replacing the full frame mode's saved target.
function asmdRuntimeOptions( opts, licensed )
{
   var o = licensed ? asmdCopyOptions( opts ) : asmdApplyFreeExportOptions( opts );
   if ( !licensed )
      return o;
   if ( o.exportMode == 1 )
   {
      o.fullFrameFit = true;
      o.logoOnly = false;
   }
   else if ( o.exportMode == 2 )
   {
      o.logoOnly = true;
      o.logoFormat = asmdStoredLogoFormat( o.logoFormat, "SOURCE" );
      if ( o.logoFit )
      {
         o.fullFrameFit = true;
         if ( o.logoMaxMB >= 0.05 )
            o.fullFrameMaxMB = o.logoMaxMB;
         o.fullFramePriority = (o.logoPriority == 1) ? 1 : 0;
         o.logoFormat = "JPEG";
      }
      else
         o.fullFrameFit = false;
   }
   else
   {
      o.exportMode = 0;
      o.fullFrameFit = false;
      o.logoOnly = false;
   }
   return o;
}


// Dialog options that persist between runs.
function AsmdOptions()
{
   this.load = function()
   {
      var d = ASMD_DEFAULTS;
      this.template          = asmdReadSetting( "template",          DataType_String,  d.template );
      this.subfolderPerImage = asmdReadSetting( "subfolderPerImage", DataType_Boolean, d.subfolderPerImage );
      this.overwrite         = asmdReadSetting( "overwrite",         DataType_Boolean, d.overwrite );
      this.noUpscale         = asmdReadSetting( "noUpscale",         DataType_Boolean, d.noUpscale );
      this.interpolation     = asmdReadSetting( "interpolation",     DataType_Int32,   d.interpolation );
      this.sharpenEnabled    = asmdReadSetting( "sharpenEnabled",    DataType_Boolean, d.sharpenEnabled );
      this.sharpenStrength   = asmdReadSetting( "sharpenStrength",   DataType_Double,  d.sharpenStrength );
      this.wmEnabled         = asmdReadSetting( "wmEnabled",         DataType_Boolean, d.wmEnabled );
      this.wmMode            = asmdReadSetting( "wmMode",            DataType_Int32,   d.wmMode );
      this.wmText            = asmdReadSetting( "wmText",            DataType_String,  d.wmText );
      this.wmLogoPath        = asmdReadSetting( "wmLogoPath",        DataType_String,  d.wmLogoPath );
      this.wmCorner          = asmdReadSetting( "wmCorner",          DataType_Int32,   d.wmCorner );
      this.wmOpacity         = asmdReadSetting( "wmOpacity",         DataType_Double,  d.wmOpacity );
      this.wmSizePercent     = asmdReadSetting( "wmSizePercent",     DataType_Double,  d.wmSizePercent );
      if ( this.interpolation < 0 || this.interpolation >= ASMD_INTERPOLATIONS.length )
         this.interpolation = 0;
      if ( this.wmCorner < 0 || this.wmCorner >= ASMD_CORNERS.length )
         this.wmCorner = 3;
      if ( this.wmMode != 1 )
         this.wmMode = 0;
      this.mode              = asmdReadSetting( "mode",              DataType_Int32,   d.mode );
      this.carShape          = asmdReadSetting( "carShape",          DataType_Int32,   d.carShape );
      this.carCustomW        = asmdReadSetting( "carCustomW",        DataType_Int32,   d.carCustomW );
      this.carCustomH        = asmdReadSetting( "carCustomH",        DataType_Int32,   d.carCustomH );
      this.carPanels         = asmdReadSetting( "carPanels",         DataType_Int32,   d.carPanels );
      this.carLayout         = asmdReadSetting( "carLayout",         DataType_Int32,   d.carLayout );
      this.carPlatform       = asmdReadSetting( "carPlatform",       DataType_Int32,   d.carPlatform );
      this.carWatermark      = asmdReadSetting( "carWatermark",      DataType_Int32,   d.carWatermark );
      this.carMaxKB          = asmdReadSetting( "carMaxKB",          DataType_Int32,   d.carMaxKB );
      this.carTemplate       = asmdReadSetting( "carTemplate",       DataType_String,  d.carTemplate );
      this.processingExpanded = asmdReadSetting( "processingExpanded", DataType_Boolean, d.processingExpanded );
      this.watermarkExpanded  = asmdReadSetting( "watermarkExpanded",  DataType_Boolean, d.watermarkExpanded );
      this.jpegQuality        = asmdClampJpegQuality( asmdReadSetting( "jpegQuality", DataType_Int32, d.jpegQuality ) );
      this.fullFrameFit       = asmdReadSetting( "fullFrameFit",       DataType_Boolean, d.fullFrameFit );
      this.fullFrameMaxMB     = asmdReadSetting( "fullFrameMaxMB",     DataType_Double,  d.fullFrameMaxMB );
      this.fullFramePriority  = asmdReadSetting( "fullFramePriority",  DataType_Int32,   d.fullFramePriority );
      this.logoOnly           = asmdReadSetting( "logoOnly",           DataType_Boolean, d.logoOnly );
      if ( !(this.fullFrameMaxMB >= 0.01) )
         this.fullFrameMaxMB = d.fullFrameMaxMB;
      if ( this.fullFramePriority != 1 )
         this.fullFramePriority = 0;
      this.logoFit            = asmdReadSetting( "logoFit",            DataType_Boolean, !!(this.logoOnly && this.fullFrameFit) );
      this.logoFormat         = asmdReadSetting( "logoFormat",         DataType_String,  d.logoFormat );
      this.logoMaxMB          = asmdReadSetting( "logoMaxMB",          DataType_Double,  this.fullFrameMaxMB );
      this.logoPriority       = asmdReadSetting( "logoPriority",       DataType_Int32,   this.fullFramePriority );
      this.logoFormat = asmdStoredLogoFormat( this.logoFormat, "SOURCE" );
      if ( !(this.logoMaxMB >= 0.05) )
         this.logoMaxMB = d.logoMaxMB;
      if ( this.logoPriority != 1 )
         this.logoPriority = 0;
      var storedMode = asmdReadSetting( "exportMode", DataType_Int32, -1 );
      this.exportMode = asmdNormalizeExportMode( storedMode, this.fullFrameFit, this.logoOnly );
      if ( this.mode != 1 )
         this.mode = 0;
      if ( this.carShape < 0 || this.carShape >= ASMD_CAROUSEL_SHAPES.length )
         this.carShape = 0;
      if ( this.carPanels < ASMD_CAROUSEL_MIN_PANELS || this.carPanels > ASMD_CAROUSEL_MAX_PANELS )
         this.carPanels = d.carPanels;
      if ( this.carLayout < 0 || this.carLayout >= ASMD_CAROUSEL_LAYOUTS.length )
         this.carLayout = d.carLayout;
      if ( this.carPlatform < 0 || this.carPlatform >= ASMD_CAROUSEL_PLATFORMS.length )
         this.carPlatform = d.carPlatform;
      if ( this.carWatermark < 0 || this.carWatermark >= ASMD_CAROUSEL_WATERMARKS.length )
         this.carWatermark = d.carWatermark;
      if ( !(this.carMaxKB >= 10) )
         this.carMaxKB = d.carMaxKB;
      if ( !(this.carCustomW >= 16) ) this.carCustomW = d.carCustomW;
      if ( !(this.carCustomH >= 16) ) this.carCustomH = d.carCustomH;
   };

   this.save = function()
   {
      asmdWriteSetting( "template",          DataType_String,  this.template );
      asmdWriteSetting( "subfolderPerImage", DataType_Boolean, this.subfolderPerImage );
      asmdWriteSetting( "overwrite",         DataType_Boolean, this.overwrite );
      asmdWriteSetting( "noUpscale",         DataType_Boolean, this.noUpscale );
      asmdWriteSetting( "interpolation",     DataType_Int32,   this.interpolation );
      asmdWriteSetting( "sharpenEnabled",    DataType_Boolean, this.sharpenEnabled );
      asmdWriteSetting( "sharpenStrength",   DataType_Double,  this.sharpenStrength );
      asmdWriteSetting( "wmEnabled",         DataType_Boolean, this.wmEnabled );
      asmdWriteSetting( "wmMode",            DataType_Int32,   this.wmMode );
      asmdWriteSetting( "wmText",            DataType_String,  this.wmText );
      asmdWriteSetting( "wmLogoPath",        DataType_String,  this.wmLogoPath );
      asmdWriteSetting( "wmCorner",          DataType_Int32,   this.wmCorner );
      asmdWriteSetting( "wmOpacity",         DataType_Double,  this.wmOpacity );
      asmdWriteSetting( "wmSizePercent",     DataType_Double,  this.wmSizePercent );
      asmdWriteSetting( "mode",              DataType_Int32,   this.mode );
      asmdWriteSetting( "carShape",          DataType_Int32,   this.carShape );
      asmdWriteSetting( "carCustomW",        DataType_Int32,   this.carCustomW );
      asmdWriteSetting( "carCustomH",        DataType_Int32,   this.carCustomH );
      asmdWriteSetting( "carPanels",         DataType_Int32,   this.carPanels );
      asmdWriteSetting( "carLayout",         DataType_Int32,   this.carLayout );
      asmdWriteSetting( "carPlatform",       DataType_Int32,   this.carPlatform );
      asmdWriteSetting( "carWatermark",      DataType_Int32,   this.carWatermark );
      asmdWriteSetting( "carMaxKB",          DataType_Int32,   this.carMaxKB );
      asmdWriteSetting( "carTemplate",       DataType_String,  this.carTemplate );
      asmdWriteSetting( "processingExpanded", DataType_Boolean, this.processingExpanded );
      asmdWriteSetting( "watermarkExpanded",  DataType_Boolean, this.watermarkExpanded );
      asmdWriteSetting( "jpegQuality",        DataType_Int32,   this.jpegQuality );
      asmdWriteSetting( "fullFrameFit",       DataType_Boolean, this.fullFrameFit );
      asmdWriteSetting( "fullFrameMaxMB",     DataType_Double,  this.fullFrameMaxMB );
      asmdWriteSetting( "fullFramePriority",  DataType_Int32,   this.fullFramePriority );
      asmdWriteSetting( "logoOnly",           DataType_Boolean, this.logoOnly );
      asmdWriteSetting( "exportMode",         DataType_Int32,   this.exportMode );
      asmdWriteSetting( "logoFit",            DataType_Boolean, this.logoFit );
      asmdWriteSetting( "logoFormat",         DataType_String,  this.logoFormat );
      asmdWriteSetting( "logoMaxMB",          DataType_Double,  this.logoMaxMB );
      asmdWriteSetting( "logoPriority",       DataType_Int32,   this.logoPriority );
   };

   this.load();
}

// Load the full preset list: built-ins first, then the user's custom
// presets (stored as one JSON string), with saved checkbox states applied.
function asmdLoadPresets()
{
   var list = [], i;
   for ( i = 0; i < ASMD_BUILTIN_PRESETS.length; ++i )
   {
      var b = asmdClonePreset( ASMD_BUILTIN_PRESETS[i] );
      b.builtIn = true;
      list.push( b );
   }

   var json = asmdReadSetting( "customPresets", DataType_String, "" );
   if ( json && json.length > 0 )
   {
      try
      {
         var custom = JSON.parse( json );
         for ( i = 0; i < custom.length; ++i )
         {
            var c = asmdClonePreset( custom[i] );
            c.builtIn = false;
            if ( c.id && c.name )
               list.push( c );
         }
      }
      catch ( x )
      {
         console.warningln( "** Saved custom presets could not be read and were ignored: " + x.message );
      }
   }

   var stateJson = asmdReadSetting( "enabledStates", DataType_String, "" );
   if ( stateJson && stateJson.length > 0 )
   {
      try
      {
         var states = JSON.parse( stateJson );
         for ( i = 0; i < list.length; ++i )
            if ( states.hasOwnProperty( list[i].id ) )
               list[i].enabled = !!states[list[i].id];
      }
      catch ( x ) {}
   }
   return list;
}

function asmdSavePresets( list )
{
   var custom = [], states = {};
   for ( var i = 0; i < list.length; ++i )
   {
      var p = list[i];
      states[p.id] = p.enabled;
      if ( !p.builtIn )
         custom.push( {
            id: p.id, name: p.name, platform: p.platform,
            width: p.width, height: p.height, ratio: p.ratio, longEdge: p.longEdge,
            maxKB: p.maxKB, format: p.format, sharpen: p.sharpen, enabled: p.enabled
         } );
   }
   asmdWriteSetting( "customPresets", DataType_String, JSON.stringify( custom ) );
   asmdWriteSetting( "enabledStates", DataType_String, JSON.stringify( states ) );
}

// Saved jobs use the same Settings JSON string as custom presets.
// Custom presets are licensed, so saving jobs is licensed too.
function asmdNormalizeJob( raw )
{
   if ( !raw || typeof raw != "object" )
      return null;
   var name = asmdTrim( String( raw.name || "" ) ).replace( /[\r\n\t]+/g, " " );
   if ( name.length == 0 || name.length > 80 )
      return null;
   var d = ASMD_DEFAULTS;
   var mode = asmdNormalizeExportMode( raw.exportMode, raw.fullFrameFit, raw.logoOnly );
   var ids = [], i;
   if ( raw.enabledIds && raw.enabledIds.length )
      for ( i = 0; i < raw.enabledIds.length; ++i )
         if ( raw.enabledIds[i] )
            ids.push( String( raw.enabledIds[i] ) );
   var mb = raw.fullFrameMaxMB;
   if ( !(mb >= 0.05) )
      mb = d.fullFrameMaxMB;
   var lmb = raw.logoMaxMB;
   if ( !(lmb >= 0.05) )
      lmb = mb;
   var logoFit = !!raw.logoFit;
   if ( !(("logoFit" in raw)) && mode == 2 && raw.fullFrameFit )
      logoFit = true;
   var format = asmdStoredLogoFormat( ("logoFormat" in raw) ? raw.logoFormat : "JPEG", "JPEG" );
   var priority = (raw.fullFramePriority == 1) ? 1 : 0;
   var logoPriority = (raw.logoPriority == 1) ? 1 : 0;
   return {
      name: name,
      exportMode: mode,
      socialMode: (raw.socialMode == 1) ? 1 : 0,
      enabledIds: ids,
      template: (raw.template && String( raw.template ).length) ? String( raw.template ) : d.template,
      subfolderPerImage: !!raw.subfolderPerImage,
      overwrite: !!raw.overwrite,
      noUpscale: (raw.noUpscale === false) ? false : true,
      interpolation: (raw.interpolation >= 0 && raw.interpolation < ASMD_INTERPOLATIONS.length) ? raw.interpolation : 0,
      sharpenEnabled: !!raw.sharpenEnabled,
      sharpenStrength: (raw.sharpenStrength >= 0 && raw.sharpenStrength <= 1) ? raw.sharpenStrength : d.sharpenStrength,
      jpegQuality: asmdClampJpegQuality( raw.jpegQuality ),
      wmEnabled: !!raw.wmEnabled,
      wmMode: (raw.wmMode == 1) ? 1 : 0,
      wmText: (raw.wmText || raw.wmText === "") ? String( raw.wmText ) : d.wmText,
      wmLogoPath: raw.wmLogoPath ? String( raw.wmLogoPath ) : "",
      wmCorner: (raw.wmCorner >= 0 && raw.wmCorner < ASMD_CORNERS.length) ? raw.wmCorner : d.wmCorner,
      wmOpacity: (raw.wmOpacity >= 0.05 && raw.wmOpacity <= 1) ? raw.wmOpacity : d.wmOpacity,
      wmSizePercent: (raw.wmSizePercent >= 1 && raw.wmSizePercent <= 25) ? raw.wmSizePercent : d.wmSizePercent,
      fullFrameMaxMB: mb,
      fullFramePriority: priority,
      logoFit: logoFit,
      logoFormat: format,
      logoMaxMB: lmb,
      logoPriority: logoPriority,
      outDir: raw.outDir ? String( raw.outDir ) : "",
      carShape: (raw.carShape >= 0) ? raw.carShape : d.carShape,
      carCustomW: (raw.carCustomW >= 16) ? raw.carCustomW : d.carCustomW,
      carCustomH: (raw.carCustomH >= 16) ? raw.carCustomH : d.carCustomH,
      carPanels: (raw.carPanels >= 2) ? raw.carPanels : d.carPanels,
      carLayout: (raw.carLayout >= 0) ? raw.carLayout : d.carLayout,
      carPlatform: (raw.carPlatform >= 0) ? raw.carPlatform : d.carPlatform,
      carWatermark: (raw.carWatermark >= 0) ? raw.carWatermark : d.carWatermark,
      carMaxKB: (raw.carMaxKB >= 10) ? raw.carMaxKB : d.carMaxKB,
      carTemplate: (raw.carTemplate && String( raw.carTemplate ).length) ? String( raw.carTemplate ) : d.carTemplate
   };
}

function asmdLoadJobs()
{
   var list = [];
   var json = asmdReadSetting( "savedJobs", DataType_String, "" );
   if ( !json || json.length == 0 )
      return list;
   try
   {
      var raw = JSON.parse( json );
      var i;
      for ( i = 0; i < raw.length; ++i )
      {
         var job = asmdNormalizeJob( raw[i] );
         if ( job )
            list.push( job );
      }
   }
   catch ( x )
   {
      console.warningln( "** Saved jobs could not be read and were ignored: " + x.message );
   }
   return list;
}

function asmdSaveJobs( list )
{
   var out = [], i;
   for ( i = 0; i < list.length; ++i )
   {
      var job = asmdNormalizeJob( list[i] );
      if ( job )
         out.push( job );
   }
   asmdWriteSetting( "savedJobs", DataType_String, JSON.stringify( out ) );
}

// ============================================================================
// Crop rectangle helpers (all in source image pixel coordinates)
// A crop is { x, y, w, h } with floating point values; w/h == aspect.
// ============================================================================

// Largest crop of the given aspect that fits the image.
function asmdMaxCropSize( imgW, imgH, aspect )
{
   var w = imgW, h = imgW/aspect;
   if ( h > imgH )
   {
      h = imgH;
      w = imgH*aspect;
   }
   return { w: w, h: h };
}

// Keep a crop inside the image, at the right aspect, and not too small.
function asmdClampCrop( c, imgW, imgH, aspect )
{
   var m = asmdMaxCropSize( imgW, imgH, aspect );
   var minW = Math.min( Math.max( 16, 16*aspect ), m.w );
   if ( c.w > m.w ) c.w = m.w;
   if ( c.w < minW ) c.w = minW;
   c.h = c.w/aspect;
   c.x = Math.max( 0, Math.min( c.x, imgW - c.w ) );
   c.y = Math.max( 0, Math.min( c.y, imgH - c.h ) );
   return c;
}

function asmdDefaultCrop( imgW, imgH, aspect )
{
   var m = asmdMaxCropSize( imgW, imgH, aspect );
   return { x: (imgW - m.w)/2, y: (imgH - m.h)/2, w: m.w, h: m.h };
}

// Integer pixel rectangle for processing.
function asmdCropRect( c, imgW, imgH )
{
   var x0 = Math.max( 0, Math.round( c.x ) );
   var y0 = Math.max( 0, Math.round( c.y ) );
   var x1 = Math.min( imgW, Math.round( c.x + c.w ) );
   var y1 = Math.min( imgH, Math.round( c.y + c.h ) );
   return new Rect( x0, y0, Math.max( x0 + 1, x1 ), Math.max( y0 + 1, y1 ) );
}

// ============================================================================
// Carousel model (pure logic, no PixInsight objects)
// ----------------------------------------------------------------------------
// A carousel is a list of items in swipe order. Each item is one of:
//   { type: "pano",   n, crop }            N panels cut from one wide strip
//   { type: "grid",   cols, rows, crop }   a 2x2 or 3x3 grid of tiles
//   { type: "detail", crop }               a zoom-in on the current image
//   { type: "other",  window, fit, crop }  another open image window
// Every slide shares one pixel size (slideW x slideH).
// There is at most one panorama or grid item per carousel (not both).
// ============================================================================

var ASMD_CAROUSEL_MAX_SLIDES = 20;    // Instagram's carousel limit
var ASMD_CAROUSEL_MIN_PANELS = 2;
var ASMD_CAROUSEL_MAX_PANELS = 10;

var ASMD_CAROUSEL_SHAPES = [
   { name: "4:5 portrait, 1080 x 1350 (recommended)", w: 1080, h: 1350 },
   { name: "3:4 portrait, 1080 x 1440 (app only)",    w: 1080, h: 1440 },
   { name: "1:1 square, 1080 x 1080",                 w: 1080, h: 1080 },
   { name: "9:16 full screen, 1080 x 1920 (TikTok photo carousels)", w: 1080, h: 1920 },
   { name: "Custom size",                             w: 0,    h: 0    }
];

// Destination platforms for Carousel mode. maxKB values are practical
// targets, well below each official hard upload limit (see README).
// shapes lists indices into ASMD_CAROUSEL_SHAPES. forceWidth, when set,
// scales non-custom shapes to that width (Threads official max is 1440).
// shortNote is the on-screen text (kept to 2-3 lines). note is the full
// text, shown in the label tooltip. The note label uses a fixed height so
// switching platforms does not resize the slide list or button rows.
var ASMD_CAROUSEL_PLATFORMS = [
   { id: "instagram", name: "Instagram", token: "Instagram",
     maxSlides: 20, maxKB: 1600, defaultShape: 0, shapes: [ 0, 1, 2, 4 ],
     swipe: true, forceWidth: 0,
     shortNote: "Up to 20 photos or videos per carousel. 4:5 works in the app and schedulers; 3:4 is app only. " +
                "Every slide shares one shape.",
     note: "Instagram allows up to 20 photos or videos in one carousel (official Help Center). " +
           "4:5 works in the app and in scheduling tools. 3:4 is accepted only by the Instagram app. " +
           "Every slide shares one shape, because Instagram uses the first slide's shape for the whole carousel." },
   { id: "tiktok", name: "TikTok", token: "TikTok",
     maxSlides: 35, maxKB: 2400, defaultShape: 3, shapes: [ 3, 0, 1, 2, 4 ],
     swipe: true, forceWidth: 0,
     shortNote: "Up to 35 images per photo post. JPEG or WebP, maximum 1080p, 20 MB each. " +
                "9:16 at 1080 x 1920 fills the phone screen.",
     note: "TikTok photo posts allow up to 35 images (official Content Posting API). " +
           "Official image rules are JPEG or WebP, maximum 1080p, and 20 MB each. " +
           "9:16 at 1080 x 1920 fills the phone screen; that pixel size is common practice, not an official size." },
   { id: "facebook", name: "Facebook", token: "Facebook",
     maxSlides: 20, maxKB: 1500, defaultShape: 2, shapes: [ 0, 1, 2, 4 ],
     swipe: false, forceWidth: 0,
     shortNote: "Facebook shows a collage, not a swipeable carousel, so panorama and grid seams will not line up. " +
                "This script caps an export at 20.",
     note: "Facebook shows several photos as a collage, not a swipeable carousel. " +
           "Panorama and grid seams will not line up as a swipe on Facebook; use Instagram, TikTok, or Threads for that. " +
           "Facebook does not publish a cap for photos in one post (albums allow 1,000). This script caps a Facebook export at 20." },
   { id: "threads", name: "Threads", token: "Threads",
     maxSlides: 20, maxKB: 4000, defaultShape: 1, shapes: [ 0, 1, 2, 3, 4 ],
     swipe: true, forceWidth: 1440,
     shortNote: "Up to 20 images or videos per carousel. Slides are exported 1440 px wide. " +
                "Official file cap is 8 MB; the target below is practical.",
     note: "Threads allows up to 20 images or videos in one carousel (official Threads API, updated October 30, 2026). " +
           "Images are scaled to a width of 320 to 1440 px, so slides are exported 1440 px wide. " +
           "Official file cap is 8 MB; the target below is a practical size." },
   { id: "x", name: "X", token: "X",
     maxSlides: 4, maxKB: 3000, defaultShape: 0, shapes: [ 0, 1, 2, 4 ],
     swipe: false, forceWidth: 0,
     shortNote: "Official cap is 4 photos per post. A reported raise to 20 could not be confirmed, so this script stays at 4. " +
                "A 3x3 grid is over that limit.",
     note: "X has long allowed 4 photos per post. News reports on November 12, 2026 said the cap was raised to 20, " +
           "but that could not be confirmed on an official Help page, so this script stays at 4. " +
           "A 3x3 grid (9 tiles) is over that limit. Multiple photos are arranged in a grid in the timeline, " +
           "so panorama and grid seams may not swipe. A single photo between 2:1 and 3:4 is shown in full. " +
           "Official file cap is 5 MB; the target below is 3 MB." },
   { id: "custom", name: "Custom", token: "Carousel",
     maxSlides: 35, maxKB: 1600, defaultShape: 0, shapes: [ 0, 1, 2, 3, 4 ],
     swipe: true, forceWidth: 0,
     shortNote: "No platform cap beyond 35 slides. You choose the shape and size. " +
                "The {platform} file name token is Carousel.",
     note: "Custom has no platform cap beyond 35 slides. You choose the shape and size. " +
           "The {platform} file name token is Carousel." }
];

function asmdCarouselPlatform( index )
{
   if ( index < 0 || index >= ASMD_CAROUSEL_PLATFORMS.length )
      index = 0;
   return ASMD_CAROUSEL_PLATFORMS[index];
}

function asmdCarouselPlatformAllowsShape( platformIndex, shapeIndex )
{
   var p = asmdCarouselPlatform( platformIndex );
   for ( var i = 0; i < p.shapes.length; ++i )
      if ( p.shapes[i] == shapeIndex )
         return true;
   return false;
}

var ASMD_CAROUSEL_WATERMARKS = [ "None", "First slide only", "Every slide", "Last slide only" ];

// Multi-slide layouts: a horizontal panorama, or a 2x2 or 3x3 grid.
var ASMD_CAROUSEL_LAYOUTS = [
   { name: "Panorama", type: "pano" },
   { name: "2x2 grid", type: "grid", cols: 2, rows: 2 },
   { name: "3x3 grid", type: "grid", cols: 3, rows: 3 }
];

// Slide pixel size for a shape index (custom uses customW x customH).
function asmdCarouselShape( index, customW, customH )
{
   var s = ASMD_CAROUSEL_SHAPES[index];
   if ( s && s.w > 0 && s.h > 0 )
      return { w: s.w, h: s.h };
   return { w: Math.max( 16, Math.round( customW || 1080 ) ),
            h: Math.max( 16, Math.round( customH || 1350 ) ) };
}

// Geometry of a cols x rows grid of slides, each slideW x slideH.
// The crop is resampled once to cols*slideW x rows*slideH and then cut
// into tiles in reading order (row by row, left to right), so the tiles
// share edges with no gap or overlap.
function asmdGridGeometry( cols, rows, slideW, slideH )
{
   cols = Math.max( 1, Math.round( cols ) );
   rows = Math.max( 1, Math.round( rows ) );
   var tiles = [];
   for ( var r = 0; r < rows; ++r )
      for ( var c = 0; c < cols; ++c )
         tiles.push( { x: c*slideW, y: r*slideH, w: slideW, h: slideH, row: r, col: c } );
   return { stripW: cols*slideW, stripH: rows*slideH,
            aspect: cols*slideW/(rows*slideH), tiles: tiles, cols: cols, rows: rows };
}

// Geometry of a seamless panorama of n slides: a 1-row grid.
// panels is an alias of tiles, kept so existing panorama code and tests work.
function asmdPanoramaGeometry( n, slideW, slideH )
{
   var g = asmdGridGeometry( n, 1, slideW, slideH );
   g.panels = g.tiles;
   return g;
}

function asmdCarouselIsLayout( item )
{
   return !!(item && (item.type == "pano" || item.type == "grid"));
}

// Index into ASMD_CAROUSEL_LAYOUTS for a pano or grid item.
function asmdCarouselLayoutIndexOf( item )
{
   if ( item && item.type == "grid" )
      return (item.cols == 3 && item.rows == 3) ? 2 : 1;
   return 0;
}

// Slide limit comes from the selected carousel platform.
var ASMD_CAROUSEL_TIKTOK_SHAPE = 3;
function asmdCarouselMaxSlides( platformIndex )
{
   var p = asmdCarouselPlatform( platformIndex );
   return (p && p.maxSlides > 0) ? p.maxSlides : ASMD_CAROUSEL_MAX_SLIDES;
}

// Number of slides an item produces.
function asmdCarouselItemSlides( item )
{
   if ( item.type == "pano" )
      return Math.max( 1, Math.round( item.n ) );
   if ( item.type == "grid" )
      return Math.max( 1, Math.round( item.cols ) )*Math.max( 1, Math.round( item.rows ) );
   return 1;
}

function asmdCarouselCount( items )
{
   var n = 0;
   for ( var i = 0; i < items.length; ++i )
      n += asmdCarouselItemSlides( items[i] );
   return n;
}

// Expands the item list into numbered slides in swipe order:
// [ { number (1 based), itemIndex, panel (0 based, -1 if not a panel) } ]
function asmdCarouselSlides( items )
{
   var out = [], num = 0;
   for ( var i = 0; i < items.length; ++i )
   {
      var k = asmdCarouselItemSlides( items[i] );
      for ( var j = 0; j < k; ++j )
         out.push( { number: ++num, itemIndex: i, panel: asmdCarouselIsLayout( items[i] ) ? j : -1 } );
   }
   return out;
}

// First 1-based slide number of item i.
function asmdCarouselItemFirst( items, index )
{
   var first = 1;
   for ( var i = 0; i < index; ++i )
      first += asmdCarouselItemSlides( items[i] );
   return first;
}

// Slide numbers covered by item i, as text: "01" or "01-03".
function asmdCarouselItemRange( items, index )
{
   var first = asmdCarouselItemFirst( items, index );
   var last = first + asmdCarouselItemSlides( items[index] ) - 1;
   return (last > first) ? (asmdTwo( first ) + "-" + asmdTwo( last )) : asmdTwo( first );
}

// Watermark choice: 0 none, 1 first slide, 2 every slide, 3 last slide.
function asmdCarouselWatermarkOn( choice, number, total )
{
   switch ( choice )
   {
   case 1:  return number == 1;
   case 2:  return true;
   case 3:  return number == total;
   default: return false;
   }
}

// Makes sure a carousel name template contains the {slide} token, so the
// files sort in swipe order and never overwrite each other.
function asmdCarouselTemplate( t )
{
   t = asmdTrim( t );
   if ( t.length == 0 )
      t = ASMD_DEFAULTS.carTemplate;
   if ( t.toLowerCase().indexOf( "{slide}" ) < 0 )
   {
      var m = t.match( /^(.*?)(\.(jpe?g|png))?$/i );
      t = m[1] + "_{slide}" + (m[2] || "");
   }
   return t;
}

// Changes a crop to a new aspect, keeping its center and height where the
// image allows. Used for detail and other-image slides, so a carefully
// framed zoom does not jump to the largest box when the slide shape changes.
function asmdRefitCrop( c, imgW, imgH, aspect )
{
   var cx = c.x + c.w/2, cy = c.y + c.h/2;
   c.w = c.h*aspect;
   c.x = cx - c.w/2;
   c.y = cy - c.h/2;
   return asmdClampCrop( c, imgW, imgH, aspect );
}

// Largest crop of the given aspect that fits in the image, centered on the
// previous box center (clamped to the image). Used when the panorama panel
// count, grid size, or slide shape changes, and when a single-export preset
// changes aspect. The user can still drag or resize the box smaller after.
function asmdMaxFitCrop( c, imgW, imgH, aspect )
{
   var cx = c.x + c.w/2, cy = c.y + c.h/2;
   var m = asmdMaxCropSize( imgW, imgH, aspect );
   c.w = m.w;
   c.h = m.h;
   c.x = cx - c.w/2;
   c.y = cy - c.h/2;
   return asmdClampCrop( c, imgW, imgH, aspect );
}

// Intersection of two crops, or null if they do not overlap.
function asmdCropIntersection( a, b )
{
   var x0 = Math.max( a.x, b.x );
   var y0 = Math.max( a.y, b.y );
   var x1 = Math.min( a.x + a.w, b.x + b.w );
   var y1 = Math.min( a.y + a.h, b.y + b.h );
   if ( x1 <= x0 || y1 <= y0 )
      return null;
   return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

// Overlap as a percent of the smaller crop's area. 0 if they do not overlap.
function asmdCropOverlapPercent( a, b )
{
   var hit = asmdCropIntersection( a, b );
   if ( !hit )
      return 0;
   var smaller = Math.min( a.w*a.h, b.w*b.h );
   if ( !(smaller > 0) )
      return 0;
   return 100*hit.w*hit.h/smaller;
}

// Overlapping pairs among boxes [{ crop, number }, ...], sorted by slide number.
// percent is rounded to a whole number, at least 1 when there is any overlap.
function asmdCropOverlapPairs( boxes )
{
   var pairs = [];
   var i, j;
   for ( i = 0; i < boxes.length; ++i )
      for ( j = i + 1; j < boxes.length; ++j )
      {
         var p = asmdCropOverlapPercent( boxes[i].crop, boxes[j].crop );
         if ( p > 0 )
         {
            var n1 = boxes[i].number, n2 = boxes[j].number;
            if ( n1 > n2 )
            {
               var t = n1; n1 = n2; n2 = t;
            }
            pairs.push( { a: n1, b: n2, percent: Math.max( 1, Math.round( p ) ) } );
         }
      }
   pairs.sort( function( u, v ) { return (u.a != v.a) ? (u.a - v.a) : (u.b - v.b); } );
   return pairs;
}

function asmdCropOverlapText( pairs )
{
   if ( !pairs || pairs.length == 0 )
      return "";
   var parts = [];
   for ( var i = 0; i < pairs.length; ++i )
      parts.push( "Slides " + pairs[i].a + " and " + pairs[i].b +
                  " overlap by " + pairs[i].percent + "%." );
   return parts.join( " " );
}

// Hint under the Don't-upscale checkbox when the crop is smaller than the
// output. forcedExact is true in Carousel mode, where every slide keeps the
// shared platform size (the checkbox cannot shrink those files).
function asmdUpscaleHint( cropW, cropH, outW, outH, noUpscale, forcedExact )
{
   if ( !(cropW > 0) || !(outW > 0) || cropW >= outW )
      return "";
   if ( noUpscale && !forcedExact )
   {
      var f = cropW/outW;
      var w = Math.max( 1, Math.round( outW*f ) );
      var h = Math.max( 1, Math.round( outH*f ) );
      return "Your crop is " + cropW + " px wide, so this export will be " +
             w + " x " + h + " instead of " + outW + " x " + outH + ".";
   }
   var s = outW/cropW;
   var t = "Your crop will be enlarged " + s.toFixed( 1 ) + "x to " + outW + " x " + outH + ".";
   if ( s > 2.0001 )
      t += " It may look soft.";
   if ( forcedExact && noUpscale )
      t += " Carousel slides stay at the platform size so they match.";
   return t;
}

function asmdFileExtension( path )
{
   var s = asmdTrim( String( path || "" ) ).toLowerCase().replace( /\\/g, "/" );
   var slash = s.lastIndexOf( "/" );
   var base = (slash >= 0) ? s.substring( slash + 1 ) : s;
   var dot = base.lastIndexOf( "." );
   if ( dot <= 0 || dot == base.length - 1 )
      return "";
   return base.substring( dot + 1 );
}

// Note under the logo path. info is optional: { width, hasAlpha } from a cheap
// load. Reads of missing fields use "in" because PJSR warns on undefined properties.
function asmdLogoHint( path, info )
{
   var p = asmdTrim( path || "" );
   if ( p.length == 0 )
      return "";
   var ext = asmdFileExtension( p );
   var parts = [];
   if ( ext == "svg" )
      parts.push( "SVG is not supported. Export it to PNG." );
   else if ( ext == "jpg" || ext == "jpeg" )
      parts.push( "JPEG has no transparency, so the logo will show as a solid rectangle. Use a transparent PNG for a clean logo." );
   else if ( info && ("hasAlpha" in info) && info.hasAlpha === false )
      parts.push( "This logo has no transparency, so it will show as a solid rectangle. Use a transparent PNG for a clean logo." );
   if ( info && ("width" in info) && info.width > 0 && info.width < 400 )
      parts.push( "Small logo; it may look soft when scaled up." );
   return parts.join( " " );
}

// True if any sampled pixel has an alpha byte below 255. Uses a coarse grid
// of at most 64 x 64 samples so a large logo stays cheap. width, height and
// pixel() are documented Bitmap members, so they are read directly.
function asmdBitmapHasTransparency( bmp )
{
   if ( !bmp )
      return false;
   var W = bmp.width, H = bmp.height;
   if ( !(W > 0) || !(H > 0) )
      return false;
   var nx = Math.min( 64, W );
   var ny = Math.min( 64, H );
   var ix, iy, x, y, p;
   for ( iy = 0; iy < ny; ++iy )
   {
      y = (ny <= 1) ? 0 : Math.floor( iy*(H - 1)/(ny - 1) );
      for ( ix = 0; ix < nx; ++ix )
      {
         x = (nx <= 1) ? 0 : Math.floor( ix*(W - 1)/(nx - 1) );
         p = bmp.pixel( x, y );
         if ( ((p >>> 24) & 0xFF) < 255 )
            return true;
      }
   }
   return false;
}

// Alpha on a PixInsight Image from ImageWindow.open (documented properties).
function asmdImageHasAlpha( image )
{
   if ( !image )
      return false;
   if ( image.hasAlphaChannels )
      return true;
   return image.numberOfChannels > (image.isColor ? 3 : 1);
}

// Width and whether the logo has any transparency, only if the file exists
// and loads. Bitmap pixels are sampled; ImageWindow images use Image metadata.
function asmdInspectLogo( path )
{
   var p = asmdTrim( path || "" );
   if ( p.length == 0 || !File.exists( p ) )
      return null;

   try
   {
      var bmp = new Bitmap( p );
      if ( bmp && bmp.width > 0 && bmp.height > 0 )
      {
         var info = { width: bmp.width, height: bmp.height };
         try { info.hasAlpha = asmdBitmapHasTransparency( bmp ); }
         catch ( eAlpha ) { }   // alpha unknown: no transparency note
         return info;
      }
   }
   catch ( e )
   {
   }

   var windows = null;
   try
   {
      windows = ImageWindow.open( path, "ASMD_logo_info", "", true );
      if ( windows && windows.length > 0 && windows[0] && !windows[0].isNull )
      {
         var image = windows[0].mainView.image;
         if ( image && image.width > 0 && image.height > 0 )
         {
            var info2 = { width: image.width, height: image.height };
            try { info2.hasAlpha = asmdImageHasAlpha( image ); }
            catch ( eAlpha2 ) { }
            return info2;
         }
      }
   }
   catch ( e2 )
   {
   }
   finally
   {
      if ( windows )
         for ( var i = 0; i < windows.length; ++i )
            if ( windows[i] && !windows[i].isNull )
               windows[i].forceClose();
   }
   return null;
}

// Default zoom-in crop for a detail slide: 40% of the largest box, centered.
function asmdDefaultDetailCrop( imgW, imgH, aspect )
{
   var m = asmdMaxCropSize( imgW, imgH, aspect );
   var w = m.w*0.4, h = w/aspect;
   return asmdClampCrop( { x: (imgW - w)/2, y: (imgH - h)/2, w: w, h: h }, imgW, imgH, aspect );
}

// ============================================================================
// Crop preview control
// ----------------------------------------------------------------------------
// A custom Control that draws a fit-to-window rendition of the image plus a
// crop overlay. Mouse: drag inside to move, drag a corner handle to resize,
// click outside to center the crop there, wheel to grow or shrink (Shift for
// fine steps). The aspect ratio is always kept.
// ============================================================================

// Renders a reduced bitmap of an image for the preview. Image.render() takes
// a zoom level where negative values are reductions (-2 = 1:2). If a core
// rejects the argument, fall back to a full size rendition.
function asmdRenderPreviewBitmap( image )
{
   var k = Math.max( 1, Math.floor( Math.max( image.width, image.height )/1600 ) );
   try
   {
      return (k >= 2) ? image.render( -k ) : image.render();
   }
   catch ( x )
   {
      return image.render();
   }
}

function AsmdCropPreview( parent, image )
{
   this.__base__ = Control;
   this.__base__( parent );

   this.imgW = image.width;
   this.imgH = image.height;

   // Render a reduced bitmap once.
   this.bitmap = asmdRenderPreviewBitmap( image );

   this.crop = null;        // current crop object (shared with the dialog)
   this.aspect = 1;
   this.label = "";
   this.onCropChanged = null;
   this.dividers = 0;       // carousel: columns of cut lines (0 = none)
   this.gridCols = 0;
   this.gridRows = 0;
   this.peers = [];         // other detail boxes on this image: [{ crop, number, selected }]

   // Switches the preview to another image (carousel slides from other open
   // windows). The bitmap is rendered by the caller so it can be cached.
   this.setImage = function( w, h, bitmap )
   {
      if ( this.bitmap === bitmap && this.imgW == w && this.imgH == h )
         return;
      this.imgW = w;
      this.imgH = h;
      this.bitmap = bitmap;
      this.mode = 0;
      this.update();
   };

   this.hideCrop = false;  // full frame and logo only show the image with no crop box
   this.mode = 0;           // 0 = idle, 1 = moving, 2 = resizing
   this.anchor = null;      // fixed corner while resizing (image coords)
   this.corner = -1;        // corner being dragged (0 TL, 1 TR, 2 BL, 3 BR)
   this.dragOffset = null;  // pointer minus crop origin while moving
   this.handleSize = 9;

   this.setScaledMinSize( ASMD_PREVIEW_MIN_W, ASMD_PREVIEW_MIN_H );
   try
   {
      this.setMinWidth( this.logicalPixelsToPhysical( ASMD_PREVIEW_MIN_W ) );
      this.setMinHeight( this.logicalPixelsToPhysical( ASMD_PREVIEW_MIN_H ) );
   }
   catch ( xMin )
   {
      try
      {
         this.setMinWidth( ASMD_PREVIEW_MIN_W );
         this.setMinHeight( ASMD_PREVIEW_MIN_H );
      }
      catch ( yMin ) {}
   }
   this.cursor = new Cursor( StdCursor_Cross );
   this.toolTip = "<p>Drag inside the box to move it. Drag a corner handle to resize it. " +
                  "Use the mouse wheel to grow or shrink it (hold Shift for fine steps). " +
                  "Click outside the box to center it there. The aspect ratio always stays " +
                  "locked to the selected target.</p>" +
                  "<p>In Carousel mode, other detail slides on the same image are shown as dim " +
                  "outlines with their slide numbers, so you can see if they overlap.</p>";

   // Image to control mapping: control = offset + image*scale.
   this.geometry = function()
   {
      var cw = this.width, ch = this.height;
      var s = Math.min( cw/this.imgW, ch/this.imgH );
      return { s: s, ox: (cw - this.imgW*s)/2, oy: (ch - this.imgH*s)/2 };
   };

   this.toImage = function( x, y )
   {
      var g = this.geometry();
      return { x: (x - g.ox)/g.s, y: (y - g.oy)/g.s };
   };

   this.cropControlRect = function()
   {
      var g = this.geometry(), c = this.crop;
      return { x0: g.ox + c.x*g.s, y0: g.oy + c.y*g.s,
               x1: g.ox + (c.x + c.w)*g.s, y1: g.oy + (c.y + c.h)*g.s };
   };

   // Returns the corner index under (x,y) in control coordinates, or -1.
   this.hitCorner = function( x, y )
   {
      if ( !this.crop )
         return -1;
      var r = this.cropControlRect(), t = this.handleSize + 3;
      var pts = [ [r.x0, r.y0], [r.x1, r.y0], [r.x0, r.y1], [r.x1, r.y1] ];
      for ( var i = 0; i < 4; ++i )
         if ( Math.abs( x - pts[i][0] ) <= t && Math.abs( y - pts[i][1] ) <= t )
            return i;
      return -1;
   };

   this.insideCrop = function( x, y )
   {
      if ( !this.crop )
         return false;
      var r = this.cropControlRect();
      return x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1;
   };

   this.setTarget = function( crop, aspect, label, cols, rows )
   {
      this.crop = crop;
      this.aspect = aspect;
      this.label = label || "";
      this.gridCols = cols || 0;
      this.gridRows = (rows > 0) ? rows : ((this.gridCols > 1) ? 1 : 0);
      this.dividers = this.gridCols;
      this.peers = [];
      this.update();
   };

   this.setPeers = function( list )
   {
      this.peers = list || [];
      this.update();
   };

   this.rectForCrop = function( c )
   {
      var g = this.geometry();
      return { x0: g.ox + c.x*g.s, y0: g.oy + c.y*g.s,
               x1: g.ox + (c.x + c.w)*g.s, y1: g.oy + (c.y + c.h)*g.s };
   };

   // Call after any change to this.crop.
   this.changed = function()
   {
      if ( !this.crop )
         return;
      asmdClampCrop( this.crop, this.imgW, this.imgH, this.aspect );
      this.update();
      if ( this.onCropChanged )
         this.onCropChanged();
   };

   this.onPaint = function( x0, y0, x1, y1 )
   {
      var G = new Graphics( this );
      try
      {
         G.fillRect( 0, 0, this.width, this.height, new Brush( 0xff202020 ) );
         var g = this.geometry();
         var ix0 = g.ox, iy0 = g.oy, ix1 = g.ox + this.imgW*g.s, iy1 = g.oy + this.imgH*g.s;
         G.smoothInterpolation = true;
         G.drawScaledBitmap( new Rect( Math.round( ix0 ), Math.round( iy0 ),
                                       Math.round( ix1 ), Math.round( iy1 ) ), this.bitmap );
         if ( this.crop && !this.hideCrop )
         {
            var r = this.cropControlRect();
            var shade = new Brush( 0xa0000000 );
            // Darken everything outside the crop.
            G.fillRect( ix0, iy0, ix1, r.y0, shade );
            G.fillRect( ix0, r.y1, ix1, iy1, shade );
            G.fillRect( ix0, r.y0, r.x0, r.y1, shade );
            G.fillRect( r.x1, r.y0, ix1, r.y1, shade );

            if ( this.gridCols > 1 || this.gridRows > 1 )
            {
               // Carousel panorama or grid: cyan cut lines and tile numbers
               // in reading order (row by row, left to right).
               var gcols = Math.max( 1, this.gridCols );
               var grows = Math.max( 1, this.gridRows );
               var tw = (r.x1 - r.x0)/gcols;
               var th = (r.y1 - r.y0)/grows;
               G.pen = new Pen( 0xff00e0ff, 2 );
               for ( var di = 1; di < gcols; ++di )
                  G.drawLine( r.x0 + di*tw, r.y0, r.x0 + di*tw, r.y1 );
               for ( var dj = 1; dj < grows; ++dj )
                  G.drawLine( r.x0, r.y0 + dj*th, r.x1, r.y0 + dj*th );
               var tn = 0;
               var fnH = this.font.height;
               var fnA = 0;
               if ( !(fnH > 0) )
                  fnH = 14;
               try
               {
                  if ( ("ascent" in this.font) && this.font.ascent > 0 )
                     fnA = this.font.ascent;
               }
               catch ( x ) {}
               if ( !(fnA > 0) )
                  fnA = fnH - 3;
               for ( var tr = 0; tr < grows; ++tr )
                  for ( var tc = 0; tc < gcols; ++tc )
                  {
                     var ns = String( ++tn );
                     var box = asmdTileLabelBox( r.x0 + tc*tw, r.y0 + tr*th,
                                                 r.x0 + (tc + 1)*tw, r.y0 + (tr + 1)*th,
                                                 this.font.width( ns ), fnH,
                                                 ix0, iy0, ix1, iy1 );
                     G.fillRect( box.x, box.y, box.x + box.w, box.y + box.h, new Brush( 0xb0000000 ) );
                     G.pen = new Pen( 0xff00e0ff );
                     G.drawText( box.x + box.padX, box.y + box.padY + fnA, ns );
                  }
            }
            else
            {
               // Rule of thirds guides.
               G.pen = new Pen( 0x60ffffff, 1 );
               var dx = (r.x1 - r.x0)/3, dy = (r.y1 - r.y0)/3;
               G.drawLine( r.x0 + dx, r.y0, r.x0 + dx, r.y1 );
               G.drawLine( r.x0 + 2*dx, r.y0, r.x0 + 2*dx, r.y1 );
               G.drawLine( r.x0, r.y0 + dy, r.x1, r.y0 + dy );
               G.drawLine( r.x0, r.y0 + 2*dy, r.x1, r.y0 + 2*dy );
            }

            // Crop border.
            G.pen = new Pen( 0xffffc000, 2 );
            G.drawRect( r.x0, r.y0, r.x1, r.y1 );

            // Corner handles.
            var hs = this.handleSize;
            var corners = [ [r.x0, r.y0], [r.x1, r.y0], [r.x0, r.y1], [r.x1, r.y1] ];
            G.pen = new Pen( 0xff000000, 1 );
            for ( var i = 0; i < 4; ++i )
            {
               var cx = corners[i][0], cy = corners[i][1];
               G.fillRect( cx - hs/2, cy - hs/2, cx + hs/2, cy + hs/2, new Brush( 0xffffc000 ) );
               G.drawRect( cx - hs/2, cy - hs/2, cx + hs/2, cy + hs/2 );
            }

            // Target label in the top left corner of the crop.
            if ( this.label.length > 0 )
            {
               var tw = this.font.width( this.label ) + 8, th = this.font.height + 4;
               G.fillRect( r.x0 + 2, r.y0 + 2, r.x0 + 2 + tw, r.y0 + 2 + th, new Brush( 0xb0000000 ) );
               G.pen = new Pen( 0xffffffff );
               G.drawText( r.x0 + 6, r.y0 + 4 + this.font.ascent, this.label );
            }
         }

         // Other detail boxes on the same image, plus overlap tints.
         if ( !this.hideCrop && this.peers && this.peers.length > 0 )
         {
            var pi, pj, pr;
            var overlapBrush = new Brush( 0x60ff8800 );
            for ( pi = 0; pi < this.peers.length; ++pi )
               for ( pj = pi + 1; pj < this.peers.length; ++pj )
               {
                  var hit = asmdCropIntersection( this.peers[pi].crop, this.peers[pj].crop );
                  if ( hit )
                  {
                     pr = this.rectForCrop( hit );
                     G.fillRect( pr.x0, pr.y0, pr.x1, pr.y1, overlapBrush );
                  }
               }
            for ( pi = 0; pi < this.peers.length; ++pi )
            {
               if ( this.peers[pi].selected )
                  continue;
               pr = this.rectForCrop( this.peers[pi].crop );
               G.pen = new Pen( 0xa000e0ff, 2 );
               G.drawRect( pr.x0, pr.y0, pr.x1, pr.y1 );
               var ns = String( this.peers[pi].number );
               var nw = this.font.width( ns ) + 8, nh = this.font.height + 4;
               G.fillRect( pr.x0 + 2, pr.y0 + 2, pr.x0 + 2 + nw, pr.y0 + 2 + nh, new Brush( 0x80000000 ) );
               G.pen = new Pen( 0xc0ffffff );
               G.drawText( pr.x0 + 6, pr.y0 + 4 + this.font.ascent, ns );
            }
         }
      }
      finally
      {
         G.end();
      }
   };

   this.onMousePress = function( x, y, button, buttons, modifiers )
   {
      if ( this.hideCrop )
         return;
      if ( button != MouseButton_Left || !this.crop )
         return;
      var c = this.crop;
      var corner = this.hitCorner( x, y );
      if ( corner >= 0 )
      {
         // The anchor is the corner opposite the one being dragged.
         this.mode = 2;
         this.corner = corner;
         this.anchor = {
            x: (corner == 0 || corner == 2) ? c.x + c.w : c.x,
            y: (corner == 0 || corner == 1) ? c.y + c.h : c.y
         };
         this.cursor = new Cursor( StdCursor_SizeAll );
         return;
      }
      var p = this.toImage( x, y );
      if ( !this.insideCrop( x, y ) )
      {
         // Click outside: center the crop on the click, then start moving.
         c.x = p.x - c.w/2;
         c.y = p.y - c.h/2;
         this.changed();
      }
      this.mode = 1;
      this.dragOffset = { x: p.x - c.x, y: p.y - c.y };
      this.cursor = new Cursor( StdCursor_ClosedHand );
   };

   this.onMouseMove = function( x, y, buttons, modifiers )
   {
      if ( this.hideCrop || !this.crop )
         return;
      var c = this.crop, p;
      if ( this.mode == 1 )
      {
         p = this.toImage( x, y );
         c.x = p.x - this.dragOffset.x;
         c.y = p.y - this.dragOffset.y;
         this.changed();
      }
      else if ( this.mode == 2 )
      {
         p = this.toImage( x, y );
         var a = this.anchor, asp = this.aspect;
         var left = (this.corner == 0 || this.corner == 2);
         var top  = (this.corner == 0 || this.corner == 1);
         // Largest width allowed from the anchor toward the dragged corner.
         var maxW = Math.min( left ? a.x : (this.imgW - a.x),
                              (top ? a.y : (this.imgH - a.y))*asp );
         var minW = Math.min( Math.max( 16, 16*asp ), maxW );
         // Width follows whichever pointer axis asks for more room.
         var w = Math.max( Math.abs( p.x - a.x ), Math.abs( p.y - a.y )*asp );
         w = Math.max( minW, Math.min( w, maxW ) );
         var h = w/asp;
         c.w = w;
         c.h = h;
         c.x = left ? a.x - w : a.x;
         c.y = top  ? a.y - h : a.y;
         this.changed();
      }
      else
      {
         // Hover feedback.
         if ( this.hitCorner( x, y ) >= 0 )
            this.cursor = new Cursor( StdCursor_SizeAll );
         else if ( this.insideCrop( x, y ) )
            this.cursor = new Cursor( StdCursor_OpenHand );
         else
            this.cursor = new Cursor( StdCursor_Cross );
      }
   };

   this.onMouseRelease = function( x, y, button, buttons, modifiers )
   {
      this.mode = 0;
      this.anchor = null;
      this.dragOffset = null;
      this.cursor = new Cursor( this.insideCrop( x, y ) ? StdCursor_OpenHand : StdCursor_Cross );
   };

   this.onMouseWheel = function( x, y, delta, buttons, modifiers )
   {
      if ( this.hideCrop || !this.crop || delta == 0 )
         return;
      // Wheel up grows, wheel down shrinks, about the crop center.
      var step = (modifiers & KeyModifier_Shift) ? 1.01 : 1.05;
      var f = (delta > 0) ? step : 1/step;
      var c = this.crop;
      var cx = c.x + c.w/2, cy = c.y + c.h/2;
      var m = asmdMaxCropSize( this.imgW, this.imgH, this.aspect );
      c.w = Math.min( c.w*f, m.w );
      c.h = c.w/this.aspect;
      c.x = cx - c.w/2;
      c.y = cy - c.h/2;
      this.changed();
   };

   this.onResize = function( wNew, hNew, wOld, hOld )
   {
      this.update();
   };
}

AsmdCropPreview.prototype = new Control;

// ============================================================================
// Preset editor dialog
// ============================================================================

function AsmdPresetDialog( preset, isNew )
{
   this.__base__ = Dialog;
   this.__base__();

   var self = this;
   this.preset = asmdClonePreset( preset );
   this.windowTitle = isNew ? "New Preset" : "Edit Preset";

   var labelW = this.font.width( "Max file size (MB):" ) + 12;

   function row( labelText, control, tip )
   {
      var l = new Label( self );
      l.text = labelText;
      l.minWidth = labelW;
      l.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      var s = new HorizontalSizer;
      s.spacing = 6;
      s.add( l );
      s.add( control, 100 );
      if ( tip )
         control.toolTip = tip;
      return s;
   }

   this.name_Edit = new Edit( this );
   this.name_Edit.text = this.preset.name;
   this.name_Edit.setScaledMinWidth( 260 );

   this.platform_Edit = new Edit( this );
   this.platform_Edit.text = this.preset.platform;

   this.mode_Combo = new ComboBox( this );
   this.mode_Combo.addItem( "Exact pixels (width x height)" );
   this.mode_Combo.addItem( "Aspect ratio + long edge" );
   var usesPixels = (this.preset.width > 0 && this.preset.height > 0);
   this.mode_Combo.currentItem = usesPixels ? 0 : 1;

   this.width_Spin = new SpinBox( this );
   this.width_Spin.setRange( 16, 16384 );
   this.width_Spin.value = usesPixels ? this.preset.width : 1080;

   this.height_Spin = new SpinBox( this );
   this.height_Spin.setRange( 16, 16384 );
   this.height_Spin.value = usesPixels ? this.preset.height : 1350;

   var x_Label = new Label( this );
   x_Label.text = "x";
   x_Label.textAlignment = TextAlign_VertCenter;

   var px_Sizer = new HorizontalSizer;
   px_Sizer.spacing = 6;
   px_Sizer.add( this.width_Spin );
   px_Sizer.add( x_Label );
   px_Sizer.add( this.height_Spin );
   px_Sizer.addStretch();
   this.px_Control = new Control( this );
   this.px_Control.sizer = px_Sizer;

   this.ratio_Edit = new Edit( this );
   this.ratio_Edit.text = (this.preset.ratio && this.preset.ratio.length > 0) ? this.preset.ratio : "4:5";

   this.longEdge_Spin = new SpinBox( this );
   this.longEdge_Spin.setRange( 16, 16384 );
   this.longEdge_Spin.value = (this.preset.longEdge > 0) ? this.preset.longEdge : 2048;

   this.maxMB_Edit = new NumericEdit( this );
   this.maxMB_Edit.label.text = "";
   this.maxMB_Edit.setReal( true );
   this.maxMB_Edit.setRange( 0.01, 100 );
   this.maxMB_Edit.setPrecision( 2 );
   this.maxMB_Edit.setValue( ((this.preset.maxKB > 0) ? this.preset.maxKB : 1000)/1000 );

   this.format_Combo = new ComboBox( this );
   this.format_Combo.addItem( "JPEG" );
   this.format_Combo.addItem( "PNG" );
   this.format_Combo.currentItem = (this.preset.format == "PNG") ? 1 : 0;

   this.sharpen_Check = new CheckBox( this );
   this.sharpen_Check.text = "Allow sharpening for this preset (when sharpening is on)";
   this.sharpen_Check.checked = this.preset.sharpen;

   this.updateMode = function()
   {
      var px = this.mode_Combo.currentItem == 0;
      this.px_Control.enabled = px;
      this.ratio_Edit.enabled = !px;
      this.longEdge_Spin.enabled = !px;
   };
   this.mode_Combo.onItemSelected = function( index ) { self.updateMode(); };

   this.ok_Button = new PushButton( this );
   this.ok_Button.text = "OK";
   this.ok_Button.onClick = function()
   {
      var name = asmdTrim( self.name_Edit.text );
      if ( name.length == 0 )
      {
         asmdMessage( "Please enter a preset name.", StdIcon_Warning );
         return;
      }
      var p = self.preset;
      p.name = name;
      var plat = asmdTrim( self.platform_Edit.text );
      p.platform = asmdSafeFileToken( plat.length > 0 ? plat : name );
      if ( self.mode_Combo.currentItem == 0 )
      {
         p.width = self.width_Spin.value;
         p.height = self.height_Spin.value;
         p.ratio = "";
         p.longEdge = 0;
      }
      else
      {
         if ( asmdParseRatio( self.ratio_Edit.text ) == 0 )
         {
            asmdMessage( "The ratio must look like 4:5, 16:9, 1.91:1, or the word native.", StdIcon_Warning );
            return;
         }
         p.width = 0;
         p.height = 0;
         p.ratio = asmdTrim( self.ratio_Edit.text );
         p.longEdge = self.longEdge_Spin.value;
      }
      p.maxKB = Math.max( 10, Math.round( self.maxMB_Edit.value*1000 ) );
      p.format = (self.format_Combo.currentItem == 1) ? "PNG" : "JPEG";
      p.sharpen = self.sharpen_Check.checked;
      self.ok();
   };

   this.cancel_Button = new PushButton( this );
   this.cancel_Button.text = "Cancel";
   this.cancel_Button.onClick = function() { self.cancel(); };

   var buttons = new HorizontalSizer;
   buttons.spacing = 6;
   buttons.addStretch();
   buttons.add( this.ok_Button );
   buttons.add( this.cancel_Button );

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add( row( "Name:", this.name_Edit, "<p>Shown in the targets list.</p>" ) );
   this.sizer.add( row( "File name tag:", this.platform_Edit,
      "<p>Used for the {platform} token in file names, for example Instagram-Portrait. " +
      "Spaces and symbols are replaced with dashes.</p>" ) );
   this.sizer.add( row( "Size mode:", this.mode_Combo ) );
   this.sizer.add( row( "Pixels (W x H):", this.px_Control ) );
   this.sizer.add( row( "Aspect ratio:", this.ratio_Edit,
      "<p>For example 4:5, 16:9, 1.91:1, or native to keep the image's own shape.</p>" ) );
   this.sizer.add( row( "Long edge (px):", this.longEdge_Spin ) );
   this.sizer.add( row( "Max file size (MB):", this.maxMB_Edit,
      "<p>Target size in megabytes, for example 2.4. JPEG keeps these pixels and searches quality from the " +
      "Processing setting (90 to 100, default 95) down to 75. If quality 75 is still over, the image is resized. " +
      "PNG files are reported if they go over.</p>" ) );
   this.sizer.add( row( "Format:", this.format_Combo ) );
   this.sizer.add( row( "", this.sharpen_Check ) );
   this.sizer.addSpacing( 4 );
   this.sizer.add( buttons );

   this.updateMode();
   this.adjustToContents();
   this.setFixedSize();
}

AsmdPresetDialog.prototype = new Dialog;

// ============================================================================
// License key dialog
// ============================================================================

function AsmdNameDialog( title, labelText, initial )
{
   this.__base__ = Dialog;
   this.__base__();

   var self = this;
   this.result = "";
   this.windowTitle = title;

   this.name_Edit = new Edit( this );
   this.name_Edit.text = initial || "";
   try { this.name_Edit.setScaledMinWidth( 280 ); } catch ( x ) {}

   var label = new Label( this );
   label.text = labelText;
   label.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   var row = new HorizontalSizer;
   row.spacing = 6;
   row.add( label );
   row.add( this.name_Edit, 100 );

   this.ok_Button = new PushButton( this );
   this.ok_Button.text = "OK";
   this.ok_Button.onClick = function()
   {
      var name = asmdTrim( self.name_Edit.text ).replace( /[\r\n\t]+/g, " " );
      if ( name.length == 0 )
      {
         asmdMessage( "Please enter a name.", StdIcon_Warning );
         return;
      }
      if ( name.length > 80 )
      {
         asmdMessage( "Please use a name of 80 characters or less.", StdIcon_Warning );
         return;
      }
      self.result = name;
      self.ok();
   };

   this.cancel_Button = new PushButton( this );
   this.cancel_Button.text = "Cancel";
   this.cancel_Button.onClick = function() { self.cancel(); };

   var buttons = new HorizontalSizer;
   buttons.spacing = 6;
   buttons.addStretch();
   buttons.add( this.ok_Button );
   buttons.add( this.cancel_Button );

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 6;
   this.sizer.add( row );
   this.sizer.add( buttons );
   this.adjustToContents();
   this.setFixedSize();
}

AsmdNameDialog.prototype = new Dialog;

function AsmdLicenseDialog()
{
   this.__base__ = Dialog;
   this.__base__();

   var self = this;
   this.windowTitle = ASMD_TITLE + " license";

   var intro = new Label( this );
   intro.wordWrapping = true;
   intro.useRichText = true;
   intro.text = "<p>Paste the email you used when you bought the script, and the license key " +
                "from your receipt. One key unlocks every feature on this computer.</p>";

   this.email_Edit = new Edit( this );
   this.email_Edit.text = ASMD_LICENSE.email;
   this.key_Edit = new Edit( this );
   this.key_Edit.text = ASMD_LICENSE.key;

   this.status_Label = new Label( this );
   this.status_Label.wordWrapping = true;
   this.status_Label.useRichText = true;
   this.status_Label.text = asmdIsLicensed() ?
      ("<b>Licensed to " + asmdLicensedEmail() + "</b>") : "No license is stored on this computer.";

   this.unlock_Button = new PushButton( this );
   this.unlock_Button.text = "Unlock";
   this.unlock_Button.onClick = function()
   {
      var email = asmdNormalizeEmail( self.email_Edit.text );
      var key = asmdCanonicalLicenseKey( self.key_Edit.text );
      if ( !asmdLicenseValid( email, key ) )
      {
         self.status_Label.text = "That email and key do not match. Check both and try again.";
         return;
      }
      asmdSaveLicense( email, key );
      self.email_Edit.text = email;
      self.key_Edit.text = key;
      self.status_Label.text = "<b>Licensed to " + email + "</b>";
   };

   this.remove_Button = new PushButton( this );
   this.remove_Button.text = "Remove license";
   this.remove_Button.onClick = function()
   {
      asmdClearLicense();
      self.email_Edit.text = "";
      self.key_Edit.text = "";
      self.status_Label.text = "License removed. This copy is back on the free version.";
   };

   this.close_Button = new PushButton( this );
   this.close_Button.text = "Close";
   this.close_Button.onClick = function() { self.ok(); };

   var emailRow = new HorizontalSizer;
   emailRow.spacing = 6;
   var emailLab = new Label( this );
   emailLab.text = "Email:";
   emailLab.minWidth = this.font.width( "License key:" ) + 8;
   emailRow.add( emailLab );
   emailRow.add( this.email_Edit, 100 );

   var keyRow = new HorizontalSizer;
   keyRow.spacing = 6;
   var keyLab = new Label( this );
   keyLab.text = "License key:";
   keyLab.minWidth = this.font.width( "License key:" ) + 8;
   keyRow.add( keyLab );
   keyRow.add( this.key_Edit, 100 );

   var btns = new HorizontalSizer;
   btns.spacing = 6;
   btns.add( this.unlock_Button );
   btns.add( this.remove_Button );
   btns.addStretch();
   btns.add( this.close_Button );

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 8;
   this.sizer.add( intro );
   this.sizer.add( emailRow );
   this.sizer.add( keyRow );
   this.sizer.add( this.status_Label );
   this.sizer.add( btns );
   this.adjustToContents();
   this.setMinWidth( 420 );
}

AsmdLicenseDialog.prototype = new Dialog;


// ============================================================================
// Export engine
// ============================================================================

// Interpolation constant for the Resample process, given the dialog choice
// and the scale factor (output width / crop width).
function asmdInterpolation( choice, scale )
{
   switch ( choice )
   {
   case 1:  return Resample.prototype.MitchellNetravaliFilter;
   case 2:  return Resample.prototype.Lanczos3;
   case 3:  return Resample.prototype.BicubicSpline;
   default: return (scale < 0.8) ? Resample.prototype.MitchellNetravaliFilter
                                 : Resample.prototype.Lanczos3;
   }
}

function asmdInterpolationName( choice, scale )
{
   var v = asmdInterpolation( choice, scale );
   if ( v == Resample.prototype.MitchellNetravaliFilter ) return "Mitchell-Netravali";
   if ( v == Resample.prototype.Lanczos3 ) return "Lanczos-3, clamped";
   return "bicubic spline";
}

// Builds an output file name from the template and a token table.
// Tokens: {name} {platform} {preset} {w} {h} {date} {time} {kb}
function asmdBuildFileName( template, tokens, format )
{
   var t = asmdTrim( template );
   if ( t.length == 0 )
      t = ASMD_DEFAULTS.template;
   // Remove any extension typed in the template; the right one is added below.
   t = t.replace( /\.(jpe?g|png)$/i, "" );
   var out = t.replace( /\{(\w+)\}/g, function( all, key )
   {
      key = key.toLowerCase();
      return tokens.hasOwnProperty( key ) ? String( tokens[key] ) : all;
   } );
   // Replace characters that are illegal in file names; keep the rest readable.
   out = out.replace( /[\\\/:*?"<>|{}]/g, "-" ).replace( /\s+/g, "-" );
   if ( out.length == 0 )
      out = "image";
   return out + ((format == "PNG") ? ".png" : ".jpg");
}

// Returns path, or path with _2, _3, ... added when the file already exists.
function asmdUniquePath( path, overwrite )
{
   if ( overwrite || !File.exists( path ) )
      return path;
   var dot = path.lastIndexOf( "." );
   var base = path.substring( 0, dot ), ext = path.substring( dot );
   for ( var i = 2; i < 1000; ++i )
   {
      var p = base + "_" + i + ext;
      if ( !File.exists( p ) )
         return p;
   }
   return base + "_" + asmdTimeString() + ext;
}

// Compare paths loosely so "C:/A.tif" and "c:/A.tif" count as the same file.
function asmdPathsEqual( a, b )
{
   var na = asmdCleanDir( String( a || "" ) ).toLowerCase();
   var nb = asmdCleanDir( String( b || "" ) ).toLowerCase();
   return na.length > 0 && na == nb;
}

function asmdWithLogoSuffix( path )
{
   var slash = Math.max( String( path ).lastIndexOf( "/" ), String( path ).lastIndexOf( "\\" ) );
   var dot = String( path ).lastIndexOf( "." );
   if ( dot <= slash )
      dot = path.length;
   var base = path.substring( 0, dot );
   var ext = path.substring( dot );
   if ( /_logo$/i.test( base ) )
      return base + "_2" + ext;
   return base + "_logo" + ext;
}

// Never return the source path, even when overwrite is on.
function asmdSafeOutputPath( path, srcPath, overwrite )
{
   var p = String( path || "" );
   if ( srcPath && asmdPathsEqual( p, srcPath ) )
      p = asmdWithLogoSuffix( p );
   var allow = !!overwrite && !(srcPath && asmdPathsEqual( p, srcPath ));
   p = asmdUniquePath( p, allow );
   if ( srcPath && asmdPathsEqual( p, srcPath ) )
      p = asmdUniquePath( asmdWithLogoSuffix( p ), false );
   return p;
}

// Loads a logo file as a Bitmap. Tries the direct Bitmap loader first, then
// falls back to opening the file as a PixInsight image and rendering it, which
// handles 16-bit PNGs and other files the Bitmap loader rejects.
function asmdLoadLogoBitmap( path )
{
   var bmp = null;
   try
   {
      bmp = new Bitmap( path );
      if ( !bmp || !(bmp.width > 0) || !(bmp.height > 0) )
         bmp = null;
   }
   catch ( e )
   {
      console.writeln( "   logo: direct load failed (" + e.message + "), trying image loader" );
      bmp = null;
   }
   if ( bmp )
      return bmp;

   var windows = null;
   try
   {
      windows = ImageWindow.open( path, "ASMD_logo_tmp", "", true );
      if ( windows && windows.length > 0 && !windows[0].isNull )
      {
         var image = windows[0].mainView.image;
         var r = image.render();
         if ( r && r.width > 0 && r.height > 0 )
            bmp = r;
      }
   }
   catch ( e2 )
   {
      console.writeln( "   logo: image loader failed (" + e2.message + ")" );
      bmp = null;
   }
   finally
   {
      if ( windows )
         for ( var i = 0; i < windows.length; ++i )
            if ( windows[i] && !windows[i].isNull )
               windows[i].forceClose();
   }
   return bmp;
}

// Opens a folder in the system file browser (File Explorer, Finder, or the
// Linux default). Returns true if the launch was attempted without error.
function asmdOpenFolder( dir )
{
   var platform = (typeof corePlatform != "undefined") ? String( corePlatform ) : "";
   var program, args;
   if ( platform.indexOf( "WINDOWS" ) >= 0 || platform.indexOf( "Windows" ) >= 0 )
   {
      program = "explorer.exe";
      args = [ dir.split( "/" ).join( String.fromCharCode( 92 ) ) ];   // forward to back slashes
   }
   else if ( platform.indexOf( "MAC" ) >= 0 || platform.indexOf( "Mac" ) >= 0 )
   {
      program = "/usr/bin/open";
      args = [ dir ];
   }
   else
   {
      program = "xdg-open";
      args = [ dir ];
   }
   try
   {
      // PixInsight's startDetached() takes one command line string.
      var cmd = program + " \"" + args[0] + "\"";
      var ok = false;
      if ( typeof ExternalProcess != "undefined" && ("startDetached" in ExternalProcess) )
      {
         try { ExternalProcess.startDetached( cmd ); ok = true; }
         catch ( e1 ) { ok = false; }
      }
      if ( !ok )
      {
         var P = new ExternalProcess;
         P.start( cmd );
      }
      return true;
   }
   catch ( e )
   {
      console.warningln( "Could not open the folder: " + e.message );
      return false;
   }
}

// Draws the watermark (text or logo image) on a transparent bitmap the size of
// the output image, then blends it onto the image. Must run inside a
// beginProcess/endProcess block on the target view.
function asmdApplyWatermark( view, opts )
{
   var img = view.image;
   var W = img.width, H = img.height;
   var shortEdge = Math.min( W, H );
   var margin = Math.max( 4, Math.round( shortEdge*0.025 ) );
   var opacity = Math.max( 0.05, Math.min( 1, opts.wmOpacity ) );
   var sizePx = Math.max( 8, Math.round( shortEdge*opts.wmSizePercent/100 ) );
   var text = asmdTrim( opts.wmText );

   if ( opts.wmMode != 1 && text.length == 0 )
      return false;

   // Load and scale the logo before painting starts.
   var logo = null, bw, bh;
   if ( opts.wmMode == 1 )
   {
      if ( !opts.wmLogoPath || !File.exists( opts.wmLogoPath ) )
         throw new Error( "Watermark logo file not found: " + opts.wmLogoPath );
      var src = asmdLoadLogoBitmap( opts.wmLogoPath );
      if ( !src )
         throw new Error( "Could not load the watermark logo: " + opts.wmLogoPath );
      bh = sizePx;
      bw = Math.max( 1, Math.round( src.width*bh/src.height ) );
      if ( bw > W - 2*margin )
      {
         bw = W - 2*margin;
         bh = Math.max( 1, Math.round( src.height*bw/src.width ) );
      }
      logo = src.scaledTo( bw, bh );
   }

   var font = new Font( FontFamily_SansSerif );
   font.pixelSize = sizePx;
   if ( !logo )
   {
      bw = font.width( text );
      bh = font.height;
   }

   // Positions: 0 TL, 1 TR, 2 BL, 3 BR, 4 center, 5 left center, 6 right center,
   // 7 top center, 8 bottom center.
   var at = asmdWatermarkPosition( opts.wmCorner, W, H, bw, bh, margin );
   var x = at.x, y = at.y;

   var bmp = new Bitmap( W, H );
   bmp.fill( 0x00000000 );
   var G = new Graphics( bmp );
   try
   {
      G.antialiasing = true;
      G.textAntialiasing = true;
      G.smoothInterpolation = true;
      if ( logo )
      {
         G.opacity = opacity;
         G.drawBitmap( x, y, logo );
      }
      else
      {
         G.font = font;
         var alpha = Math.round( 255*opacity );
         var baseline = y + font.ascent;
         var off = Math.max( 1, Math.round( sizePx/18 ) );
         // Soft dark shadow for legibility on bright nebulae, then the text.
         // Colors are 0xAARRGGBB; multiplication keeps them unsigned.
         G.pen = new Pen( Math.round( alpha*0.6 )*16777216 );
         G.drawText( x + off, baseline + off, text );
         G.pen = new Pen( alpha*16777216 + 0xffffff );
         G.drawText( x, baseline, text );
      }
   }
   finally
   {
      G.end();
   }
   img.blend( bmp );
   return true;
}

// Converts a color view to sRGB with ICCProfileTransformation, falling back
// to the PixInsight default RGB profile when the named profile is missing.
function asmdConvertToSRGB( view, notes )
{
   var P = new ICCProfileTransformation;
   P.targetProfile = ASMD_SRGB_PROFILE;
   P.toDefaultProfile = false;
   P.renderingIntent = ICCProfileTransformation.prototype.Perceptual;
   P.useBlackPointCompensation = true;
   P.useFloatingPointTransformation = true;
   try
   {
      if ( P.executeOn( view, false ) )
         return true;
   }
   catch ( x )
   {
      notes.push( "sRGB profile '" + ASMD_SRGB_PROFILE + "' not found (" + x.message +
                  "). Used the PixInsight default RGB profile instead." );
   }
   P.toDefaultProfile = true;
   P.executeOn( view, false );
   return false;
}

// Tags a view with the sRGB profile (no pixel change) so it gets embedded.
function asmdAssignSRGB( view, notes )
{
   var P = new AssignICCProfile;
   P.targetProfile = ASMD_SRGB_PROFILE;
   P.mode = AssignICCProfile.prototype.AssignNewProfile;
   try
   {
      if ( P.executeOn( view, false ) )
         return true;
   }
   catch ( x ) {}
   try
   {
      P.mode = AssignICCProfile.prototype.AssignDefaultProfile;
      P.executeOn( view, false );
   }
   catch ( x )
   {
      notes.push( "Could not tag the 8-bit image with an ICC profile: " + x.message );
   }
   return false;
}

// Saves a window as JPEG at the given quality and returns the file size.
// JPEG format hints are documented by the JPEG module in PixInsight's
// Format Explorer.
function asmdSaveJPEG( window, path, quality )
{
   asmdRemoveFile( path );
   var hints = "quality " + quality + " optimized no-progressive icc-profile no-xmp verbosity 0 non-interactive";
   if ( !window.saveAs( path, false/*queryOptions*/, false/*allowMessages*/,
                        false/*strict*/, false/*verifyOverwrite*/, hints ) )
      throw new Error( "Could not write " + path );
   if ( !File.exists( path ) )
      throw new Error( "File was not created: " + path );
   return asmdFileSize( path );
}

// Saves the window at its current pixel size. Searches from maxQuality down
// to minQuality and keeps the highest quality that fits. If minQuality is
// still over, fits is false and no final file is written (temps are removed).
// Returns { quality, bytes, fits, w, h, path, text }.
function asmdSaveJpegAtSize( window, finalPath, maxBytes, maxQuality, minQuality, progress )
{
   var w = window.mainView.image.width;
   var h = window.mainView.image.height;
   var dot = finalPath.lastIndexOf( "." );
   var stem = ((dot > 0) ? finalPath.substring( 0, dot ) : finalPath) + "_asmdtmp_q";
   var sizes = {};
   var paths = {};
   var written = [];

   function measure( q )
   {
      if ( sizes.hasOwnProperty( q ) )
         return sizes[q];
      if ( console.abortRequested )
         throw new Error( "Aborted by user." );
      var p = stem + q + ".jpg";
      written.push( p );
      var n = asmdSaveJPEG( window, p, q );
      sizes[q] = n;
      paths[q] = p;
      if ( progress )
         progress( "quality " + q + " at " + w + " x " + h + ": " + asmdMB( n/1024 ) );
      return n;
   }

   var picked = null;
   try
   {
      picked = asmdPickJpegQuality( measure, maxBytes, maxQuality, minQuality );
      picked.w = w;
      picked.h = h;
      picked.text = asmdFitStatusText( w, h, w, h, picked.quality, picked.bytes );
      if ( picked.fits )
      {
         asmdRemoveFile( finalPath );
         File.move( paths[picked.quality], finalPath );
         picked.path = finalPath;
      }
      else
         picked.path = "";
      return picked;
   }
   finally
   {
      for ( var i = 0; i < written.length; ++i )
         asmdRemoveFile( written[i] );
   }
}

// Writes a downscaled JPEG of srcWindow. Automatic size fitting always uses
// Mitchell-Netravali (choice 1), the script's reduction filter, so the search
// does not alias stars. The caller closes nothing; this function closes its
// temporary window.
function asmdSaveScaledJPEG( srcWindow, path, w, h, quality )
{
   var src = srcWindow.mainView.image;
   var isColor = src.isColor;
   var channels = isColor ? 3 : 1;
   var trial = asmdNewWindow( src.width, src.height, channels, 8, false, isColor );
   try
   {
      var v = trial.mainView;
      v.beginProcess( UndoFlag_NoSwapFile );
      v.image.assign( src );
      v.endProcess();
      asmdCopyICC( srcWindow, trial );
      asmdResampleView( v, w, h, 1, w/src.width );
      if ( isColor )
         asmdAssignSRGB( v, [] );
      return asmdSaveJPEG( trial, path, quality );
   }
   finally
   {
      asmdClose( trial );
   }
}

// Saves a JPEG at a fixed quality. Tries the window's current pixel size
// first. If that file is over maxBytes, searches for the largest smaller
// size that fits (about 1 to 2 percent), still at the same quality.
// Temporary files are written beside the final file and deleted.
// Returns { quality, bytes, fits, w, h, path, fromW, fromH, text }.
function asmdSaveFittingJpeg( window, finalPath, maxBytes, quality, overwrite, progress )
{
   var q = Math.round( Number( quality ) );
   if ( !(q >= ASMD_JPEG_SEARCH_FLOOR) )
      q = ASMD_JPEG_SEARCH_FLOOR;
   if ( q > ASMD_JPEG_QUALITY_MAX )
      q = ASMD_JPEG_QUALITY_MAX;
   var startW = window.mainView.image.width;
   var startH = window.mainView.image.height;
   var dot = finalPath.lastIndexOf( "." );
   var stem = ((dot > 0) ? finalPath.substring( 0, dot ) : finalPath) + "_asmdtmp_s";
   var written = [];
   var seq = 0;

   function measure( scale )
   {
      if ( console.abortRequested )
         throw new Error( "Aborted by user." );
      var sz = asmdScaledSize( startW, startH, scale );
      var p = stem + seq + ".jpg";
      ++seq;
      written.push( p );
      var n = (sz.w == startW && sz.h == startH)
              ? asmdSaveJPEG( window, p, q )
              : asmdSaveScaledJPEG( window, p, sz.w, sz.h, q );
      if ( progress )
         progress( "quality " + q + " at " + sz.w + " x " + sz.h + ": " + asmdMB( n/1024 ) );
      return { w: sz.w, h: sz.h, scale: sz.w/startW, bytes: n, path: p };
   }

   try
   {
      var fit = asmdFitScale( measure, maxBytes, ASMD_SCALE_TOLERANCE, asmdMinFitScale( startW, startH ) );
      var dest = asmdPathWithSize( finalPath, startW, startH, fit.w, fit.h, overwrite );
      asmdRemoveFile( dest );
      File.move( fit.path, dest );
      fit.path = dest;
      fit.quality = q;
      fit.fromW = startW;
      fit.fromH = startH;
      fit.text = asmdFitStatusText( startW, startH, fit.w, fit.h, q, fit.bytes );
      return fit;
   }
   finally
   {
      for ( var i = 0; i < written.length; ++i )
         asmdRemoveFile( written[i] );
   }
}

var asmdTempCounter = 0;

// Hidden temporary image window (never shown in the workspace).
function asmdNewWindow( w, h, channels, bits, isFloat, isColor )
{
   ++asmdTempCounter;
   return new ImageWindow( w, h, channels, bits, isFloat, isColor,
                           "ASMD_SocialExport_tmp" + asmdTempCounter );
}

function asmdClose( win )
{
   try
   {
      if ( win && !win.isNull )
         win.forceClose();
   }
   catch ( x ) {}
}

// Resamples a view to exactly outW x outH. scale = output width / input width.
function asmdResampleView( v, outW, outH, choice, scale )
{
   var R = new Resample;
   R.xSize = outW;
   R.ySize = outH;
   R.mode = Resample.prototype.AbsolutePixels;
   R.absoluteMode = Resample.prototype.ForceWidthAndHeight;
   R.interpolation = asmdInterpolation( choice, scale );
   R.clampingThreshold = 0.30;
   R.smoothness = 1.50;
   R.xResolution = 72;
   R.yResolution = 72;
   R.metric = false;
   R.forceResolution = false;
   R.executeOn( v, false );
   if ( v.image.width != outW || v.image.height != outH )
      throw new Error( "Resample produced " + v.image.width + " x " + v.image.height +
                       " instead of " + outW + " x " + outH + "." );
}

// Output sharpening, scaled to the reduction factor: larger reductions get a
// slightly wider, stronger mask. Deringing keeps dark halos away from stars.
// Luminance only, to avoid color noise.
function asmdSharpenView( v, strength, scale, isColor, progress )
{
   var stops = (scale < 1) ? Math.log( 1/scale )/Math.LN2 : 0;   // halvings of size
   // Strength 0.25 is gentle, 0.5 moderate, 1.0 clearly strong.
   var st = strength;
   var sigma = Math.min( 2.0, 0.70 + 0.50*st + 0.10*Math.min( stops, 4 ) );
   var amount = 0.15 + 0.80*st + 0.03*Math.min( stops, 4 );
   amount = Math.max( 0.10, Math.min( 0.95, amount ) );
   progress( "sharpening (sigma " + sigma.toFixed( 2 ) + ", amount " + amount.toFixed( 2 ) + ")" );
   var U = new UnsharpMask;
   U.sigma = sigma;
   U.amount = amount;
   U.useLuminance = isColor;
   U.linear = false;
   U.deringing = true;
   U.deringingDark = 0.10;
   U.deringingBright = 0.00;
   U.outputDeringingMaps = false;
   U.rangeLow = 0;
   U.rangeHigh = 0;
   U.executeOn( v, false );
}

// SOURCE, JPEG, or PNG. Anything else uses fallback (SOURCE for new
// settings, JPEG for saved jobs that predate the choice).
function asmdStoredLogoFormat( value, fallback )
{
   if ( value == "PNG" || value == "JPEG" || value == "SOURCE" )
      return value;
   return fallback || "SOURCE";
}

function asmdLogoFormatComboIndex( format )
{
   if ( format == "JPEG" )
      return 1;
   if ( format == "PNG" )
      return 2;
   return 0;
}

function asmdLogoFormatFromComboIndex( index )
{
   if ( index == 1 )
      return "JPEG";
   if ( index == 2 )
      return "PNG";
   return "SOURCE";
}

// File type from the view's path. Unknown or missing paths fall back to TIFF.
function asmdDetectSourceFormat( path )
{
   var text = asmdTrim( path || "" );
   var ext = asmdFileExtension( text );
   if ( ext == "tif" || ext == "tiff" )
      return { id: "TIFF", ext: (ext == "tiff") ? ".tiff" : ".tif", fallback: false, reason: "" };
   if ( ext == "png" )
      return { id: "PNG", ext: ".png", fallback: false, reason: "" };
   if ( ext == "jpg" || ext == "jpeg" )
      return { id: "JPEG", ext: (ext == "jpeg") ? ".jpeg" : ".jpg", fallback: false, reason: "" };
   if ( ext == "xisf" )
      return { id: "XISF", ext: ".xisf", fallback: false, reason: "" };
   if ( ext == "fits" || ext == "fit" )
      return { id: "FITS", ext: (ext == "fits") ? ".fits" : ".fit", fallback: false, reason: "" };
   return { id: "TIFF", ext: ".tif", fallback: true, reason: (text.length == 0) ? "no-path" : "unknown" };
}

function asmdLogoSourceFileName( baseName, ext )
{
   var base = asmdSafeFileToken( baseName );
   var e = String( ext || ".tif" );
   if ( e.charAt( 0 ) != "." )
      e = "." + e;
   return base + "_logo" + e.toLowerCase();
}

function asmdImageSampleInfo( image, window )
{
   var bits = 0, isFloat = false, sawBits = false, sawFloat = false;
   try
   {
      if ( image && ("bitsPerSample" in image) && image.bitsPerSample > 0 )
      {
         bits = image.bitsPerSample;
         sawBits = true;
      }
   }
   catch ( e ) {}
   if ( !sawBits )
   {
      try
      {
         if ( window && ("bitsPerSample" in window) && window.bitsPerSample > 0 )
         {
            bits = window.bitsPerSample;
            sawBits = true;
         }
      }
      catch ( e2 ) {}
   }
   try
   {
      if ( image && ("isFloatSample" in image) )
      {
         isFloat = !!image.isFloatSample;
         sawFloat = true;
      }
   }
   catch ( e3 ) {}
   if ( !sawFloat )
   {
      try
      {
         if ( window && ("isFloatSample" in window) )
         {
            isFloat = !!window.isFloatSample;
            sawFloat = true;
         }
      }
      catch ( e4 ) {}
   }
   if ( !sawBits )
      bits = 16;
   if ( !sawFloat )
      isFloat = (bits >= 32);
   if ( bits <= 8 )
      bits = 8;
   else if ( bits <= 16 )
      bits = 16;
   else if ( bits <= 32 )
      bits = 32;
   else
      bits = 64;
   if ( isFloat && bits < 32 )
      bits = 32;
   return { bits: bits, isFloat: !!isFloat };
}

function asmdSampleLabel( sample )
{
   if ( !sample )
      return "16-bit";
   if ( sample.isFloat )
      return (sample.bits >= 64) ? "64-bit float" : "32-bit float";
   return sample.bits + "-bit";
}

function asmdFormatHints( formatId, sample, quality )
{
   var bits = sample ? sample.bits : 16;
   var isFloat = sample ? sample.isFloat : false;
   var depth = "unsigned 16";
   if ( isFloat )
      depth = (bits >= 64) ? "double" : "float";
   else if ( bits <= 8 )
      depth = "unsigned 8";
   else if ( bits <= 16 )
      depth = "unsigned 16";
   else if ( bits <= 32 )
      depth = "unsigned 32";
   else
      depth = "unsigned 64";
   var q = asmdClampJpegQuality( quality );
   if ( formatId == "JPEG" )
      return "quality " + q + " optimized no-progressive icc-profile verbosity 0 non-interactive";
   if ( formatId == "PNG" )
      return ((bits > 8 && !isFloat) ? "unsigned 16" : "unsigned 8") + " icc-profile verbosity 0 non-interactive";
   if ( formatId == "TIFF" )
      return depth + " compression zip icc-profile verbosity 0 non-interactive";
   if ( formatId == "XISF" )
      return "compression zlib icc-profile verbosity 0 non-interactive";
   if ( formatId == "FITS" )
      return depth + " verbosity 0 non-interactive";
   return "verbosity 0 non-interactive";
}

function asmdProfileDescription( window )
{
   try
   {
      if ( window && ("iccProfile" in window) )
      {
         var icc = window.iccProfile;
         if ( icc && ("isEmpty" in icc) && !icc.isEmpty && ("description" in icc) && icc.description )
            return String( icc.description );
      }
   }
   catch ( e ) {}
   return "";
}

function asmdViewProperties( window )
{
   try
   {
      if ( window && window.mainView && ("properties" in window.mainView) &&
           window.mainView.properties && window.mainView.properties.length > 0 )
         return window.mainView.properties;
   }
   catch ( e ) {}
   try
   {
      if ( window && ("properties" in window) && window.properties && window.properties.length > 0 )
         return window.properties;
   }
   catch ( e2 ) {}
   return null;
}

function asmdPushFormatMetadata( instance, format, srcWindow, notes )
{
   try
   {
      if ( format && ("canStoreKeywords" in format) && format.canStoreKeywords &&
           srcWindow && ("keywords" in srcWindow) )
      {
         var kw = srcWindow.keywords;
         if ( kw && kw.length > 0 )
         {
            if ( "keywords" in instance )
               instance.keywords = kw;
         }
      }
   }
   catch ( e )
   {
      notes.push( "Could not copy FITS keywords: " + e.message );
   }
   try
   {
      if ( format && ("canStoreICCProfiles" in format) && format.canStoreICCProfiles &&
           srcWindow && ("iccProfile" in srcWindow) )
      {
         var icc = srcWindow.iccProfile;
         if ( icc && !(("isEmpty" in icc) && icc.isEmpty) )
         {
            if ( "iccProfile" in instance )
               instance.iccProfile = icc;
         }
      }
   }
   catch ( e2 )
   {
      notes.push( "Could not copy the ICC profile: " + e2.message );
   }
   try
   {
      var props = asmdViewProperties( srcWindow );
      if ( props )
      {
         var storeImage = format && ("canStoreImageProperties" in format) && format.canStoreImageProperties;
         var storeFile = format && ("canStoreProperties" in format) && format.canStoreProperties;
         if ( storeImage && ("imageProperties" in instance) )
            instance.imageProperties = props;
         else if ( storeFile && ("properties" in instance) )
            instance.properties = props;
      }
   }
   catch ( e3 )
   {
      notes.push( "Could not copy image properties: " + e3.message );
   }
}

function asmdWriteWithFormat( window, path, formatId, ext, sample, srcWindow, quality, notes )
{
   var hints = asmdFormatHints( formatId, sample, quality );
   var fmt = null;
   try
   {
      fmt = new FileFormat( ext, false, true );
   }
   catch ( eFmt ) { fmt = null; }
   if ( !fmt || (("isNull" in fmt) && fmt.isNull) )
   {
      var bare = (ext.charAt( 0 ) == ".") ? ext.substring( 1 ) : ext;
      try
      {
         fmt = new FileFormat( bare, false, true );
      }
      catch ( eFmt2 ) { fmt = null; }
   }
   if ( !fmt || (("isNull" in fmt) && fmt.isNull) )
      throw new Error( "No installed file format can write " + ext + " files." );
   var inst = new FileFormatInstance( fmt );
   if ( !inst || (("isNull" in inst) && inst.isNull) )
      throw new Error( "Could not open the " + formatId + " writer." );
   asmdRemoveFile( path );
   try
   {
      if ( !inst.create( path, hints ) )
         throw new Error( "Could not create " + path );
      asmdPushFormatMetadata( inst, fmt, srcWindow, notes );
      if ( !inst.writeImage( window.mainView.image ) )
         throw new Error( "Could not write " + path );
   }
   finally
   {
      try { inst.close(); } catch ( eClose ) {}
   }
   if ( !File.exists( path ) )
      throw new Error( "File was not created: " + path );
   return asmdFileSize( path );
}

function asmdOpenFirstWindow( path )
{
   var windows = null;
   try
   {
      windows = ImageWindow.open( path, "ASMD_logo_src", "", true );
   }
   catch ( e )
   {
      windows = null;
   }
   if ( windows && windows.length > 0 && windows[0] && !windows[0].isNull )
   {
      for ( var i = 1; i < windows.length; ++i )
         asmdClose( windows[i] );
      return windows[0];
   }
   if ( windows )
      for ( var j = 0; j < windows.length; ++j )
         asmdClose( windows[j] );
   return null;
}

function asmdConvertLogoToTarget( logoWindow, targetWindow, notes )
{
   if ( !logoWindow || !logoWindow.mainView || !logoWindow.mainView.image.isColor )
      return;
   if ( !targetWindow || !targetWindow.mainView || !targetWindow.mainView.image.isColor )
      return;
   var srcDesc = asmdProfileDescription( logoWindow );
   var dstDesc = asmdProfileDescription( targetWindow );
   if ( srcDesc.length == 0 )
      srcDesc = ASMD_SRGB_PROFILE;
   if ( dstDesc.length == 0 )
      dstDesc = ASMD_SRGB_PROFILE;
   if ( srcDesc == dstDesc )
      return;
   var P = new ICCProfileTransformation;
   P.sourceProfile = srcDesc;
   P.targetProfile = dstDesc;
   P.toDefaultProfile = false;
   P.renderingIntent = ICCProfileTransformation.prototype.Perceptual;
   P.useBlackPointCompensation = true;
   P.useFloatingPointTransformation = true;
   try
   {
      if ( !P.executeOn( logoWindow.mainView, false ) )
         notes.push( "Could not convert the logo into the image color profile. The logo keeps its own colors." );
   }
   catch ( e )
   {
      notes.push( "Could not convert the logo into the image color profile (" + e.message + "). The logo keeps its own colors." );
   }
}

function asmdCopyChannelRect( srcImage, dstImage, channel, sx, sy, dx, dy, w, h )
{
   var band = 128, y, bh, buf, useTyped;
   for ( y = 0; y < h; y += band )
   {
      bh = Math.min( band, h - y );
      useTyped = (typeof Float32Array != "undefined");
      buf = useTyped ? new Float32Array( w * bh ) : [];
      try
      {
         srcImage.getSamples( buf, new Rect( sx, sy + y, sx + w, sy + y + bh ), channel );
      }
      catch ( xs )
      {
         if ( !useTyped )
            throw xs;
         buf = [];
         srcImage.getSamples( buf, new Rect( sx, sy + y, sx + w, sy + y + bh ), channel );
      }
      dstImage.setSamples( buf, new Rect( dx, dy + y, dx + w, dy + y + bh ), channel );
   }
}

// Puts the logo on the view at the view's sample format. The logo is
// converted into the image profile first. Transparency comes from the logo
// bitmap when that bitmap can be loaded. Returns false when the file cannot
// be opened, so the caller can use the bitmap blend instead.
function asmdCompositeLogo( view, opts, targetWindow, notes )
{
   var path = opts.wmLogoPath;
   if ( !path || !File.exists( path ) )
      return false;
   var logoWin = asmdOpenFirstWindow( path );
   if ( !logoWin )
      return false;
   var scaled = null, overlay = null;
   try
   {
      asmdConvertLogoToTarget( logoWin, targetWindow, notes );
      var img = view.image;
      var W = img.width, H = img.height;
      var isColor = !!img.isColor;
      var channels = isColor ? 3 : 1;
      var sample = asmdImageSampleInfo( img, targetWindow );
      var srcImg = logoWin.mainView.image;
      var shortEdge = Math.min( W, H );
      var margin = Math.max( 4, Math.round( shortEdge * 0.025 ) );
      var opacity = Math.max( 0.05, Math.min( 1, opts.wmOpacity ) );
      var sizePx = Math.max( 8, Math.round( shortEdge * opts.wmSizePercent / 100 ) );
      var bh = sizePx;
      var bw = Math.max( 1, Math.round( srcImg.width * bh / Math.max( 1, srcImg.height ) ) );
      if ( bw > W - 2 * margin )
      {
         bw = Math.max( 1, W - 2 * margin );
         bh = Math.max( 1, Math.round( srcImg.height * bw / Math.max( 1, srcImg.width ) ) );
      }
      scaled = asmdNewWindow( srcImg.width, srcImg.height, channels, sample.bits, sample.isFloat, isColor );
      var sv = scaled.mainView;
      sv.beginProcess( UndoFlag_NoSwapFile );
      try
      {
         if ( !!srcImg.isColor == isColor )
            sv.image.assign( srcImg );
         else
            asmdCopyChannelRect( srcImg, sv.image, 0, 0, 0, 0, 0, srcImg.width, srcImg.height );
      }
      finally
      {
         sv.endProcess();
      }
      if ( srcImg.width != bw || srcImg.height != bh )
         asmdResampleView( sv, bw, bh, 1, bw / Math.max( 1, srcImg.width ) );

      var bmp = null;
      try
      {
         bmp = new Bitmap( path );
         if ( !bmp || !(bmp.width > 0) || !(bmp.height > 0) )
            bmp = null;
         else if ( bmp.width != bw || bmp.height != bh )
            bmp = bmp.scaledTo( bw, bh );
      }
      catch ( eb )
      {
         bmp = null;
      }

      var at = asmdWatermarkPosition( opts.wmCorner, W, H, bw, bh, margin );
      overlay = asmdNewWindow( W, H, channels + 1, sample.bits, sample.isFloat, isColor );
      var ov = overlay.mainView;
      ov.beginProcess( UndoFlag_NoSwapFile );
      try
      {
         try { ov.image.fill( 0 ); } catch ( ef ) {}
         asmdCopyChannelRect( sv.image, ov.image, 0, 0, 0, at.x, at.y, bw, bh );
         if ( channels > 1 )
         {
            asmdCopyChannelRect( sv.image, ov.image, Math.min( 1, sv.image.numberOfChannels - 1 ), 0, 0, at.x, at.y, bw, bh );
            asmdCopyChannelRect( sv.image, ov.image, Math.min( 2, sv.image.numberOfChannels - 1 ), 0, 0, at.x, at.y, bw, bh );
         }
         asmdWriteOpacityAlpha( ov.image, at.x, at.y, bw, bh, opacity, bmp, sample );
      }
      finally
      {
         ov.endProcess();
      }
      img.blend( ov.image );
      notes.push( "Logo blended in the image sample format (" + asmdSampleLabel( sample ) + ")." );
      return true;
   }
   finally
   {
      asmdClose( scaled );
      asmdClose( overlay );
      asmdClose( logoWin );
   }
}

function asmdWriteOpacityAlpha( image, x, y, w, h, opacity, bmp, sample )
{
   var alphaCh = image.isColor ? 3 : 1;
   var maxV = 1;
   if ( !sample.isFloat )
   {
      if ( sample.bits <= 8 )
         maxV = 255;
      else if ( sample.bits <= 16 )
         maxV = 65535;
      else
         maxV = 4294967295;
   }
   var row, ix, a, pix, buf;
   for ( row = 0; row < h; ++row )
   {
      buf = (typeof Float32Array != "undefined") ? new Float32Array( w ) : [];
      for ( ix = 0; ix < w; ++ix )
      {
         a = opacity;
         if ( bmp )
         {
            try
            {
               pix = bmp.pixel( ix, row );
               a = opacity * (((pix >>> 24) & 255) / 255);
            }
            catch ( ep ) {}
         }
         buf[ix] = a * maxV;
      }
      image.setSamples( buf, new Rect( x, y + row, x + w, y + row + 1 ), alphaCh );
   }
}

// Text uses the existing bitmap blend, which stays in the image's sample
// range. A logo file is converted into the image profile and sample format.
function asmdApplyWatermarkForDepth( view, opts, targetWindow, notes )
{
   if ( opts.wmMode == 1 )
   {
      try
      {
         if ( asmdCompositeLogo( view, opts, targetWindow, notes ) )
            return true;
      }
      catch ( e )
      {
         notes.push( "Could not convert the logo into the image sample format (" + e.message + "). Blended the logo preview instead." );
      }
   }
   return asmdApplyWatermark( view, opts );
}

// Original size + Same as source. No sRGB conversion and no 8-bit step.
// The logo is composited at the image depth, then written with FileFormat.
function asmdExportSameAsSource( job, progress )
{
   var srcWindow = job.srcWindow;
   var src = srcWindow.mainView.image;
   var notes = [];
   var opts = job.opts;
   var isColor = src.isColor;
   var channels = isColor ? 3 : 1;
   var srcPath = "";
   try
   {
      if ( srcWindow && ("filePath" in srcWindow) && srcWindow.filePath )
         srcPath = srcWindow.filePath;
   }
   catch ( ePath ) {}
   var resolved = asmdDetectSourceFormat( srcPath );
   var sample = asmdImageSampleInfo( src, srcWindow );
   if ( resolved.fallback )
   {
      sample = { bits: 16, isFloat: false };
      var why = (resolved.reason == "no-path")
         ? "This image has no file path, so Same as source is writing 16-bit TIFF."
         : "Same as source does not recognize this file type, so the file is 16-bit TIFF.";
      notes.push( why );
      progress( why );
   }
   if ( resolved.id == "PNG" && sample.isFloat )
   {
      sample = { bits: 16, isFloat: false };
      notes.push( "PNG cannot store floating point samples. Writing 16-bit PNG." );
   }
   if ( resolved.id == "JPEG" )
      notes.push( "JPEG is saved at quality " + asmdClampJpegQuality( opts.jpegQuality ) + ". JPEG files are 8-bit." );
   else if ( !resolved.fallback )
      progress( "keeping " + resolved.id + ", " + asmdSampleLabel( sample ) + ", " + src.width + " x " + src.height );

   var work = null;
   try
   {
      progress( "copying " + src.width + " x " + src.height + " at " + asmdSampleLabel( sample ) );
      work = asmdNewWindow( src.width, src.height, channels, sample.bits, sample.isFloat, isColor );
      var v = work.mainView;
      v.beginProcess( UndoFlag_NoSwapFile );
      v.image.assign( src );
      v.endProcess();
      asmdCopyICC( srcWindow, work );
      if ( opts.wmEnabled )
      {
         progress( "adding watermark" );
         v.beginProcess( UndoFlag_NoSwapFile );
         try
         {
            asmdApplyWatermarkForDepth( v, opts, srcWindow, notes );
         }
         finally
         {
            v.endProcess();
         }
      }
      progress( "saving " + resolved.id );
      var bytes = asmdWriteWithFormat( work, job.outPath, resolved.id, resolved.ext, sample, srcWindow,
                                       opts.jpegQuality, notes );
      var quality = "16-bit";
      if ( resolved.id == "JPEG" )
         quality = asmdClampJpegQuality( opts.jpegQuality );
      else if ( resolved.id == "PNG" )
         quality = "PNG";
      else if ( sample.isFloat )
         quality = "float";
      else
         quality = sample.bits + "-bit";
      return {
         name: job.preset.name, path: job.outPath, w: src.width, h: src.height,
         format: resolved.id, maxKB: job.preset.maxKB, notes: notes, ok: true,
         bytes: bytes, quality: quality, fits: true, sameSource: true,
         detail: resolved.id + " " + asmdSampleLabel( sample )
      };
   }
   finally
   {
      asmdClose( work );
   }
}

// Processes one target. Never modifies the source window: all work happens
// on hidden temporary windows that are closed at the end.
//   job = { preset, crop, outPath, opts, srcWindow, carouselSlide }
// Full frame fit and logo-only skip the crop and the preset pixel size.
// Preset JPEGs keep that pixel size and search quality from the chosen
// maximum down to 75. Full frame Highest quality holds the chosen quality
// and resizes instead. Returns a result object for the summary; throws on errors.
function asmdExportOne( job, progress )
{
   var optsEarly = job.opts;
   if ( optsEarly && optsEarly.logoOnly && !optsEarly.fullFrameFit && optsEarly.logoFormat == "SOURCE" )
      return asmdExportSameAsSource( job, progress );
   var src = job.srcWindow.mainView.image;
   var srcW = src.width, srcH = src.height;
   var notes = [];
   var isColor = src.isColor;
   var channels = isColor ? 3 : 1;
   var opts = job.opts;
   var whole = !!(opts.fullFrameFit || opts.logoOnly);
   var rect, cropW, cropH, outW, outH, scale;

   if ( whole )
   {
      rect = asmdCropRect( { x: 0, y: 0, w: srcW, h: srcH }, srcW, srcH );
      cropW = rect.width;
      cropH = rect.height;
      outW = cropW;
      outH = cropH;
      scale = 1;
      if ( opts.logoOnly && opts.fullFrameFit )
         notes.push( "Logo only, full frame: watermark only, then fit to the size target." );
      else if ( opts.logoOnly )
         notes.push( "Logo only: no crop, no sharpening, no preset resize." );
      else
         notes.push( "Full frame: no crop. Preset pixel size is not used." );
   }
   else
   {
      var geo = asmdPresetGeometry( job.preset, srcW, srcH );
      rect = asmdCropRect( job.crop, srcW, srcH );
      cropW = rect.width;
      cropH = rect.height;
      outW = geo.w;
      outH = geo.h;

      // Optionally avoid enlarging a small crop.
      if ( cropW < outW && opts.noUpscale )
      {
         var f = cropW/outW;
         outW = Math.max( 1, Math.round( outW*f ) );
         outH = Math.max( 1, Math.round( outH*f ) );
         notes.push( "Output reduced to " + outW + " x " + outH + " to avoid enlarging." );
      }
      else if ( cropW < outW )
         notes.push( "The crop is smaller than the output size, so the image was enlarged." );
      scale = outW/cropW;
   }

   var work = null, out8 = null;
   try
   {
      // 1. Duplicate + crop: copy only the crop rectangle and the color
      //    channels (no alpha) into a new 32-bit float window.
      //    Full frame and logo-only copy the whole image.
      progress( "cropping " + cropW + " x " + cropH + " at (" + rect.x0 + ", " + rect.y0 + ")" );
      work = asmdNewWindow( cropW, cropH, channels, 32, true, isColor );
      var v = work.mainView;
      v.beginProcess( UndoFlag_NoSwapFile );
      v.image.assign( src, rect, 0, channels - 1 );
      v.endProcess();

      // Carry the source ICC profile over when the core exposes it
      // (ImageWindow.iccProfile, PixInsight 1.9.6 and later). Older cores
      // treat the copy as the default RGB profile, normally sRGB.
      try
      {
         var icc = job.srcWindow.iccProfile;
         if ( icc && !icc.isEmpty )
            work.iccProfile = icc;
      }
      catch ( x ) {}

      // 2. Resample to the preset size. Full frame and logo-only stay at the
      //    source size until the JPEG size fit, if any.
      if ( !whole && (cropW != outW || cropH != outH) )
      {
         progress( "resampling to " + outW + " x " + outH + " (" + asmdInterpolationName( opts.interpolation, scale ) + ")" );
         asmdResampleView( v, outW, outH, opts.interpolation, scale );
      }

      // 3. Output sharpening. Logo-only never sharpens.
      if ( !opts.logoOnly && opts.sharpenEnabled && job.preset.sharpen && opts.sharpenStrength > 0.001 )
         asmdSharpenView( v, opts.sharpenStrength, scale, isColor, progress );

      // 4. Convert to sRGB (color images only). JPEG and PNG need this so
      //    viewers show the right colors. Logo-only does not skip it.
      if ( isColor )
      {
         progress( "converting to sRGB" );
         asmdConvertToSRGB( v, notes );
      }

      // 5. Watermark, drawn at full float precision before the 8-bit step.
      if ( opts.wmEnabled )
      {
         progress( "adding watermark" );
         v.beginProcess( UndoFlag_NoSwapFile );
         try
         {
            asmdApplyWatermark( v, opts );
         }
         finally
         {
            v.endProcess();
         }
      }

      // 6. Convert to 8-bit: assign into an 8-bit integer window (rounds
      //    [0,1] floats to 0..255), then tag it as sRGB so the profile is
      //    embedded in the file.
      progress( "converting to 8-bit" );
      out8 = asmdNewWindow( outW, outH, channels, 8, false, isColor );
      var v8 = out8.mainView;
      v8.beginProcess( UndoFlag_NoSwapFile );
      v8.image.assign( v.image );
      v8.endProcess();
      asmdClose( work );
      work = null;
      if ( isColor )
         asmdAssignSRGB( v8, notes );

      // 7. Save. JPEG holds the chosen quality and downscales to the target.
      //    PNG keeps the pixel size above and is flagged if it is over.
      var maxBytes = Math.round( job.preset.maxKB*1024 );
      var res = { name: job.preset.name, path: job.outPath, w: outW, h: outH,
                  format: job.preset.format, maxKB: job.preset.maxKB, notes: notes, ok: false };
      if ( job.preset.format == "PNG" )
      {
         progress( "saving PNG" );
         asmdRemoveFile( job.outPath );
         if ( !out8.saveAs( job.outPath, false, false, false, false, "icc-profile verbosity 0 non-interactive" ) )
            throw new Error( "Could not write " + job.outPath );
         res.bytes = asmdFileSize( job.outPath );
         res.quality = "PNG";
         res.fits = res.bytes <= maxBytes;
         if ( !res.fits )
            notes.push( "The PNG is larger than the " + asmdMB( job.preset.maxKB ) + " target. Use JPEG or raise the target." );
      }
      else
      {
         var maxQ = asmdClampJpegQuality( opts.jpegQuality );
         // Full frame Highest quality holds the chosen quality and resizes.
         // Everything else keeps the current pixel size and may drop quality to 75.
         var holdQuality = !!(opts.fullFrameFit) && opts.fullFramePriority != 1;
         if ( holdQuality )
         {
            progress( "fitting JPEG at quality " + maxQ + " for " + asmdMB( job.preset.maxKB ) + " or less" );
            var held = asmdSaveFittingJpeg( out8, job.outPath, maxBytes, maxQ, !!opts.overwrite, progress );
            res.bytes = held.bytes;
            res.quality = held.quality;
            res.w = held.w;
            res.h = held.h;
            res.path = held.path;
            res.fits = held.fits;
            progress( held.text );
            if ( !held.fits )
               notes.push( "Still over " + asmdMB( job.preset.maxKB ) + " at quality " + maxQ +
                           " after resizing to " + held.w + " x " + held.h + " (" + asmdMB( held.bytes/1024 ) +
                           "). Saved that size. Raise the target." );
            else if ( held.w != held.fromW || held.h != held.fromH )
               notes.push( "Resized with Mitchell-Netravali to stay at quality " + maxQ + "." );
         }
         else
         {
            progress( "searching JPEG quality from " + maxQ + " down to " + ASMD_JPEG_SEARCH_FLOOR +
                      " for " + asmdMB( job.preset.maxKB ) + " or less" );
            var picked = asmdSaveJpegAtSize( out8, job.outPath, maxBytes, maxQ, ASMD_JPEG_SEARCH_FLOOR, progress );
            if ( picked.fits )
            {
               res.bytes = picked.bytes;
               res.quality = picked.quality;
               res.w = picked.w;
               res.h = picked.h;
               res.path = picked.path;
               res.fits = true;
               progress( picked.text );
            }
            else
            {
               progress( "Quality " + ASMD_JPEG_SEARCH_FLOOR + " is still over " + asmdMB( job.preset.maxKB ) +
                         " at " + picked.w + " x " + picked.h + ". Resizing smaller at quality " +
                         ASMD_JPEG_SEARCH_FLOOR + "." );
               var shrunk = asmdSaveFittingJpeg( out8, job.outPath, maxBytes, ASMD_JPEG_SEARCH_FLOOR,
                                                  !!opts.overwrite, progress );
               var resort = asmdLastResortText( picked.w, picked.h, shrunk.w, shrunk.h,
                                                 ASMD_JPEG_SEARCH_FLOOR, shrunk.bytes, job.preset.maxKB );
               res.bytes = shrunk.bytes;
               res.quality = shrunk.quality;
               res.w = shrunk.w;
               res.h = shrunk.h;
               res.path = shrunk.path;
               res.fits = shrunk.fits;
               progress( resort );
               notes.push( resort );
               if ( job.carouselSlide && (shrunk.w != picked.w || shrunk.h != picked.h) )
                  notes.push( "This slide was resized below the platform size, so its pixel size may not match the other slides." );
               if ( !shrunk.fits )
                  notes.push( "Still over " + asmdMB( job.preset.maxKB ) + " at " + shrunk.w + " x " + shrunk.h +
                              " (" + asmdMB( shrunk.bytes/1024 ) + "). Saved that size. Raise the target." );
            }
         }
      }
      res.ok = true;
      return res;
   }
   finally
   {
      asmdClose( work );
      asmdClose( out8 );
   }
}


// ============================================================================
// Carousel export helpers
// ============================================================================

// Copies the ICC profile of one window to another when the core supports it.
function asmdCopyICC( fromWindow, toWindow )
{
   try
   {
      var icc = fromWindow.iccProfile;
      if ( icc && !icc.isEmpty )
         toWindow.iccProfile = icc;
   }
   catch ( x ) {}
}

// Builds a hidden window holding the whole source image centered on black,
// padded to the given aspect (width/height). Used for "whole image, fitted"
// slides. The caller closes the returned window.
function asmdMakePaddedWindow( srcWindow, aspect )
{
   var src = srcWindow.mainView.image;
   var w = src.width, h = src.height;
   var isColor = src.isColor, channels = isColor ? 3 : 1;
   var PW, PH;
   if ( w/h > aspect )
   {
      PW = w;
      PH = Math.max( h, Math.round( w/aspect ) );
   }
   else
   {
      PH = h;
      PW = Math.max( w, Math.round( h*aspect ) );
   }
   var ox = Math.floor( (PW - w)/2 ), oy = Math.floor( (PH - h)/2 );
   var win = asmdNewWindow( PW, PH, channels, 32, true, isColor );
   try
   {
      var v = win.mainView;
      v.beginProcess( UndoFlag_NoSwapFile );
      try
      {
         try { v.image.fill( 0 ); } catch ( xf ) {}   /* new images start black anyway */
         // Copy in bands of rows to keep memory use modest.
         var band = 256, useTyped = (typeof Float32Array != "undefined");
         for ( var y = 0; y < h; y += band )
         {
            var bh = Math.min( band, h - y );
            var buf = useTyped ? new Float32Array( w*bh ) : [];
            for ( var c = 0; c < channels; ++c )
            {
               try
               {
                  src.getSamples( buf, new Rect( 0, y, w, y + bh ), c );
               }
               catch ( xs )
               {
                  if ( !useTyped )
                     throw xs;
                  // Older cores may want a plain Array.
                  useTyped = false;
                  buf = [];
                  src.getSamples( buf, new Rect( 0, y, w, y + bh ), c );
               }
               v.image.setSamples( buf, new Rect( ox, oy + y, ox + w, oy + y + bh ), c );
            }
         }
      }
      finally
      {
         v.endProcess();
      }
      asmdCopyICC( srcWindow, win );
      return win;
   }
   catch ( x )
   {
      asmdClose( win );
      throw x;
   }
}

// Crops a panorama or grid box from the source and resamples it ONCE to
// cols*slideW x rows*slideH, then applies output sharpening to the whole
// image (so no tile edge is sharpened differently). Tiles are later cut
// at exact multiples of the slide size. The caller closes the returned window.
// kind is "panorama" or "grid" and is used only in progress messages.
function asmdMakeGridStrip( srcWindow, crop, cols, rows, slideW, slideH, opts, progress, kind )
{
   var src = srcWindow.mainView.image;
   var rect = asmdCropRect( crop, src.width, src.height );
   var geo = asmdGridGeometry( cols, rows, slideW, slideH );
   if ( rows == 1 )
      geo.panels = geo.tiles;
   var isColor = src.isColor, channels = isColor ? 3 : 1;
   var scale = geo.stripW/rect.width;
   var win = asmdNewWindow( rect.width, rect.height, channels, 32, true, isColor );
   var label = kind || "grid";
   var whole = (rows > 1) ? "grid" : "strip";
   try
   {
      var v = win.mainView;
      progress( label + ": cropping " + rect.width + " x " + rect.height + " at (" + rect.x0 + ", " + rect.y0 + ")" );
      v.beginProcess( UndoFlag_NoSwapFile );
      v.image.assign( src, rect, 0, channels - 1 );
      v.endProcess();
      asmdCopyICC( srcWindow, win );
      if ( rect.width != geo.stripW || rect.height != geo.stripH )
      {
         progress( label + ": resampling the whole " + whole + " to " + geo.stripW + " x " + geo.stripH +
                   " (" + asmdInterpolationName( opts.interpolation, scale ) + ")" );
         asmdResampleView( v, geo.stripW, geo.stripH, opts.interpolation, scale );
      }
      if ( opts.sharpenEnabled && opts.sharpenStrength > 0.001 )
         asmdSharpenView( v, opts.sharpenStrength, scale, isColor, progress );
      return { window: win, scale: scale, geo: geo };
   }
   catch ( x )
   {
      asmdClose( win );
      throw x;
   }
}

function asmdMakePanoramaStrip( srcWindow, crop, n, slideW, slideH, opts, progress )
{
   return asmdMakeGridStrip( srcWindow, crop, n, 1, slideW, slideH, opts, progress, "panorama" );
}

// Shallow copy of the options (data only), so per slide changes such as
// the watermark switch never touch the saved settings.
function asmdCloneOpts( o )
{
   var c = {};
   for ( var k in o )
      if ( o.hasOwnProperty( k ) && typeof o[k] != "function" )
         c[k] = o[k];
   return c;
}


// ============================================================================
// Main dialog
// ============================================================================

function AsmdSocialExportDialog( srcWindow )
{
   this.__base__ = Dialog;
   this.__base__();

   var self = this;
   // Row captions inside the settings column are not stored on the dialog.
   // carRow and labeled push them here so the wheel installer can see them.
   this._asmdWheelTargets = [];
   this.srcWindow = srcWindow;
   var img = srcWindow.mainView.image;
   this.imgW = img.width;
   this.imgH = img.height;

   this.opts = new AsmdOptions;
   asmdLoadLicense();
   this.presets = asmdLoadPresets();
   this.crops = {};           // image id + preset id -> crop object (kept for this session)
   this.batchImages = asmdCollectOpenImages( this.srcWindow );
   this.activeImageId = this.srcWindow.mainView.id;
   this.imagesSyncing = false;
   this.currentId = null;
   this.busy = false;

   this.windowTitle = ASMD_TITLE + " " + ASMD_VERSION;

   // ---- Source info --------------------------------------------------------

   var srcPath = srcWindow.filePath;
   var hasFile = (srcPath && srcPath.length > 0);
   var srcName = hasFile ? File.extractName( srcPath ) : srcWindow.mainView.id;
   var srcDir  = hasFile ? asmdCleanDir( File.extractDrive( srcPath ) + File.extractDirectory( srcPath ) ) : "";
   if ( srcDir.length == 0 )
      srcDir = asmdCleanDir( File.homeDirectory );
   this.srcDir = srcDir;

   // ---- Preview ------------------------------------------------------------

   this.preview = new AsmdCropPreview( this, img );
   this.preview.onCropChanged = function() { self.updateCropInfo(); };

   // Own row under the preview. A minimum height and word wrap keep this
   // line from being painted across the preview when the window is short.
   this.cropInfo_Label = new Label( this );
   this.cropInfo_Label.wordWrapping = true;
   this.cropInfo_Label.text = " ";
   this.cropInfo_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   var cropInfoH = asmdScaledPx( this, ASMD_CROPINFO_MIN_H );
   try { this.cropInfo_Label.setScaledMinHeight( ASMD_CROPINFO_MIN_H ); } catch ( yInfo ) {}
   try { this.cropInfo_Label.setMinHeight( cropInfoH ); } catch ( xInfo ) {}

   this.center_Button = new PushButton( this );
   this.center_Button.text = "Center";
   this.center_Button.toolTip = "<p>Center the crop box, keeping its size.</p>";
   this.center_Button.onClick = function()
   {
      var c = self.currentCrop();
      if ( !c ) return;
      c.x = (self.preview.imgW - c.w)/2;
      c.y = (self.preview.imgH - c.h)/2;
      self.preview.changed();
   };

   this.max_Button = new PushButton( this );
   this.max_Button.text = "Max size";
   this.max_Button.toolTip = "<p>Make the crop box as large as the image allows, keeping its center where possible.</p>";
   this.max_Button.onClick = function()
   {
      var c = self.currentCrop();
      if ( !c ) return;
      var cx = c.x + c.w/2, cy = c.y + c.h/2;
      var m = asmdMaxCropSize( self.preview.imgW, self.preview.imgH, self.preview.aspect );
      c.w = m.w; c.h = m.h;
      c.x = cx - c.w/2; c.y = cy - c.h/2;
      self.preview.changed();
   };

   this.reset_Button = new PushButton( this );
   this.reset_Button.text = "Reset";
   this.reset_Button.toolTip = "<p>Reset this target's crop to the largest centered box.</p>";
   this.reset_Button.onClick = function()
   {
      var c = self.currentCrop();
      if ( !c ) return;
      var d = asmdDefaultCrop( self.preview.imgW, self.preview.imgH, self.preview.aspect );
      c.x = d.x; c.y = d.y; c.w = d.w; c.h = d.h;
      self.preview.changed();
   };

   this.sameCenter_Button = new PushButton( this );
   this.sameCenter_Button.text = "Same center for all";
   this.sameCenter_Button.toolTip = "<p>Move every other target's crop so it is centered on the same point as this one.</p>";
   this.sameCenter_Button.onClick = function()
   {
      var c = self.currentCrop();
      if ( !c ) return;
      var cx = c.x + c.w/2, cy = c.y + c.h/2;
      for ( var i = 0; i < self.presets.length; ++i )
      {
         var p = self.presets[i];
         var o = self.cropFor( p );
         o.x = cx - o.w/2;
         o.y = cy - o.h/2;
         asmdClampCrop( o, self.imgW, self.imgH, asmdPresetGeometry( p, self.imgW, self.imgH ).aspect );
      }
      self.preview.update();
      self.updateCropInfo();
   };

   var cropButtons = new HorizontalSizer;
   cropButtons.spacing = 6;
   cropButtons.add( this.center_Button );
   cropButtons.add( this.max_Button );
   cropButtons.add( this.reset_Button );
   cropButtons.add( this.sameCenter_Button );
   cropButtons.addStretch();
   this.cropButtons_Control = new Control( this );
   this.cropButtons_Control.sizer = cropButtons;

   var leftSizer = new VerticalSizer;
   leftSizer.spacing = 4;
   leftSizer.add( this.preview, 100 );
   leftSizer.add( this.cropInfo_Label );
   leftSizer.add( this.cropButtons_Control );
   this.leftSizer = leftSizer;

   // ---- Targets ------------------------------------------------------------

   this.targets_Tree = new TreeBox( this );
   this.targets_Tree.numberOfColumns = 4;
   this.targets_Tree.headerVisible = true;
   this.targets_Tree.rootDecoration = false;
   this.targets_Tree.alternateRowColor = true;
   this.targets_Tree.multipleSelection = false;
   this.targets_Tree.setHeaderText( 0, "Target" );
   this.targets_Tree.setHeaderText( 1, "Pixels" );
   this.targets_Tree.setHeaderText( 2, "Max size" );
   this.targets_Tree.setHeaderText( 3, "Format" );
   this.targets_Tree.setScaledMinSize( 440, 160 );
   this.targets_Tree.toolTip = "<p>Check the targets to export. Select a target to position its crop box. " +
                               "Each target keeps its own crop.</p>";

   this.targets_Tree.onCurrentNodeUpdated = function( current, previous )
   {
      if ( current && current.presetId )
         self.selectTarget( current.presetId );
   };
   this.targets_Tree.onNodeUpdated = function( node, column )
   {
      // Hiding the Targets group when switching to Carousel can fire this
      // with every box unchecked. Ignore those events and any refill.
      if ( self.treeSyncing || self.mode == 1 )
         return;
      if ( node && node.presetId )
      {
         var p = self.presetById( node.presetId );
         if ( p )
         {
            if ( !asmdIsLicensed() && !asmdPresetIsFree( p ) )
            {
               node.checked = false;
               return;
            }
            p.enabled = node.checked;
         }
      }
   };

   this.add_Button = new PushButton( this );
   this.add_Button.text = "Add...";
   this.add_Button.toolTip = "<p>Create a custom preset.</p>";
   this.add_Button.onClick = function() { self.addPreset(); };

   this.edit_Button = new PushButton( this );
   this.edit_Button.text = "Edit...";
   this.edit_Button.toolTip = "<p>Edit the selected custom preset. For a built-in preset, this offers to create an editable custom copy.</p>";
   this.edit_Button.onClick = function() { self.editPreset(); };

   this.delete_Button = new PushButton( this );
   this.delete_Button.text = "Delete";
   this.delete_Button.toolTip = "<p>Delete the selected custom preset. Built-in presets cannot be deleted.</p>";
   this.delete_Button.onClick = function() { self.deletePreset(); };

   this.all_Button = new PushButton( this );
   this.all_Button.text = "All";
   this.all_Button.toolTip = "<p>Check every target.</p>";
   this.all_Button.onClick = function() { self.checkAll( true ); };

   this.none_Button = new PushButton( this );
   this.none_Button.text = "None";
   this.none_Button.toolTip = "<p>Uncheck every target.</p>";
   this.none_Button.onClick = function() { self.checkAll( false ); };

   var presetButtons = new HorizontalSizer;
   presetButtons.spacing = 6;
   presetButtons.add( this.add_Button );
   presetButtons.add( this.edit_Button );
   presetButtons.add( this.delete_Button );
   presetButtons.addStretch();
   presetButtons.add( this.all_Button );
   presetButtons.add( this.none_Button );

   this.images_Tree = new TreeBox( this );
   this.images_Tree.numberOfColumns = 3;
   this.images_Tree.headerVisible = true;
   this.images_Tree.rootDecoration = false;
   this.images_Tree.alternateRowColor = true;
   this.images_Tree.multipleSelection = false;
   this.images_Tree.setHeaderText( 0, "Image" );
   this.images_Tree.setHeaderText( 1, "Pixels" );
   this.images_Tree.setHeaderText( 2, "Base name" );
   this.images_Tree.setScaledMinSize( 440, 90 );
   try
   {
      this.images_Tree.setMinHeight( this.logicalPixelsToPhysical( 90 ) );
   }
   catch ( x )
   {
      this.images_Tree.setMinHeight( 90 );
   }
   this.images_Tree.toolTip = "<p>Check the open images to export together. Select an image to " +
      "set its crop and base name. Each image keeps its own crop per target. " +
      "Exporting more than the current image needs a license. " +
      "Edit a base name in the Base name column if your build allows it, or in the Output field below.</p>";

   this.images_Tree.onCurrentNodeUpdated = function( current, previous )
   {
      if ( self.imagesSyncing || self.mode == 1 )
         return;
      if ( current && current.imageId )
         self.selectBatchImage( current.imageId );
   };
   this.images_Tree.onNodeUpdated = function( node, column )
   {
      if ( self.imagesSyncing || self.mode == 1 )
         return;
      if ( !node || !node.imageId )
         return;
      var rec = self.batchImageById( node.imageId );
      if ( !rec )
         return;
      if ( column == 2 )
      {
         rec.baseName = asmdSafeFileToken( node.text( 2 ) );
         if ( rec.id == self.activeImageId && self.baseName_Edit )
         {
            self.imagesSyncing = true;
            try { self.baseName_Edit.text = rec.baseName; }
            finally { self.imagesSyncing = false; }
            self.updateExample();
         }
         return;
      }
      if ( !asmdIsLicensed() && !rec.isSource )
      {
         node.checked = false;
         rec.checked = false;
         return;
      }
      rec.checked = node.checked;
   };

   this.images_Group = new GroupBox( this );
   this.images_Group.title = "Images";
   this.images_Group.sizer = new VerticalSizer;
   this.images_Group.sizer.margin = 6;
   this.images_Group.sizer.spacing = 4;
   this.images_Group.sizer.add( this.images_Tree );
   this.images_Group.toolTip = this.images_Tree.toolTip;

   this.targets_Group = new GroupBox( this );
   this.targets_Group.title = "Targets";
   this.targets_Group.sizer = new VerticalSizer;
   this.targets_Group.sizer.margin = 6;
   this.targets_Group.sizer.spacing = 6;
   this.targets_Group.sizer.add( this.targets_Tree, 100 );
   this.targets_Group.sizer.add( presetButtons );

   // ---- Mode switch and carousel -------------------------------------------

   this.mode = this.opts.mode;
   this.exportMode = -1;       // set by showExportMode; -1 so the first logo open expands the watermark
   this.jobs = asmdLoadJobs();
   this._asmdHoldCarousel = false;
   this._asmdExportLock = false;
   this._asmdModeUiLock = false;
   this._asmdJpegLock = false;
   this._asmdJobsFilling = false;
   this.treeSyncing = false;  // ignore TreeBox check events while hiding or refilling
   this.carItems = [];        // carousel items in swipe order (this session)
   this.carSel = -1;          // selected carousel item index
   this.carBitmaps = {};      // view id -> preview bitmap for other images
   this.mainBitmap = this.preview.bitmap;

   this.modeSingle_Radio = new RadioButton( this );
   this.modeSingle_Radio.text = "Single exports";
   this.modeSingle_Radio.toolTip = "<p>Export one file per checked target for each checked image, " +
      "each with its own crop. Checking more than the current image needs a license.</p>";
   this.modeCarousel_Radio = new RadioButton( this );
   this.modeCarousel_Radio.text = "Carousel";
   this.modeCarousel_Radio.toolTip = "<p>Export a numbered set of slides that share one shape: a seamless " +
      "panorama or a 2x2 or 3x3 grid, zoomed-in detail slides, and slides from other open images.</p>";
   this.modeSingle_Radio.checked = (this.mode != 1);
   this.modeCarousel_Radio.checked = (this.mode == 1);
   this.modeSingle_Radio.onCheck = function( checked )
   {
      if ( checked ) { self.modeCarousel_Radio.checked = false; self.showMode( 0 ); }
   };
   this.modeCarousel_Radio.onCheck = function( checked )
   {
      if ( checked ) { self.modeSingle_Radio.checked = false; self.showMode( 1 ); }
   };

   var modeLabel = new Label( this );
   modeLabel.text = "Mode:";
   modeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   asmdPushWheelTarget( this, modeLabel );
   var modeSizer = new HorizontalSizer;
   modeSizer.spacing = 12;
   modeSizer.add( modeLabel );
   modeSizer.add( this.modeSingle_Radio );
   modeSizer.add( this.modeCarousel_Radio );
   modeSizer.addStretch();
   this.mode_Control = new Control( this );
   this.mode_Control.sizer = modeSizer;

   var carLabelW = this.font.width( "Panorama slides:" ) + 12;
   function carRow( text, control, stretch )
   {
      var l = new Label( self );
      l.text = text;
      l.minWidth = carLabelW;
      l.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      asmdPushWheelTarget( self, l );
      asmdPushWheelTarget( self, control );
      var s = new HorizontalSizer;
      s.spacing = 6;
      s.add( l );
      if ( stretch === false )
      {
         s.add( control );
         s.addStretch();
      }
      else
         s.add( control, 100 );
      return s;
   }

   this.carPlatform_Combo = new ComboBox( this );
   for ( var pi = 0; pi < ASMD_CAROUSEL_PLATFORMS.length; ++pi )
      this.carPlatform_Combo.addItem( ASMD_CAROUSEL_PLATFORMS[pi].name );
   this.carPlatform_Combo.currentItem = this.opts.carPlatform;
   this.carPlatform_Combo.toolTip = "<p>Where you will post the carousel. This sets the allowed slide shapes, " +
      "the default shape, the slide limit, and the suggested file size. Instagram, TikTok, and Threads swipe " +
      "from slide to slide, so a panorama or grid lines up. Facebook shows a collage, and X arranges photos " +
      "in a grid, so those seams will not swipe.</p>";
   this.carPlatform_Combo.onItemSelected = function( index ) { self.carApplyPlatform( true ); };

   this.carShape_Combo = new ComboBox( this );
   this.carShape_Combo.toolTip = "<p>One shape for every slide. The list depends on the platform above. " +
      "On Instagram, 4:5 works in the app and in scheduling tools, and 3:4 is accepted only by the app.</p>";
   this.carShape_Combo.onItemSelected = function( index ) { self.carShapeChanged(); };

   this.carW_Spin = new SpinBox( this );
   this.carW_Spin.setRange( 16, 8192 );
   this.carW_Spin.value = this.opts.carCustomW;
   this.carH_Spin = new SpinBox( this );
   this.carH_Spin.setRange( 16, 8192 );
   this.carH_Spin.value = this.opts.carCustomH;
   this.carW_Spin.onValueUpdated = function( v ) { self.carShapeChanged(); };
   this.carH_Spin.onValueUpdated = function( v ) { self.carShapeChanged(); };
   var carX_Label = new Label( this );
   carX_Label.text = "x";
   carX_Label.textAlignment = TextAlign_VertCenter;
   asmdPushWheelTarget( this, carX_Label );
   var carCustomSizer = new HorizontalSizer;
   carCustomSizer.spacing = 6;
   carCustomSizer.add( this.carW_Spin );
   carCustomSizer.add( carX_Label );
   carCustomSizer.add( this.carH_Spin );
   carCustomSizer.addStretch();
   this.carCustom_Control = new Control( this );
   this.carCustom_Control.sizer = carCustomSizer;

   this.carNote_Label = new Label( this );
   this.carNote_Label.wordWrapping = true;
   this.carNote_Label.text = " ";
   var noteLineH = 16;
   try
   {
      if ( this.font && this.font.height )
         noteLineH = this.font.height;
   }
   catch ( x ) {}
   // 3 lines, enough for the longest shortNote, so the height stays
   // constant when the platform changes.
   this.carNote_Label.setFixedHeight( noteLineH * 3 + 6 );

   this.carMaxMB_Edit = new NumericEdit( this );
   this.carMaxMB_Edit.label.text = "";
   this.carMaxMB_Edit.setReal( true );
   this.carMaxMB_Edit.setRange( 0.01, 100 );
   this.carMaxMB_Edit.setPrecision( 2 );
   this.carMaxMB_Edit.setValue( this.opts.carMaxKB/1000 );
   this.carMaxMB_Edit.toolTip = "<p>Target size per slide in megabytes, for example 1.6. Slides keep this pixel size. " +
                                "JPEG quality starts at the Processing setting and can drop to 75. A slide is resized " +
                                "only if quality 75 is still over the target.</p>";

   this.carLayout_Combo = new ComboBox( this );
   for ( var li = 0; li < ASMD_CAROUSEL_LAYOUTS.length; ++li )
      this.carLayout_Combo.addItem( ASMD_CAROUSEL_LAYOUTS[li].name );
   this.carLayout_Combo.currentItem = this.opts.carLayout;
   this.carLayout_Combo.toolTip = "<p>How the main crop is split into slides. <b>Panorama</b> is a wide " +
      "strip cut into 2 to 10 slides side by side, so a nebula flows as you swipe. <b>2x2 grid</b> and " +
      "<b>3x3 grid</b> cut one crop into 4 or 9 tiles in reading order (row by row, left to right). " +
      "The crop box is locked to the grid's overall shape, and cyan lines show the cuts.</p>" +
      "<p>A carousel can have one panorama or one grid, not both. You can still add detail slides and " +
      "other images after it.</p>";
   this.carLayout_Combo.onItemSelected = function( index ) { self.carLayoutChanged(); };

   this.carPanels_Spin = new SpinBox( this );
   this.carPanels_Spin.setRange( ASMD_CAROUSEL_MIN_PANELS, ASMD_CAROUSEL_MAX_PANELS );
   this.carPanels_Spin.value = this.opts.carPanels;
   this.carPanels_Spin.toolTip = "<p>How many slides the panorama is split into (2 to 10). The crop box " +
      "is locked to that many slides side by side, and the cyan lines show the cuts. Changing the count " +
      "grows the box to the largest size that fits, centered where it was. You can still drag or resize " +
      "it smaller after that.</p>";
   this.carPanels_Spin.onValueUpdated = function( v ) { self.carPanelsChanged( v ); };
   this.carPanels_Spin.enabled = (this.opts.carLayout == 0);

   this.carAddLayout_Button = new PushButton( this );
   this.carAddPano_Button = this.carAddLayout_Button;
   this.carAddLayout_Button.text = (this.opts.carLayout == 0) ? "Add panorama" :
      ("Add " + ASMD_CAROUSEL_LAYOUTS[this.opts.carLayout].name);
   this.carAddLayout_Button.toolTip = "<p>Add the panorama or grid to the slide list (one per carousel).</p>";
   this.carAddLayout_Button.onClick = function() { self.carAddLayout(); };

   var panoSizer = new HorizontalSizer;
   panoSizer.spacing = 6;
   panoSizer.add( this.carLayout_Combo );
   panoSizer.add( this.carPanels_Spin );
   panoSizer.add( this.carAddLayout_Button );
   panoSizer.addStretch();
   var panoControl = new Control( this );
   panoControl.sizer = panoSizer;

   this.car_Tree = new TreeBox( this );
   this.car_Tree.numberOfColumns = 3;
   this.car_Tree.headerVisible = true;
   this.car_Tree.rootDecoration = false;
   this.car_Tree.alternateRowColor = true;
   this.car_Tree.multipleSelection = false;
   this.car_Tree.setHeaderText( 0, "Slide" );
   this.car_Tree.setHeaderText( 1, "Type" );
   this.car_Tree.setHeaderText( 2, "Source" );
   this.car_Tree.setScaledMinSize( 440, 150 );
   try
   {
      this.car_Tree.setMinHeight( this.logicalPixelsToPhysical( 150 ) );
   }
   catch ( x )
   {
      this.car_Tree.setMinHeight( 150 );
   }
   this.car_Tree.toolTip = "<p>Slides in swipe order. Select a slide to show and edit its crop in the " +
      "preview. A panorama or grid counts as one slide per tile.</p>" +
      "<p>Instagram allows up to 20 slides per carousel, so the list stops at 20 (35 with the TikTok " +
      "9:16 shape, TikTok's photo post limit).</p>";
   this.car_Tree.onCurrentNodeUpdated = function( current, previous )
   {
      if ( current && ("slideIndex" in current) && !self.carFilling )
         self.carSelect( current.slideIndex );
   };

   this.carTotal_Label = new Label( this );
   this.carTotal_Label.text = " ";

   this.carAddDetail_Button = new PushButton( this );
   this.carAddDetail_Button.text = "Add detail";
   this.carAddDetail_Button.toolTip = "<p>Add a zoomed-in crop of this image as a slide. Move and resize " +
      "its box in the preview. Its shape is locked to the slide shape.</p>";
   this.carAddDetail_Button.onClick = function() { self.carAddDetail(); };

   this.carUp_Button = new PushButton( this );
   this.carUp_Button.text = "Move up";
   this.carUp_Button.onClick = function() { self.carMove( -1 ); };
   this.carDown_Button = new PushButton( this );
   this.carDown_Button.text = "Move down";
   this.carDown_Button.onClick = function() { self.carMove( 1 ); };
   this.carRemove_Button = new PushButton( this );
   this.carRemove_Button.text = "Remove";
   this.carRemove_Button.onClick = function() { self.carRemove(); };
   this.carSelect_Button = new PushButton( this );
   this.carSelect_Button.text = "Select";
   this.carSelect_Button.toolTip = "<p>Show the selected slide's crop in the preview so you can edit it.</p>";
   this.carSelect_Button.onClick = function()
   {
      var n = self.car_Tree.currentNode;
      if ( n && ("slideIndex" in n) )
         self.carSelect( n.slideIndex );
   };

   var carButtons = new HorizontalSizer;
   carButtons.spacing = 6;
   carButtons.add( this.carAddDetail_Button );
   carButtons.addStretch();
   carButtons.add( this.carSelect_Button );
   carButtons.add( this.carUp_Button );
   carButtons.add( this.carDown_Button );
   carButtons.add( this.carRemove_Button );
   var btnRowH = noteLineH + 16;
   try
   {
      btnRowH = Math.max( this.logicalPixelsToPhysical( 28 ), noteLineH + 16 );
   }
   catch ( x )
   {
      btnRowH = Math.max( 28, noteLineH + 16 );
   }
   this.carButtons_Control = new Control( this );
   this.carButtons_Control.sizer = carButtons;
   this.carButtons_Control.setFixedHeight( btnRowH );

   // Other open images (starless, RGB, ...). The dialog is modal, so the
   // list of windows cannot change while it is open.
   this.carOtherWindows = [];
   try
   {
      var wins = ImageWindow.windows;
      for ( var wi = 0; wi < wins.length; ++wi )
         if ( wins[wi] && !wins[wi].isNull && wins[wi].mainView.id != srcWindow.mainView.id &&
              wins[wi].mainView.image.width >= 16 && wins[wi].mainView.image.height >= 16 )
            this.carOtherWindows.push( wins[wi] );
   }
   catch ( x ) {}
   this.carOther_Combo = new ComboBox( this );
   if ( this.carOtherWindows.length == 0 )
      this.carOther_Combo.addItem( "(no other open images)" );
   for ( var oi = 0; oi < this.carOtherWindows.length; ++oi )
   {
      var oimg = this.carOtherWindows[oi].mainView.image;
      this.carOther_Combo.addItem( this.carOtherWindows[oi].mainView.id + " (" + oimg.width + " x " + oimg.height + ")" );
   }
   this.carOther_Combo.toolTip = "<p>Another open image, for example a starless or RGB version. " +
      "Open it in PixInsight before starting the script.</p>";
   this.carFit_Check = new CheckBox( this );
   this.carFit_Check.text = "Whole image";
   this.carFit_Check.toolTip = "<p>Checked: the whole image is fitted inside the slide with black bars. " +
      "Unchecked: you crop it in the preview like a detail slide.</p>";
   this.carAddOther_Button = new PushButton( this );
   this.carAddOther_Button.text = "Add image";
   this.carAddOther_Button.onClick = function() { self.carAddOther(); };
   this.carOther_Combo.enabled = this.carOtherWindows.length > 0;
   this.carFit_Check.enabled = this.carOtherWindows.length > 0;
   this.carAddOther_Button.enabled = this.carOtherWindows.length > 0;
   var otherSizer = new HorizontalSizer;
   otherSizer.spacing = 6;
   otherSizer.add( this.carOther_Combo, 100 );
   otherSizer.add( this.carFit_Check );
   otherSizer.add( this.carAddOther_Button );
   this.carOther_Control = new Control( this );
   this.carOther_Control.sizer = otherSizer;
   this.carOther_Control.setFixedHeight( btnRowH );

   this.carWm_Combo = new ComboBox( this );
   for ( var wmi = 0; wmi < ASMD_CAROUSEL_WATERMARKS.length; ++wmi )
      this.carWm_Combo.addItem( ASMD_CAROUSEL_WATERMARKS[wmi] );
   this.carWm_Combo.currentItem = this.opts.carWatermark;
   this.carWm_Combo.toolTip = "<p>Which slides get the watermark. It uses the text or logo, position, " +
      "opacity and size from Watermark / signature below, and only applies when that box is checked.</p>" +
      "<p>First slide only is the default. On a grid that is the top left tile. If that looks odd on " +
      "your image, try Every slide or Last slide only.</p>";

   this.carTemplate_Edit = new Edit( this );
   this.carTemplate_Edit.text = this.opts.carTemplate;
   this.carTemplate_Edit.toolTip = "<p>Carousel file name template. {slide} is the slide number in swipe " +
      "order (01, 02, ...) and is added automatically if missing. {count} is the number of slides. " +
      "{platform} is the destination (Instagram, TikTok, Facebook, Threads, X, or Carousel for Custom). " +
      "The other tokens work as in single exports.</p>";
   this.carTemplate_Edit.onTextUpdated = function( text ) { self.carUpdateExample(); };
   this.carExample_Label = new Label( this );
   this.carExample_Label.text = " ";

   this.carousel_Group = new GroupBox( this );
   this.carousel_Group.title = "Carousel";
   this.carousel_Group.sizer = new VerticalSizer;
   this.carousel_Group.sizer.margin = 6;
   this.carousel_Group.sizer.spacing = 3;
   this.carousel_Group.sizer.add( carRow( "Platform:", this.carPlatform_Combo ) );
   this.carousel_Group.sizer.add( carRow( "Slide shape:", this.carShape_Combo ) );
   this.carousel_Group.sizer.add( carRow( "Custom (px):", this.carCustom_Control ) );
   this.carNote_Control = new Control( this );
   this.carNote_Control.sizer = carRow( "", this.carNote_Label );
   this.carNote_Control.setFixedHeight( noteLineH * 3 + 6 );
   this.carousel_Group.sizer.add( this.carNote_Control );
   this.carousel_Group.sizer.add( carRow( "Max size (MB):", this.carMaxMB_Edit, false ) );
   this.carousel_Group.sizer.add( carRow( "Layout:", panoControl ) );
   this.carousel_Group.sizer.add( this.car_Tree, 100 );
   this.carousel_Group.sizer.add( this.carTotal_Label );
   this.carousel_Group.sizer.add( this.carButtons_Control );
   this.carousel_Group.sizer.add( carRow( "Other image:", this.carOther_Control ) );
   this.carousel_Group.sizer.add( carRow( "Watermark:", this.carWm_Combo ) );
   this.carousel_Group.sizer.add( carRow( "File names:", this.carTemplate_Edit ) );
   this.carousel_Group.sizer.add( carRow( "Example:", this.carExample_Label ) );

   // ---- Output -------------------------------------------------------------

   var labelW = this.font.width( "Name template:" ) + 12;
   function labeled( text, control )
   {
      var l = new Label( self );
      l.text = text;
      l.minWidth = labelW;
      l.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      asmdPushWheelTarget( self, l );
      asmdPushWheelTarget( self, control );
      var s = new HorizontalSizer;
      s.spacing = 6;
      s.add( l );
      s.add( control, 100 );
      return s;
   }

   this.outDir_Edit = new Edit( this );
   this.outDir_Edit.text = srcDir + "/Social";
   this.outDir_Edit.toolTip = "<p>Folder for the exported files. It is created if it does not exist.</p>";

   this.outDir_Button = new PushButton( this );
   this.outDir_Button.text = "Browse...";
   this.outDir_Button.toolTip = "<p>Choose the output folder.</p>";
   this.outDir_Button.onClick = function()
   {
      var d = new GetDirectoryDialog;
      d.caption = "Select output folder";
      var cur = asmdCleanDir( self.outDir_Edit.text );
      if ( cur.length > 0 && File.directoryExists( cur ) )
         d.initialPath = cur;
      else
         d.initialPath = self.srcDir;
      if ( d.execute() )
         self.outDir_Edit.text = asmdCleanDir( d.directory );
   };

   var dirRow = new HorizontalSizer;
   dirRow.spacing = 4;
   dirRow.add( this.outDir_Edit, 100 );
   dirRow.add( this.outDir_Button );
   var dirControl = new Control( this );
   dirControl.sizer = dirRow;

   this.imgDir_Button = new PushButton( this );
   this.imgDir_Button.text = "Image folder";
   this.imgDir_Button.toolTip = "<p>Save next to the image file.</p>";
   this.imgDir_Button.onClick = function() { self.outDir_Edit.text = self.srcDir; };

   this.social_Button = new PushButton( this );
   this.social_Button.text = "Social subfolder";
   this.social_Button.toolTip = "<p>Save in a Social folder inside the image's folder (the default).</p>";
   this.social_Button.onClick = function() { self.outDir_Edit.text = self.srcDir + "/Social"; };

   var dirButtons = new HorizontalSizer;
   dirButtons.spacing = 6;
   dirButtons.addSpacing( labelW + 6 );
   dirButtons.add( this.imgDir_Button );
   dirButtons.add( this.social_Button );
   dirButtons.addStretch();

   this.baseName_Edit = new Edit( this );
   this.baseName_Edit.text = asmdSafeFileToken( srcName );
   this.baseName_Edit.toolTip = "<p>Used for the {name} token for the selected image. " +
      "Each open image in the Images list has its own base name. Defaults to that image's file name or window id.</p>";

   this.template_Edit = new Edit( this );
   this.template_Edit.text = this.opts.template;
   this.template_Edit.toolTip = "<p>File name template. Tokens:<br/>" +
      "{name} base name, {platform} target tag, {preset} preset name, {w} and {h} output pixels, " +
      "{date} YYYY-MM-DD, {time} HHMMSS, {kb} target KB.<br/>" +
      "The .jpg or .png extension is set automatically from each target's format.</p>";
   this.template_Edit.onTextUpdated = function( text ) { self.updateExample(); };
   this.baseName_Edit.onTextUpdated = function( text )
   {
      if ( self.syncBaseNameFromEdit )
         self.syncBaseNameFromEdit( text );
      self.updateExample();
   };

   this.example_Label = new Label( this );
   this.example_Label.text = " ";
   this.example_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.subfolder_Check = new CheckBox( this );
   this.subfolder_Check.text = "Subfolder per image (named after the base name)";
   this.subfolder_Check.checked = this.opts.subfolderPerImage;

   this.overwrite_Check = new CheckBox( this );
   this.overwrite_Check.text = "Overwrite existing files (otherwise add _2, _3, ...)";
   this.overwrite_Check.checked = this.opts.overwrite;

   this.output_Group = new GroupBox( this );
   this.output_Group.title = "Output";
   this.output_Group.sizer = new VerticalSizer;
   this.output_Group.sizer.margin = 6;
   this.output_Group.sizer.spacing = 4;
   this.template_Control = new Control( this );
   this.template_Control.sizer = labeled( "Name template:", this.template_Edit );
   this.example_Control = new Control( this );
   this.example_Control.sizer = labeled( "Example:", this.example_Label );
   this.output_Group.sizer.add( labeled( "Folder:", dirControl ) );
   this.output_Group.sizer.add( dirButtons );
   this.output_Group.sizer.add( labeled( "Base name:", this.baseName_Edit ) );
   this.output_Group.sizer.add( this.template_Control );
   this.output_Group.sizer.add( this.example_Control );
   this.output_Group.sizer.add( labeled( "", this.subfolder_Check ) );
   this.output_Group.sizer.add( labeled( "", this.overwrite_Check ) );

   // ---- Processing ---------------------------------------------------------

   this.interp_Combo = new ComboBox( this );
   for ( var ii = 0; ii < ASMD_INTERPOLATIONS.length; ++ii )
      this.interp_Combo.addItem( ASMD_INTERPOLATIONS[ii] );
   this.interp_Combo.currentItem = this.opts.interpolation;
   this.interp_Combo.toolTip = "<p>Resampling method. Auto uses Mitchell-Netravali for reductions " +
                               "and clamped Lanczos-3 for enlargements.</p>";

   this.sharpen_Control = new NumericControl( this );
   this.sharpen_Control.label.text = "Sharpening:";
   this.sharpen_Control.label.minWidth = labelW;
   this.sharpen_Control.setRange( 0, 1 );
   this.sharpen_Control.slider.setRange( 0, 100 );
   this.sharpen_Control.setPrecision( 2 );
   this.sharpen_Control.setValue( this.opts.sharpenStrength );
   this.sharpen_Control.toolTip = "<p>Output sharpening strength, applied after resizing to targets that have " +
      "sharpening turned on. It is scaled to how much the image is reduced. 0 turns it off. " +
      "0.25 is gentle, 0.5 is moderate, and 1.0 is strong.</p>";
   this.sharpen_Control.enabled = this.opts.sharpenEnabled;

   this.sharpenEnable_Check = new CheckBox( this );
   this.sharpenEnable_Check.text = "Apply output sharpening";
   this.sharpenEnable_Check.checked = this.opts.sharpenEnabled;
   this.sharpenEnable_Check.toolTip = "<p>Off by default. When checked, gentle sharpening is applied after " +
      "resizing, at the strength below, to targets that allow it. When unchecked, no sharpening is applied " +
      "to any export.</p>";
   var selfS = this;
   this.sharpenEnable_Check.onCheck = function( checked )
   {
      var logo = selfS.exportMode == 2 && asmdIsLicensed();
      selfS.sharpen_Control.enabled = !logo && checked;
   };

   this.noUpscale_Check = new CheckBox( this );
   this.noUpscale_Check.text = "Don't upscale small crops (recommended)";
   this.noUpscale_Check.checked = this.opts.noUpscale;
   this.noUpscale_Check.toolTip = "<p>When the crop has fewer pixels than the platform size:</p>" +
      "<p><b>Checked</b> (recommended): the file is saved at the crop's real size. It stays sharper " +
      "and is usually a smaller file. The platform may stretch it slightly when it displays the image.</p>" +
      "<p><b>Unchecked</b>: the crop is enlarged to the exact platform size, which can look soft.</p>";
   this.noUpscale_Check.onCheck = function( checked ) { self.updateUpscaleHint(); };

   this.upscaleHint_Label = new Label( this );
   this.upscaleHint_Label.wordWrapping = true;
   this.upscaleHint_Label.text = " ";

   this.jpegQuality_Spin = new SpinBox( this );
   this.jpegQuality_Spin.setRange( ASMD_JPEG_QUALITY_FLOOR, ASMD_JPEG_QUALITY_MAX );
   this.jpegQuality_Spin.value = asmdClampJpegQuality( this.opts.jpegQuality );
   this.jpegQuality_Spin.toolTip = "<p>Starting JPEG quality, from 90 to 100. 95 is the default. " +
      "Presets and carousel slides search downward from this value to 75 so the pixel size can stay put.</p>";
   this.jpegQuality_Spin.onValueUpdated = function( v ) { self.setJpegQuality( v ); };

   this.jpegQuality_Label = new Label( this );
   this.jpegQuality_Label.wordWrapping = true;
   this.jpegQuality_Label.text = "Presets and carousel slides start here and can drop to 75 to keep the pixel size.";

   function makeModeJpegSpin( tip )
   {
      var spin = new SpinBox( self );
      spin.setRange( ASMD_JPEG_QUALITY_FLOOR, ASMD_JPEG_QUALITY_MAX );
      spin.value = asmdClampJpegQuality( self.opts.jpegQuality );
      spin.toolTip = tip;
      spin.onValueUpdated = function( v ) { self.setJpegQuality( v ); };
      return spin;
   }
   this.frameJpeg_Spin = makeModeJpegSpin(
      "<p>Starting JPEG quality for this full frame export, from 90 to 100. " +
      "Highest quality holds this value and shrinks the image. Largest size can drop from here to 75.</p>" );
   this.logoJpeg_Spin = makeModeJpegSpin(
      "<p>Starting JPEG quality for a logo-only JPEG, from 90 to 100. " +
      "Original size can drop from here to 75. Fit to file size uses Priority.</p>" );

   this.fullFrameMB_Edit = new NumericEdit( this );
   this.fullFrameMB_Edit.label.text = "";
   this.fullFrameMB_Edit.setReal( true );
   this.fullFrameMB_Edit.setRange( 0.05, 100 );
   this.fullFrameMB_Edit.setPrecision( 2 );
   this.fullFrameMB_Edit.setValue( (this.opts.fullFrameMaxMB >= 0.05) ? this.opts.fullFrameMaxMB : 10 );
   this.fullFrameMB_Edit.toolTip = "<p>Maximum file size in megabytes for a full frame export, for example 10.</p>";
   this.fullFrameMB_Edit.onValueUpdated = function( v ) { if ( self.updateExample ) self.updateExample(); };

   this.fullFramePriority_Combo = new ComboBox( this );
   this.fullFramePriority_Combo.addItem( "Highest quality" );
   this.fullFramePriority_Combo.addItem( "Largest size" );
   this.fullFramePriority_Combo.currentItem = (this.opts.fullFramePriority == 1) ? 1 : 0;
   this.fullFramePriority_Combo.toolTip = "<p>Used with Full frame, fit to file size.</p>" +
      "<p><b>Highest quality</b> (default): keeps the JPEG quality above (90 to 100) and shrinks the pixel size just enough to fit.</p>" +
      "<p><b>Largest size</b>: keeps the original pixel size and lowers quality to fit, down to 75. " +
      "If quality 75 is still over the target, the image is resized just enough at quality 75.</p>";

   this.upscale_Control = new Control( this );
   this.upscale_Control.sizer = new VerticalSizer;
   this.upscale_Control.sizer.spacing = 4;
   this.upscale_Control.sizer.add( labeled( "", this.noUpscale_Check ) );
   this.upscale_Control.sizer.add( labeled( "", this.upscaleHint_Label ) );

   this.jpegProcessing_Control = new Control( this );
   this.jpegProcessing_Control.sizer = new VerticalSizer;
   this.jpegProcessing_Control.sizer.spacing = 4;
   this.jpegProcessing_Control.sizer.add( labeled( "JPEG quality:", this.jpegQuality_Spin ) );
   this.jpegProcessing_Control.sizer.add( labeled( "", this.jpegQuality_Label ) );

   this.processing_Control = new Control( this );
   this.processing_Control.sizer = new VerticalSizer;
   this.processing_Control.sizer.margin = 6;
   this.processing_Control.sizer.spacing = 4;
   this.processing_Control.sizer.add( labeled( "Resampling:", this.interp_Combo ) );
   this.processing_Control.sizer.add( labeled( "", this.sharpenEnable_Check ) );
   this.processing_Control.sizer.add( this.sharpen_Control );
   this.processing_Control.sizer.add( this.upscale_Control );
   this.processing_Control.sizer.add( this.jpegProcessing_Control );
   this.processing_Section = new SectionBar( this, "Processing" );
   this.processing_Section.setSection( this.processing_Control );
   this.processing_Control.visible = !!this.opts.processingExpanded;
   if ( this.processing_Section.updateIcon )
      this.processing_Section.updateIcon();
   asmdPlaceSectionArrowLeft( this.processing_Section );
   this.processing_Group = this.processing_Control;

   // ---- Watermark ----------------------------------------------------------

   this.wmMode_Combo = new ComboBox( this );
   this.wmMode_Combo.addItem( "Text" );
   this.wmMode_Combo.addItem( "Logo image" );
   this.wmMode_Combo.currentItem = this.opts.wmMode;
   this.wmMode_Combo.toolTip = ASMD_LOGO_TOOLTIP;
   this.wmMode_Combo.onItemSelected = function( index ) { self.updateWatermarkControls(); };

   this.wmText_Edit = new Edit( this );
   this.wmText_Edit.text = this.opts.wmText;
   this.wmText_Edit.toolTip = "<p>Signature or copyright text.</p>";

   this.wmLogo_Edit = new Edit( this );
   this.wmLogo_Edit.text = this.opts.wmLogoPath;
   this.wmLogo_Edit.toolTip = ASMD_LOGO_TOOLTIP;
   this.wmLogo_Edit.onTextUpdated = function( text ) { if ( self.updateLogoHint ) self.updateLogoHint(); };

   this.wmLogo_Button = new PushButton( this );
   this.wmLogo_Button.text = "Browse...";
   this.wmLogo_Button.toolTip = ASMD_LOGO_TOOLTIP;
   this.wmLogo_Button.onClick = function()
   {
      var d = new OpenFileDialog;
      d.caption = "Select a logo image";
      d.filters = ASMD_LOGO_FILTERS;
      if ( d.execute() )
      {
         self.wmLogo_Edit.text = d.fileName;
         if ( self.updateLogoHint )
            self.updateLogoHint();
      }
   };

   this.logoHint_Label = new Label( this );
   this.logoHint_Label.wordWrapping = true;
   this.logoHint_Label.text = " ";

   var logoRow = new HorizontalSizer;
   logoRow.spacing = 4;
   logoRow.add( this.wmLogo_Edit, 100 );
   logoRow.add( this.wmLogo_Button );
   this.wmLogo_Control = new Control( this );
   this.wmLogo_Control.sizer = logoRow;

   this.wmCorner_Combo = new ComboBox( this );
   for ( var ci = 0; ci < ASMD_CORNER_ORDER.length; ++ci )
      this.wmCorner_Combo.addItem( ASMD_CORNERS[ASMD_CORNER_ORDER[ci]] );
   this.wmCorner_Combo.currentItem = asmdCornerComboIndex( this.opts.wmCorner );

   this.wmOpacity_Control = new NumericControl( this );
   this.wmOpacity_Control.label.text = "Opacity:";
   this.wmOpacity_Control.label.minWidth = labelW;
   this.wmOpacity_Control.setRange( 0.05, 1 );
   this.wmOpacity_Control.slider.setRange( 5, 100 );
   this.wmOpacity_Control.setPrecision( 2 );
   this.wmOpacity_Control.setValue( this.opts.wmOpacity );

   this.wmSize_Control = new NumericControl( this );
   this.wmSize_Control.label.text = "Size (%):";
   this.wmSize_Control.label.minWidth = labelW;
   this.wmSize_Control.setRange( 1, 25 );
   this.wmSize_Control.slider.setRange( 10, 250 );
   this.wmSize_Control.setPrecision( 1 );
   this.wmSize_Control.setValue( this.opts.wmSizePercent );
   this.wmSize_Control.toolTip = "<p>Text height or logo height as a percentage of the image's short edge.</p>";

   this.wm_Control = new Control( this );
   this.wm_Control.sizer = new VerticalSizer;
   this.wm_Control.sizer.margin = 6;
   this.wm_Control.sizer.spacing = 4;
   this.wm_Control.sizer.add( labeled( "Type:", this.wmMode_Combo ) );
   this.wm_Control.sizer.add( labeled( "Text:", this.wmText_Edit ) );
   this.wm_Control.sizer.add( labeled( "Logo file:", this.wmLogo_Control ) );
   this.wm_Control.sizer.add( labeled( "", this.logoHint_Label ) );
   this.wm_Control.sizer.add( labeled( "Position:", this.wmCorner_Combo ) );
   this.wm_Control.sizer.add( this.wmOpacity_Control );
   this.wm_Control.sizer.add( this.wmSize_Control );
   this.wm_Section = new SectionBar( this, "Watermark / signature" );
   this.wm_Section.enableCheckBox();
   this.wm_Section.checkBox.checked = this.opts.wmEnabled;
   this.wm_Section.onCheckSection = function( bar ) { self.updateWatermarkControls(); };
   this.wm_Section.setSection( this.wm_Control );
   this.wm_Control.visible = (this.opts.watermarkExpanded !== false);
   if ( this.wm_Section.updateIcon )
      this.wm_Section.updateIcon();
   asmdPlaceSectionArrowLeft( this.wm_Section );
   this.wm_Group = this.wm_Control;

   // ---- Bottom row ---------------------------------------------------------

   this.status_Label = new Label( this );
   this.status_Label.text = "Ready.";
   this.status_Label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   this.licenseBanner_Label = new Label( this );
   this.licenseBanner_Label.useRichText = true;
   this.licenseBanner_Label.wordWrapping = true;
   this.licenseBanner_Label.text = " ";

   this.license_Button = new PushButton( this );
   this.license_Button.text = "Enter license key";
   this.license_Button.toolTip = "<p>Enter or remove a license key to unlock every platform, custom " +
      "presets, saved jobs, your own watermark, carousel export, full frame size target, and logo-only export.</p>";
   this.license_Button.onClick = function() { self.showLicenseDialog(); };

   this.export_Button = new PushButton( this );
   this.export_Button.text = "Export";
   this.export_Button.icon = this.scaledResource( ":/icons/ok.png" );
   this.export_Button.onClick = function() { self.runExport(); };

   this.openFolder_Button = new PushButton( this );
   this.openFolder_Button.text = "Open folder";
   this.openFolder_Button.icon = this.scaledResource( ":/icons/folder-open.png" );
   this.openFolder_Button.toolTip = "<p>Open the folder the files were exported to (or the output folder " +
      "above, before the first export) in File Explorer or Finder.</p>";
   this.openFolder_Button.onClick = function()
   {
      var dir = (self.lastOutDir && File.directoryExists( self.lastOutDir )) ?
                  self.lastOutDir : asmdCleanDir( self.outDir_Edit.text );
      if ( !dir || !File.directoryExists( dir ) )
      {
         asmdMessage( "The output folder does not exist yet. Export first, or choose a folder.", StdIcon_Information );
         return;
      }
      asmdOpenFolder( dir );
   };

   this.close_Button = new PushButton( this );
   this.close_Button.text = "Close";
   this.close_Button.icon = this.scaledResource( ":/icons/close.png" );
   this.close_Button.onClick = function()
   {
      if ( self.busy )
         return;
      self.collectOptions();
      self.opts.save();
      asmdSavePresets( self.presets );
      asmdSaveWindowGeometry( self );
      self.cancel();
   };

   var bottom = new HorizontalSizer;
   bottom.spacing = 6;
   bottom.add( this.status_Label, 100 );
   bottom.add( this.license_Button );
   bottom.add( this.openFolder_Button );
   bottom.add( this.export_Button );
   bottom.add( this.close_Button );
   this.action_Control = new Control( this );
   this.action_Control.sizer = bottom;

   // Windows delivers the wheel to the child under the pointer, so the
   // ScrollBox itself never sees it. The installer below wires the viewport
   // and the children that do not use the wheel (labels, sections, groups).
   this.right_Scroll = new ScrollBox( this );
   this.right_Scroll.autoScroll = false;
   this.right_Scroll.horizontalScrollBarVisible = false;
   this.right_Scroll.verticalScrollBarVisible = false;
   try
   {
      this.right_Scroll.setScaledMinWidth( 460 );
      this.right_Scroll.setScaledMinHeight( 200 );
   }
   catch ( x )
   {
      this.right_Scroll.setMinWidth( 460 );
      this.right_Scroll.setMinHeight( 200 );
   }

   var scrollParent = this;
   try
   {
      if ( ("viewport" in this.right_Scroll) && this.right_Scroll.viewport )
         scrollParent = this.right_Scroll.viewport;
   }
   catch ( x ) {}
   this.rightPane = new Control( scrollParent );
   this.rightPane.asmdSettingsPane = true;
   var rightSizer = new VerticalSizer;
   rightSizer.spacing = 4;
   rightSizer.add( this.licenseBanner_Label );
   rightSizer.add( this.mode_Control );
   rightSizer.add( this.images_Group );
   rightSizer.add( this.targets_Group );
   rightSizer.add( this.carousel_Group );
   rightSizer.add( this.output_Group );
   rightSizer.add( this.processing_Section );
   rightSizer.add( this.processing_Control );
   rightSizer.add( this.wm_Section );
   rightSizer.add( this.wm_Control );
   this.rightPane.sizer = rightSizer;

   // ---- What do you want to do? -------------------------------------------
   // Full width, above the preview and the target list. Full frame and
   // logo only replace the old Processing checkboxes.

   this.exportSocial_Radio = new RadioButton( this );
   this.exportSocial_Radio.text = "Social media export";
   this.exportSocial_Radio.toolTip = "<p>Crop to the checked platform presets, then resize and save. " +
      "This is the usual social export, including Carousel.</p>";
   this.exportSocial_Radio.checked = true;
   this.exportSocial_Radio.onCheck = function( checked )
   {
      if ( checked ) self.showExportMode( 0 );
   };

   this.exportFrame_Radio = new RadioButton( this );
   this.exportFrame_Radio.text = "Full frame, fit to file size";
   this.exportFrame_Radio.toolTip = "<p>Licensed. Export the whole image with no crop, and fit it to a file size. " +
      "Set Target (MB) and Priority next to this choice.</p>";
   this.exportFrame_Radio.onCheck = function( checked )
   {
      if ( checked ) self.showExportMode( 1 );
   };

   this.exportLogo_Radio = new RadioButton( this );
   this.exportLogo_Radio.text = "Add logo only";
   this.exportLogo_Radio.toolTip = "<p>Licensed. Add a logo or signature and nothing else. No crop and no sharpening. " +
      "Choose original size, or fit the whole frame to a file size.</p>";
   this.exportLogo_Radio.onCheck = function( checked )
   {
      if ( checked ) self.showExportMode( 2 );
   };

   var exportAsk = new Label( this );
   exportAsk.text = "What do you want to do?";
   exportAsk.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   var exportChoice = new HorizontalSizer;
   exportChoice.spacing = 14;
   exportChoice.add( exportAsk );
   exportChoice.add( this.exportSocial_Radio );
   exportChoice.add( this.exportFrame_Radio );
   exportChoice.add( this.exportLogo_Radio );
   exportChoice.addStretch();

   this.exportHelp_Label = new Label( this );
   this.exportHelp_Label.wordWrapping = true;
   this.exportHelp_Label.text = asmdExportModeHelp( 0 );

   this.exportLicense_Label = new Label( this );
   this.exportLicense_Label.text = "Requires a license key.";
   this.exportLicense_Label.toolTip = "<p>Full frame and Add logo only need a license key. " +
      "Social media export works without one.</p>";

   function inlineLabel( text )
   {
      var l = new Label( self );
      l.text = text;
      l.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      return l;
   }

   var frameRow = new HorizontalSizer;
   frameRow.spacing = 8;
   frameRow.add( inlineLabel( "Target (MB):" ) );
   frameRow.add( this.fullFrameMB_Edit );
   frameRow.add( inlineLabel( "Priority:" ) );
   frameRow.add( this.fullFramePriority_Combo );
   frameRow.add( inlineLabel( "JPEG quality:" ) );
   frameRow.add( this.frameJpeg_Spin );
   frameRow.addStretch();
   this.frameOptions_Control = new Control( this );
   this.frameOptions_Control.sizer = frameRow;
   this.frameOptions_Control.visible = false;
   this.frameOptions_Control.toolTip = this.fullFramePriority_Combo.toolTip;

   this.logoFitOriginal_Radio = new RadioButton( this );
   this.logoFitOriginal_Radio.text = "Original size";
   this.logoFitOriginal_Radio.checked = !this.opts.logoFit;
   this.logoFitOriginal_Radio.toolTip = "<p>Keep the original pixel size. Same as source also keeps the file type and bit depth. " +
      "JPEG can drop quality to 75 to meet the target, and is resized only if quality 75 is still over. " +
      "PNG stays at the original pixel size.</p>";
   this.logoFitOriginal_Radio.onCheck = function( checked )
   {
      if ( checked )
      {
         self.logoFitSize_Radio.checked = false;
         self.updateExportModeControls();
      }
   };
   this.logoFitSize_Radio = new RadioButton( this );
   this.logoFitSize_Radio.text = "Fit to file size";
   this.logoFitSize_Radio.checked = !!this.opts.logoFit;
   this.logoFitSize_Radio.toolTip = "<p>After the logo is added, fit the whole image to Target (MB) using Priority. " +
      "This always saves a JPEG.</p>";
   this.logoFitSize_Radio.onCheck = function( checked )
   {
      if ( checked )
      {
         self.logoFitOriginal_Radio.checked = false;
         self.updateExportModeControls();
      }
   };

   this.logoFormat_Combo = new ComboBox( this );
   this.logoFormat_Combo.addItem( "Same as source" );
   this.logoFormat_Combo.addItem( "JPEG" );
   this.logoFormat_Combo.addItem( "PNG" );
   this.logoFormat_Combo.currentItem = asmdLogoFormatComboIndex( this.opts.logoFormat );
   this._asmdLogoFormatHold = "";
   this.logoFormat_Combo.toolTip = "<p>File format for Add logo only at the original size. " +
      "Same as source writes TIFF, PNG, JPEG, XISF, or FITS to match the image file, " +
      "at the original bit depth, and does not convert to 8-bit sRGB. " +
      "An image that has not been saved is written as 16-bit TIFF. " +
      "Fit to file size always saves a JPEG.</p>";
   this.logoFormat_Combo.onItemSelected = function( index ) { self.updateExportModeControls(); };

   this.logoMB_Edit = new NumericEdit( this );
   this.logoMB_Edit.label.text = "";
   this.logoMB_Edit.setReal( true );
   this.logoMB_Edit.setRange( 0.05, 100 );
   this.logoMB_Edit.setPrecision( 2 );
   this.logoMB_Edit.setValue( (this.opts.logoMaxMB >= 0.05) ? this.opts.logoMaxMB : 10 );
   this.logoMB_Edit.toolTip = "<p>Size target in megabytes for Add logo only, for example 10.</p>";
   this.logoMB_Edit.onValueUpdated = function( v ) { if ( self.updateExample ) self.updateExample(); };

   this.logoPriority_Combo = new ComboBox( this );
   this.logoPriority_Combo.addItem( "Highest quality" );
   this.logoPriority_Combo.addItem( "Largest size" );
   this.logoPriority_Combo.currentItem = (this.opts.logoPriority == 1) ? 1 : 0;
   this.logoPriority_Combo.toolTip = this.fullFramePriority_Combo.toolTip;

   var logoSizeRow = new HorizontalSizer;
   logoSizeRow.spacing = 8;
   logoSizeRow.add( inlineLabel( "Size:" ) );
   logoSizeRow.add( this.logoFitOriginal_Radio );
   logoSizeRow.add( this.logoFitSize_Radio );
   logoSizeRow.add( inlineLabel( "Format:" ) );
   logoSizeRow.add( this.logoFormat_Combo );
   logoSizeRow.addStretch();

   var logoFitRow = new HorizontalSizer;
   logoFitRow.spacing = 8;
   logoFitRow.add( inlineLabel( "Target (MB):" ) );
   logoFitRow.add( this.logoMB_Edit );
   logoFitRow.add( inlineLabel( "Priority:" ) );
   logoFitRow.add( this.logoPriority_Combo );
   logoFitRow.add( inlineLabel( "JPEG quality:" ) );
   logoFitRow.add( this.logoJpeg_Spin );
   logoFitRow.addStretch();

   this.logoOptions_Control = new Control( this );
   this.logoOptions_Control.sizer = new VerticalSizer;
   this.logoOptions_Control.sizer.spacing = 4;
   this.logoOptions_Control.sizer.add( logoSizeRow );
   this.logoOptions_Control.sizer.add( logoFitRow );
   this.logoOptions_Control.visible = false;

   this.exportMode_Control = new Control( this );
   this.exportMode_Control.sizer = new VerticalSizer;
   this.exportMode_Control.sizer.spacing = 4;
   this.exportMode_Control.sizer.add( exportChoice );
   this.exportMode_Control.sizer.add( this.exportHelp_Label );
   this.exportMode_Control.sizer.add( this.exportLicense_Label );
   this.exportMode_Control.sizer.add( this.frameOptions_Control );
   this.exportMode_Control.sizer.add( this.logoOptions_Control );
   try
   {
      this.exportMode_Control.setMinHeight( this.logicalPixelsToPhysical( 72 ) );
   }
   catch ( x )
   {
      this.exportMode_Control.setMinHeight( 72 );
   }

   // ---- Saved jobs ---------------------------------------------------------

   this.jobs_Combo = new ComboBox( this );
   this.jobs_Combo.toolTip = "<p>Saved jobs. Load applies the selected job. " +
      "Saving a job stores the mode and its settings. This needs a license key.</p>";
   try { this.jobs_Combo.setScaledMinWidth( 180 ); } catch ( x2 ) {}

   this.jobLoad_Button = new PushButton( this );
   this.jobLoad_Button.text = "Load";
   this.jobLoad_Button.toolTip = "<p>Apply the selected job.</p>";
   this.jobLoad_Button.onClick = function() { self.loadSelectedJob(); };

   this.jobSave_Button = new PushButton( this );
   this.jobSave_Button.text = "Save as...";
   this.jobSave_Button.toolTip = "<p>Save the current mode and settings as a new named job.</p>";
   this.jobSave_Button.onClick = function() { self.saveJobAs(); };

   this.jobUpdate_Button = new PushButton( this );
   this.jobUpdate_Button.text = "Update";
   this.jobUpdate_Button.toolTip = "<p>Replace the selected job with the current settings.</p>";
   this.jobUpdate_Button.onClick = function() { self.updateSelectedJob(); };

   this.jobDelete_Button = new PushButton( this );
   this.jobDelete_Button.text = "Delete";
   this.jobDelete_Button.toolTip = "<p>Delete the selected job.</p>";
   this.jobDelete_Button.onClick = function() { self.deleteSelectedJob(); };

   this.jobRename_Button = new PushButton( this );
   this.jobRename_Button.text = "Rename";
   this.jobRename_Button.toolTip = "<p>Rename the selected job.</p>";
   this.jobRename_Button.onClick = function() { self.renameSelectedJob(); };

   var jobsRow = new HorizontalSizer;
   jobsRow.spacing = 6;
   jobsRow.add( inlineLabel( "Jobs:" ) );
   jobsRow.add( this.jobs_Combo );
   jobsRow.add( this.jobLoad_Button );
   jobsRow.add( this.jobSave_Button );
   jobsRow.add( this.jobUpdate_Button );
   jobsRow.add( this.jobDelete_Button );
   jobsRow.add( this.jobRename_Button );
   jobsRow.addStretch();
   this.jobs_Control = new Control( this );
   this.jobs_Control.sizer = jobsRow;
   try
   {
      this.jobs_Control.setMinHeight( this.logicalPixelsToPhysical( 28 ) );
   }
   catch ( x3 )
   {
      this.jobs_Control.setMinHeight( 28 );
   }

   var mainSizer = new HorizontalSizer;
   mainSizer.spacing = 8;
   mainSizer.add( leftSizer, 100 );
   mainSizer.add( this.right_Scroll );

   this.title_Label = new Label( this );
   this.title_Label.useRichText = true;
   this.title_Label.text = "<b>" + ASMD_TITLE + "</b> " + ASMD_VERSION +
                     " &nbsp;&nbsp;Image: " + srcWindow.mainView.id + " (" + this.imgW + " x " + this.imgH + ")";

   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.add( this.title_Label );
   this.sizer.add( this.exportMode_Control );
   this.sizer.add( this.jobs_Control );
   this.sizer.add( mainSizer, 100 );
   this.sizer.add( this.action_Control );

   this.userResizable = true;

   // Behavior methods are attached in asmdAttachDialogBehavior().
   asmdAttachDialogBehavior( this );
   asmdAttachCarouselBehavior( this );

   // ---- Initial state ------------------------------------------------------

   this.updateWatermarkControls();
   this.fillTree( null );
   this.applyLicenseState();
   this.updateExample();
   this.carApplyPlatform( false );
   this.carUpdateExample();
   this.showMode( this.mode );
   // Do not call adjustToContents() on this dialog. On Windows it sizes the
   // window to a tiny unrealized hint (about 650 x 255) and the later resize
   // does not win. The floor below is applied with resize instead.
   asmdApplyPreviewMin( this );
   var dlgFloor = asmdDialogMinimumSize( this );
   try
   {
      this.setMinWidth( dlgFloor.w );
      this.setMinHeight( dlgFloor.h );
   }
   catch ( x )
   {
      try
      {
         this.setMinWidth( ASMD_DIALOG_MIN_W );
         this.setMinHeight( ASMD_DIALOG_MIN_H );
      }
      catch ( y ) {}
   }
   asmdFitDialogSize( this, true );
   this._asmdReady = true;
}

AsmdSocialExportDialog.prototype = new Dialog;

// ============================================================================
// Main dialog behavior
// ============================================================================

function asmdAttachDialogBehavior( dlg )
{
   // Size the settings pane to the visible viewport, reserving the vertical
   // bar, so only that bar appears and it does not cover the pane. Move the
   // pane when the user scrolls.
   dlg.updateSettingsScroll = function()
   {
      if ( !this.right_Scroll || !this.rightPane )
         return;
      var scroll = this.right_Scroll;
      var vp = null, vh = 0;
      try
      {
         if ( ("viewport" in scroll) && scroll.viewport )
            vp = scroll.viewport;
      }
      catch ( x ) {}
      try
      {
         vh = vp ? vp.height : scroll.height;
      }
      catch ( x ) {}
      if ( !(vh >= 0) )
         vh = 0;

      // Measure with the bar we already have, then again if that height
      // shows or hides the bar. The second pass uses the width that will
      // actually be visible, so the arrows and row buttons stay clear of it.
      var assumeBar = false;
      try
      {
         if ( ("verticalScrollBarVisible" in scroll) )
            assumeBar = !!scroll.verticalScrollBarVisible;
      }
      catch ( x ) {}
      var pass, vw = 0, ph = 0;
      for ( pass = 0; pass < 2; ++pass )
      {
         vw = asmdScrollContentWidth( this, scroll, assumeBar );
         asmdApplySettingsPaneWidth( this, vw );
         try
         {
            this.rightPane.adjustToContents();
         }
         catch ( x ) {}
         asmdApplySettingsPaneWidth( this, vw );
         ph = 0;
         try { ph = this.rightPane.height; } catch ( x ) {}
         var nextBar = (ph > vh);
         if ( nextBar == assumeBar )
            break;
         assumeBar = nextBar;
      }
      try
      {
         if ( "setPageSize" in scroll )
            scroll.setPageSize( Math.max( 1, vw ), Math.max( 1, vh ) );
         if ( "setHorizontalScrollRange" in scroll )
            scroll.setHorizontalScrollRange( 0, 0 );
         var maxY = Math.max( 0, ph - vh );
         if ( "setVerticalScrollRange" in scroll )
            scroll.setVerticalScrollRange( 0, maxY );
         if ( "maxVerticalScrollPosition" in scroll )
            scroll.maxVerticalScrollPosition = maxY;
         scroll.horizontalScrollBarVisible = false;
         scroll.verticalScrollBarVisible = (maxY > 0);
         scroll.autoScroll = (maxY > 0);
      }
      catch ( x ) {}
   };

   dlg.onShow = function()
   {
      asmdEnsureDialogSize( this );
      if ( ("_asmdReady" in this) && this._asmdReady )
         asmdSettleSettingsScroll( this );
   };

   dlg.onHide = function()
   {
      asmdSaveWindowGeometry( this );
   };

   dlg.onResize = function( wNew, hNew, wOld, hOld )
   {
      if ( ("_asmdFitting" in this) && this._asmdFitting )
         return;
      if ( ("_asmdEnsuring" in this) && this._asmdEnsuring )
         return;
      if ( ("_asmdSettling" in this) && this._asmdSettling )
         return;
      asmdEnsureDialogSize( this );
   };

   dlg.onSectionToggled = function( bar, beginToggle )
   {
      if ( beginToggle )
         return;
      if ( this.processing_Section && this.processing_Section.isExpanded )
         this.opts.processingExpanded = this.processing_Section.isExpanded();
      if ( this.wm_Section && this.wm_Section.isExpanded )
         this.opts.watermarkExpanded = this.wm_Section.isExpanded();
      asmdFitDialogSize( this, false );
   };

   if ( dlg.processing_Section )
      dlg.processing_Section.onToggleSection = function( bar, beginToggle ) { dlg.onSectionToggled( bar, beginToggle ); };
   if ( dlg.wm_Section )
      dlg.wm_Section.onToggleSection = function( bar, beginToggle ) { dlg.onSectionToggled( bar, beginToggle ); };

   if ( dlg.right_Scroll )
   {
      var scroll = dlg.right_Scroll;
      if ( ("viewport" in scroll) && scroll.viewport )
      {
         scroll.viewport.onResize = function()
         {
            dlg.updateSettingsScroll();
         };
      }
      scroll.onVerticalScrollPosUpdated = function( y )
      {
         asmdMoveScrolledPane( dlg.rightPane, y );
      };
      // The settings column is the only plain ScrollBox. TreeBox lists are
      // scroll areas too, and they keep the wheel for their own rows.
      asmdInstallSettingsWheel( dlg );
      scroll.onHorizontalScrollPosUpdated = function( x )
      {
         try
         {
            var y = 0;
            try { y = dlg.rightPane.position ? dlg.rightPane.position.y : dlg.rightPane.y; } catch ( z ) {}
            if ( !(y == y) )
               y = 0;
            if ( "move" in dlg.rightPane )
               dlg.rightPane.move( 0, y );
         }
         catch ( x ) {}
      };
   }

   dlg.presetById = function( id )
   {
      for ( var i = 0; i < this.presets.length; ++i )
         if ( this.presets[i].id == id )
            return this.presets[i];
      return null;
   };

   // Crop for a preset, created on first use. Each target keeps its own.
   dlg.cropFor = function( p, imageId )
   {
      var id = (imageId && String( imageId ).length) ? imageId : this.activeImageId;
      if ( !id )
         id = this.srcWindow.mainView.id;
      var rec = this.batchImageById ? this.batchImageById( id ) : null;
      var w = rec ? rec.w : this.imgW;
      var h = rec ? rec.h : this.imgH;
      var geo = asmdPresetGeometry( p, w, h );
      var key = asmdCropKey( id, p.id );
      var c = this.crops[key];
      if ( !c )
      {
         c = asmdDefaultCrop( w, h, geo.aspect );
         this.crops[key] = c;
      }
      else if ( Math.abs( c.w/c.h - geo.aspect ) > 1e-6 )
      {
         // The aspect changed (preset edited): largest box, same center.
         asmdMaxFitCrop( c, w, h, geo.aspect );
      }
      return c;
   };

   dlg.activeFilePath = function()
   {
      var rec = this.batchImageById ? this.batchImageById( this.activeImageId ) : null;
      try
      {
         if ( rec && rec.window && ("filePath" in rec.window) && rec.window.filePath )
            return rec.window.filePath;
      }
      catch ( e ) {}
      // Only the image that was open when the script started can fall back
      // to that window. Another open view with no file of its own stays unsaved.
      var useSource = !rec || rec.isSource;
      try
      {
         if ( useSource && this.srcWindow && ("filePath" in this.srcWindow) && this.srcWindow.filePath )
            return this.srcWindow.filePath;
      }
      catch ( e2 ) {}
      return "";
   };

   dlg.batchImageById = function( id )
   {
      if ( !this.batchImages )
         return null;
      for ( var i = 0; i < this.batchImages.length; ++i )
         if ( this.batchImages[i].id == id )
            return this.batchImages[i];
      return null;
   };

   dlg.syncBaseNameFromEdit = function( text )
   {
      if ( this.imagesSyncing )
         return;
      var rec = this.batchImageById( this.activeImageId );
      if ( !rec )
         return;
      rec.baseName = asmdSafeFileToken( text );
      if ( !this.images_Tree )
         return;
      for ( var i = 0; i < this.images_Tree.numberOfChildren; ++i )
      {
         var n = this.images_Tree.child( i );
         if ( n.imageId == rec.id )
         {
            this.imagesSyncing = true;
            try { n.setText( 2, rec.baseName ); }
            finally { this.imagesSyncing = false; }
            break;
         }
      }
   };

   dlg.batchBitmapFor = function( rec )
   {
      if ( !rec || rec.isSource )
         return this.mainBitmap;
      if ( !this.carBitmaps[rec.id] )
         this.carBitmaps[rec.id] = asmdRenderPreviewBitmap( rec.window.mainView.image );
      return this.carBitmaps[rec.id];
   };

   dlg.updateTitleImage = function()
   {
      if ( !this.title_Label )
         return;
      var rec = this.batchImageById( this.activeImageId );
      if ( !rec )
         rec = this.batchImageById( this.srcWindow.mainView.id );
      var id = rec ? rec.id : this.srcWindow.mainView.id;
      var w  = rec ? rec.w  : this.imgW;
      var h  = rec ? rec.h  : this.imgH;
      this.title_Label.text = "<b>" + ASMD_TITLE + "</b> " + ASMD_VERSION +
         " &nbsp;&nbsp;Image: " + id + " (" + w + " x " + h + ")";
   };

   dlg.fillImagesTree = function( selectId )
   {
      if ( !this.images_Tree )
         return;
      this.imagesSyncing = true;
      try
      {
         this.images_Tree.clear();
         var paid = asmdIsLicensed();
         var selNode = null;
         var want = selectId || this.activeImageId;
         for ( var i = 0; i < this.batchImages.length; ++i )
         {
            var rec = this.batchImages[i];
            var n = new TreeBoxNode( this.images_Tree );
            var canCheck = paid || rec.isSource;
            n.checkable = canCheck;
            n.checked = canCheck ? !!rec.checked : false;
            if ( !canCheck )
               rec.checked = false;
            var name = rec.id;
            if ( !canCheck )
               name += "  (Unlock with a license)";
            n.setText( 0, name );
            n.setText( 1, rec.w + " x " + rec.h );
            n.setText( 2, rec.baseName );
            n.setAlignment( 1, TextAlign_Right );
            n.imageId = rec.id;
            if ( rec.id == want )
               selNode = n;
         }
         for ( var c = 0; c < 3; ++c )
            this.images_Tree.adjustColumnWidthToContents( c );
         if ( !selNode && this.images_Tree.numberOfChildren > 0 )
            selNode = this.images_Tree.child( 0 );
         if ( selNode )
            this.images_Tree.currentNode = selNode;
      }
      finally
      {
         this.imagesSyncing = false;
      }
   };

   dlg.selectBatchImage = function( id )
   {
      var rec = this.batchImageById( id );
      if ( !rec )
         return;
      if ( this.activeImageId && this.activeImageId != rec.id && this.baseName_Edit )
         this.syncBaseNameFromEdit( this.baseName_Edit.text );
      this.activeImageId = rec.id;
      this.imgW = rec.w;
      this.imgH = rec.h;
      var bmp = this.batchBitmapFor( rec );
      this.preview.setImage( rec.w, rec.h, bmp );
      if ( this.baseName_Edit )
      {
         this.imagesSyncing = true;
         try { this.baseName_Edit.text = rec.baseName; }
         finally { this.imagesSyncing = false; }
      }
      this.updateTitleImage();
      if ( this.currentId )
         this.selectTarget( this.currentId );
      else
         this.updateCropInfo();
      this.updateExample();
      if ( this.updateUpscaleHint )
         this.updateUpscaleHint();
      if ( this.images_Tree && !this.imagesSyncing )
      {
         for ( var i = 0; i < this.images_Tree.numberOfChildren; ++i )
         {
            var n = this.images_Tree.child( i );
            if ( n.imageId == rec.id )
            {
               this.images_Tree.currentNode = n;
               break;
            }
         }
      }
   };

   dlg.currentPreset = function()
   {
      return this.currentId ? this.presetById( this.currentId ) : null;
   };

   dlg.currentCrop = function()
   {
      if ( this.mode == 1 )
         return (this.carSel >= 0 && this.carSel < this.carItems.length) ?
                   this.carEnsureCrop( this.carItems[this.carSel] ) : null;
      var p = this.currentPreset();
      return p ? this.cropFor( p ) : null;
   };

   dlg.selectTarget = function( id )
   {
      var p = this.presetById( id );
      if ( !p )
         return;
      this.currentId = id;
      if ( this.mode == 1 )
         return;   // the carousel owns the preview; restored by showMode( 0 )
      var geo = asmdPresetGeometry( p, this.imgW, this.imgH );
      this.preview.setTarget( this.cropFor( p ), geo.aspect, p.name + "  " + geo.w + " x " + geo.h );
      this.updateCropInfo();
      this.updateExample();
   };

   dlg.syncPresetChecksFromTree = function()
   {
      if ( !this.targets_Tree )
         return;
      for ( var i = 0; i < this.targets_Tree.numberOfChildren; ++i )
      {
         var n = this.targets_Tree.child( i );
         var p = n && n.presetId ? this.presetById( n.presetId ) : null;
         if ( p )
            p.enabled = !!n.checked;
      }
   };

   dlg.fillTree = function( selectId )
   {
      this.treeSyncing = true;
      try
      {
      this.targets_Tree.clear();
      var selNode = null;
      for ( var i = 0; i < this.presets.length; ++i )
      {
         var p = this.presets[i];
         var n = new TreeBoxNode( this.targets_Tree );
         var freeOk = asmdIsLicensed() || asmdPresetIsFree( p );
         n.checkable = freeOk;
         n.checked = freeOk ? !!p.enabled : false;
         var name = p.name + (p.builtIn ? "" : "  (custom)");
         if ( !freeOk )
            name += "  (Unlock with a license)";
         n.setText( 0, name );
         n.setText( 1, asmdPresetSizeText( p ) );
         n.setText( 2, asmdMB( p.maxKB ) );
         n.setText( 3, p.format + (p.sharpen ? "" : ", no sharpening") );
         n.setAlignment( 2, TextAlign_Right );
         n.presetId = p.id;
         if ( p.id == selectId )
            selNode = n;
      }
      for ( var c = 0; c < 4; ++c )
         this.targets_Tree.adjustColumnWidthToContents( c );
      if ( !selNode && this.targets_Tree.numberOfChildren > 0 )
         selNode = this.targets_Tree.child( 0 );
      if ( selNode )
      {
         this.targets_Tree.currentNode = selNode;
         this.selectTarget( selNode.presetId );
      }
      }
      finally
      {
         this.treeSyncing = false;
      }
   };

   dlg.checkAll = function( on )
   {
      for ( var i = 0; i < this.targets_Tree.numberOfChildren; ++i )
      {
         var n = this.targets_Tree.child( i );
         var p = this.presetById( n.presetId );
         var freeOk = asmdIsLicensed() || asmdPresetIsFree( p );
         if ( !freeOk )
         {
            n.checked = false;
            continue;
         }
         n.checked = on;
         if ( p )
            p.enabled = on;
      }
   };

   dlg.uiExportFlags = function()
   {
      var paid = asmdIsLicensed();
      var mode = (this.exportMode == 1 || this.exportMode == 2) ? this.exportMode : 0;
      if ( !paid )
         mode = 0;
      var fit = !!(this.logoFitSize_Radio && this.logoFitSize_Radio.checked);
      return {
         mode: mode,
         frame: mode == 1,
         logo: mode == 2,
         logoFit: mode == 2 && fit,
         fullFrameFit: mode == 1 || (mode == 2 && fit),
         logoOnly: mode == 2
      };
   };

   dlg.setJpegQuality = function( q )
   {
      if ( this._asmdJpegLock )
         return;
      this._asmdJpegLock = true;
      try
      {
         q = asmdClampJpegQuality( q );
         if ( this.jpegQuality_Spin )
            this.jpegQuality_Spin.value = q;
         if ( this.frameJpeg_Spin )
            this.frameJpeg_Spin.value = q;
         if ( this.logoJpeg_Spin )
            this.logoJpeg_Spin.value = q;
      }
      finally
      {
         this._asmdJpegLock = false;
      }
   };

   dlg.relayoutForMode = function()
   {
      // Size the pieces that were shown or hidden, then grow the dialog
      // up to the screen cap. Do not call setFixedSize on this dialog.
      try
      {
         if ( this.exportMode_Control && this.exportMode_Control.adjustToContents )
            this.exportMode_Control.adjustToContents();
         if ( this.jobs_Control && this.jobs_Control.adjustToContents )
            this.jobs_Control.adjustToContents();
         if ( this.processing_Control && this.processing_Control.adjustToContents )
            this.processing_Control.adjustToContents();
         if ( this.rightPane && this.rightPane.adjustToContents )
            this.rightPane.adjustToContents();
      }
      catch ( x ) {}
      if ( ("_asmdReady" in this) && this._asmdReady )
         asmdFitDialogSize( this, false );
      else if ( this.updateSettingsScroll )
         this.updateSettingsScroll();
   };

   dlg.showExportMode = function( index )
   {
      if ( this._asmdExportLock )
         return;
      this._asmdExportLock = true;
      try
      {
         if ( index != 1 && index != 2 )
            index = 0;
         var paid = asmdIsLicensed();
         if ( this.exportFrame_Radio )
            this.exportFrame_Radio.enabled = paid;
         if ( this.exportLogo_Radio )
            this.exportLogo_Radio.enabled = paid;
         if ( !paid )
            index = 0;
         else
            this.opts.exportMode = index;
         var prev = this.exportMode;
         this.exportMode = index;
         if ( this.exportSocial_Radio )
            this.exportSocial_Radio.checked = (index == 0);
         if ( this.exportFrame_Radio )
            this.exportFrame_Radio.checked = (index == 1);
         if ( this.exportLogo_Radio )
            this.exportLogo_Radio.checked = (index == 2);
         if ( index != 0 && this.mode == 1 )
         {
            this._asmdHoldCarousel = true;
            this.showMode( 0 );
         }
         else if ( index == 0 && prev != 0 && prev != -1 && this._asmdHoldCarousel )
         {
            this._asmdHoldCarousel = false;
            this.showMode( 1 );
         }
         if ( index == 2 && prev != 2 )
         {
            this.opts.watermarkExpanded = true;
            if ( this.wm_Control )
               this.wm_Control.visible = true;
            if ( this.wm_Section && this.wm_Section.updateIcon )
               this.wm_Section.updateIcon();
         }
         this.updateExportModeControls();
      }
      finally
      {
         this._asmdExportLock = false;
      }
   };

   dlg.refreshJobsCombo = function( selectName )
   {
      if ( !this.jobs_Combo )
         return;
      var jobs = this.jobs || [];
      var sel = 0, i;
      this._asmdJobsFilling = true;
      try
      {
         if ( this.jobs_Combo.clear )
            this.jobs_Combo.clear();
         if ( jobs.length == 0 )
            this.jobs_Combo.addItem( "(No saved jobs)" );
         else
         {
            for ( i = 0; i < jobs.length; ++i )
            {
               this.jobs_Combo.addItem( jobs[i].name );
               if ( selectName && jobs[i].name == selectName )
                  sel = i;
            }
            this.jobs_Combo.currentItem = sel;
         }
      }
      finally
      {
         this._asmdJobsFilling = false;
      }
      this.updateJobButtons();
   };

   dlg.updateJobButtons = function()
   {
      var paid = asmdIsLicensed();
      var has = paid && this.jobs && this.jobs.length > 0;
      if ( this.jobLoad_Button )
         this.jobLoad_Button.enabled = !!has;
      if ( this.jobSave_Button )
         this.jobSave_Button.enabled = paid;
      if ( this.jobUpdate_Button )
         this.jobUpdate_Button.enabled = !!has;
      if ( this.jobDelete_Button )
         this.jobDelete_Button.enabled = !!has;
      if ( this.jobRename_Button )
         this.jobRename_Button.enabled = !!has;
      var tip = paid ? "<p>Saved jobs store the current mode and its settings.</p>"
                     : "<p>Saved jobs require a license key.</p>";
      if ( this.jobs_Combo )
         this.jobs_Combo.toolTip = tip;
   };

   dlg.jobsNeedLicense = function()
   {
      if ( asmdIsLicensed() )
         return true;
      asmdMessage( "Saved jobs require a license. Enter a license key to unlock them.", StdIcon_Information );
      return false;
   };

   dlg.selectedJobIndex = function()
   {
      if ( !this.jobs || this.jobs.length == 0 || !this.jobs_Combo )
         return -1;
      var i = this.jobs_Combo.currentItem;
      if ( i >= 0 && i < this.jobs.length )
         return i;
      return -1;
   };

   dlg.jobIndexByName = function( name, except )
   {
      var n = asmdTrim( name ).toLowerCase();
      var i;
      for ( i = 0; i < this.jobs.length; ++i )
      {
         if ( i === except )
            continue;
         if ( asmdTrim( this.jobs[i].name ).toLowerCase() == n )
            return i;
      }
      return -1;
   };

   dlg.captureJob = function( name )
   {
      this.collectOptions();
      var o = this.opts;
      var ids = [], i;
      for ( i = 0; i < this.presets.length; ++i )
         if ( this.presets[i].enabled )
            ids.push( this.presets[i].id );
      return asmdNormalizeJob( {
         name: name,
         exportMode: o.exportMode,
         socialMode: (this.mode == 1 || this._asmdHoldCarousel) ? 1 : 0,
         enabledIds: ids,
         template: o.template,
         subfolderPerImage: o.subfolderPerImage,
         overwrite: o.overwrite,
         noUpscale: o.noUpscale,
         interpolation: o.interpolation,
         sharpenEnabled: o.sharpenEnabled,
         sharpenStrength: o.sharpenStrength,
         jpegQuality: o.jpegQuality,
         wmEnabled: o.wmEnabled,
         wmMode: o.wmMode,
         wmText: o.wmText,
         wmLogoPath: o.wmLogoPath,
         wmCorner: o.wmCorner,
         wmOpacity: o.wmOpacity,
         wmSizePercent: o.wmSizePercent,
         fullFrameMaxMB: o.fullFrameMaxMB,
         fullFramePriority: o.fullFramePriority,
         logoFit: o.logoFit,
         logoFormat: o.logoFormat,
         logoMaxMB: o.logoMaxMB,
         logoPriority: o.logoPriority,
         outDir: this.outDir_Edit ? this.outDir_Edit.text : "",
         carShape: o.carShape,
         carCustomW: o.carCustomW,
         carCustomH: o.carCustomH,
         carPanels: o.carPanels,
         carLayout: o.carLayout,
         carPlatform: o.carPlatform,
         carWatermark: o.carWatermark,
         carMaxKB: o.carMaxKB,
         carTemplate: o.carTemplate
      } );
   };

   dlg.saveJobNamed = function( name )
   {
      if ( !this.jobsNeedLicense() )
         return false;
      name = asmdTrim( name ).replace( /[\r\n\t]+/g, " " );
      if ( name.length == 0 )
      {
         asmdMessage( "Please enter a job name.", StdIcon_Warning );
         return false;
      }
      if ( name.length > 80 )
      {
         asmdMessage( "Please use a name of 80 characters or less.", StdIcon_Warning );
         return false;
      }
      if ( this.jobIndexByName( name ) >= 0 )
      {
         asmdMessage( "A job named \"" + name + "\" already exists. Select it and click Update, or choose another name.",
                      StdIcon_Warning );
         return false;
      }
      var job = this.captureJob( name );
      if ( !job )
         return false;
      this.jobs.push( job );
      asmdSaveJobs( this.jobs );
      this.refreshJobsCombo( name );
      this.setStatus( "Saved job \"" + name + "\"." );
      return true;
   };

   dlg.saveJobAs = function()
   {
      if ( !this.jobsNeedLicense() )
         return;
      var d = new AsmdNameDialog( "Save job", "Job name:", "" );
      if ( d.execute() && d.result && d.result.length > 0 )
         this.saveJobNamed( d.result );
   };

   dlg.loadSelectedJob = function()
   {
      if ( !this.jobsNeedLicense() )
         return;
      var i = this.selectedJobIndex();
      if ( i < 0 )
         return;
      this.applyJob( this.jobs[i] );
   };

   dlg.updateSelectedJob = function()
   {
      if ( !this.jobsNeedLicense() )
         return;
      var i = this.selectedJobIndex();
      if ( i < 0 )
         return;
      var name = this.jobs[i].name;
      if ( !asmdConfirm( "Update \"" + name + "\" with the current settings?" ) )
         return;
      var job = this.captureJob( name );
      if ( !job )
         return;
      this.jobs[i] = job;
      asmdSaveJobs( this.jobs );
      this.refreshJobsCombo( name );
      this.setStatus( "Updated job \"" + name + "\"." );
   };

   dlg.deleteSelectedJob = function()
   {
      if ( !this.jobsNeedLicense() )
         return;
      var i = this.selectedJobIndex();
      if ( i < 0 )
         return;
      var name = this.jobs[i].name;
      if ( !asmdConfirm( "Delete the job \"" + name + "\"?" ) )
         return;
      this.jobs.splice( i, 1 );
      asmdSaveJobs( this.jobs );
      this.refreshJobsCombo();
      this.setStatus( "Deleted job \"" + name + "\"." );
   };

   dlg.renameSelectedJob = function()
   {
      if ( !this.jobsNeedLicense() )
         return;
      var i = this.selectedJobIndex();
      if ( i < 0 )
         return;
      var old = this.jobs[i].name;
      var d = new AsmdNameDialog( "Rename job", "New name:", old );
      if ( !(d.execute() && d.result && d.result.length > 0) )
         return;
      if ( d.result.length > 80 )
      {
         asmdMessage( "Please use a name of 80 characters or less.", StdIcon_Warning );
         return;
      }
      if ( this.jobIndexByName( d.result, i ) >= 0 )
      {
         asmdMessage( "A job named \"" + d.result + "\" already exists.", StdIcon_Warning );
         return;
      }
      this.jobs[i].name = d.result;
      asmdSaveJobs( this.jobs );
      this.refreshJobsCombo( d.result );
      this.setStatus( "Renamed job to \"" + d.result + "\"." );
   };

   dlg.applyJob = function( job )
   {
      job = asmdNormalizeJob( job );
      if ( !job )
         return;
      var o = this.opts;
      o.exportMode = job.exportMode;
      o.template = job.template;
      o.subfolderPerImage = job.subfolderPerImage;
      o.overwrite = job.overwrite;
      o.noUpscale = job.noUpscale;
      o.interpolation = job.interpolation;
      o.sharpenEnabled = job.sharpenEnabled;
      o.sharpenStrength = job.sharpenStrength;
      o.jpegQuality = job.jpegQuality;
      o.wmEnabled = job.wmEnabled;
      o.wmMode = job.wmMode;
      o.wmText = job.wmText;
      o.wmLogoPath = job.wmLogoPath;
      o.wmCorner = job.wmCorner;
      o.wmOpacity = job.wmOpacity;
      o.wmSizePercent = job.wmSizePercent;
      o.fullFrameMaxMB = job.fullFrameMaxMB;
      o.fullFramePriority = job.fullFramePriority;
      o.fullFrameFit = (job.exportMode == 1);
      o.logoOnly = (job.exportMode == 2);
      o.logoFit = job.logoFit;
      o.logoFormat = job.logoFormat;
      o.logoMaxMB = job.logoMaxMB;
      o.logoPriority = job.logoPriority;
      o.mode = job.socialMode;
      o.carShape = job.carShape;
      o.carCustomW = job.carCustomW;
      o.carCustomH = job.carCustomH;
      o.carPanels = job.carPanels;
      o.carLayout = job.carLayout;
      o.carPlatform = job.carPlatform;
      o.carWatermark = job.carWatermark;
      o.carMaxKB = job.carMaxKB;
      o.carTemplate = job.carTemplate;

      this.template_Edit.text = o.template;
      this.subfolder_Check.checked = !!o.subfolderPerImage;
      this.overwrite_Check.checked = !!o.overwrite;
      this.noUpscale_Check.checked = !!o.noUpscale;
      this.interp_Combo.currentItem = o.interpolation;
      this.sharpenEnable_Check.checked = !!o.sharpenEnabled;
      if ( this.sharpen_Control.setValue )
         this.sharpen_Control.setValue( o.sharpenStrength );
      else
         this.sharpen_Control.value = o.sharpenStrength;
      this.sharpen_Control.enabled = !!o.sharpenEnabled && job.exportMode != 2;
      this.setJpegQuality( o.jpegQuality );
      this.wmMode_Combo.currentItem = o.wmMode;
      this.wmText_Edit.text = o.wmText;
      this.wmLogo_Edit.text = o.wmLogoPath;
      this.wmCorner_Combo.currentItem = asmdCornerComboIndex( o.wmCorner );
      if ( this.wmOpacity_Control.setValue )
         this.wmOpacity_Control.setValue( o.wmOpacity );
      if ( this.wmSize_Control.setValue )
         this.wmSize_Control.setValue( o.wmSizePercent );
      if ( this.wm_Section && this.wm_Section.checkBox )
         this.wm_Section.checkBox.checked = !!o.wmEnabled;
      this.fullFrameMB_Edit.setValue( o.fullFrameMaxMB );
      this.fullFramePriority_Combo.currentItem = (o.fullFramePriority == 1) ? 1 : 0;
      this.logoFitOriginal_Radio.checked = !o.logoFit;
      this.logoFitSize_Radio.checked = !!o.logoFit;
      this._asmdLogoFormatHold = "";
      this.logoFormat_Combo.currentItem = asmdLogoFormatComboIndex( o.logoFormat );
      this.logoMB_Edit.setValue( o.logoMaxMB );
      this.logoPriority_Combo.currentItem = (o.logoPriority == 1) ? 1 : 0;
      if ( job.outDir && String( job.outDir ).length > 0 )
         this.outDir_Edit.text = job.outDir;

      var onIds = {}, i;
      for ( i = 0; i < job.enabledIds.length; ++i )
         onIds[job.enabledIds[i]] = true;
      for ( i = 0; i < this.presets.length; ++i )
         this.presets[i].enabled = !!onIds[this.presets[i].id];

      this.carPlatform_Combo.currentItem = o.carPlatform;
      this.carLayout_Combo.currentItem = o.carLayout;
      this.carPanels_Spin.value = o.carPanels;
      this.carW_Spin.value = o.carCustomW;
      this.carH_Spin.value = o.carCustomH;
      this.carWm_Combo.currentItem = o.carWatermark;
      this.carMaxMB_Edit.setValue( o.carMaxKB/1000 );
      this.carTemplate_Edit.text = o.carTemplate;
      if ( this.carApplyPlatform )
         this.carApplyPlatform( false );

      this._asmdHoldCarousel = (job.socialMode == 1 && job.exportMode != 0);
      this.showExportMode( asmdIsLicensed() ? job.exportMode : 0 );
      if ( this.exportMode == 0 )
         this.showMode( job.socialMode == 1 ? 1 : 0 );
      if ( this.mode != 1 && this.fillTree )
         this.fillTree( this.currentId );
      this.updateWatermarkControls();
      if ( this.updateLogoHint )
         this.updateLogoHint();
      if ( this.carUpdateExample )
         this.carUpdateExample();
      this.setStatus( "Loaded job \"" + job.name + "\"." );
   };

   dlg.updateCropInfo = function()
   {
      if ( this.mode == 1 )
      {
         this.carUpdateCropInfo();
         return;
      }
      var flags = this.uiExportFlags();
      var note = asmdWholeFrameNote( flags.fullFrameFit, flags.logoOnly );
      if ( note.length > 0 )
      {
         this.cropInfo_Label.text = note;
         this.upscaleHint_Label.text = " ";
         this.upscaleHint_Label.visible = false;
         return;
      }
      var p = this.currentPreset();
      if ( !p )
         return;
      var c = this.cropFor( p );
      var geo = asmdPresetGeometry( p, this.imgW, this.imgH );
      var r = asmdCropRect( c, this.imgW, this.imgH );
      var s = geo.w/r.width;
      var t = "Crop " + r.width + " x " + r.height + " at (" + r.x0 + ", " + r.y0 + ")  >  " +
              geo.w + " x " + geo.h + "  (scale " + s.toFixed( 3 ) + ")";
      this.cropInfo_Label.text = t;
      this.updateUpscaleHint();
   };

   dlg.updateUpscaleHint = function()
   {
      var text = "";
      if ( this.mode == 1 )
      {
         if ( this.carSel >= 0 && this.carSel < this.carItems.length )
         {
            var it = this.carItems[this.carSel];
            if ( !(it.type == "other" && it.fit) && it.crop )
            {
               var image = this.carItemImage( it );
               var r = asmdCropRect( it.crop, image.width, image.height );
               var z = this.carSlideSize();
               var outW = z.w, outH = z.h;
               if ( it.type == "pano" )
               {
                  outW = it.n*z.w;
                  outH = z.h;
               }
               else if ( it.type == "grid" )
               {
                  outW = it.cols*z.w;
                  outH = it.rows*z.h;
               }
               text = asmdUpscaleHint( r.width, r.height, outW, outH, this.noUpscale_Check.checked, true );
            }
         }
      }
      else
      {
         var p = this.currentPreset();
         if ( p )
         {
            var c = this.cropFor( p );
            var geo = asmdPresetGeometry( p, this.imgW, this.imgH );
            var rr = asmdCropRect( c, this.imgW, this.imgH );
            text = asmdUpscaleHint( rr.width, rr.height, geo.w, geo.h, this.noUpscale_Check.checked, false );
         }
      }
      this.upscaleHint_Label.text = (text.length > 0) ? text : " ";
      this.upscaleHint_Label.visible = (text.length > 0);
   };

   dlg.tokensFor = function( p, w, h, baseName )
   {
      var name = (baseName && String( baseName ).length) ? baseName : this.baseName_Edit.text;
      return {
         name:     asmdSafeFileToken( name ),
         platform: asmdSafeFileToken( p.platform || p.name ),
         preset:   asmdSafeFileToken( p.name ),
         w:        w,
         h:        h,
         date:     asmdDateString(),
         time:     asmdTimeString(),
         kb:       p.maxKB
      };
   };

   dlg.updateExample = function()
   {
      var flags = this.uiExportFlags();
      if ( flags.frame )
      {
         var mb = (this.fullFrameMB_Edit && this.fullFrameMB_Edit.value >= 0.05) ? this.fullFrameMB_Edit.value : 10;
         var pseudo = { name: "Full frame", platform: "Full-Frame",
                        maxKB: Math.max( 10, Math.round( mb*1000 ) ), format: "JPEG" };
         this.example_Label.text = asmdBuildFileName( this.template_Edit.text,
            this.tokensFor( pseudo, this.imgW, this.imgH ), "JPEG" );
         return;
      }
      if ( flags.logo )
      {
         var lmb = (this.logoMB_Edit && this.logoMB_Edit.value >= 0.05) ? this.logoMB_Edit.value : 10;
         if ( flags.logoFit && this.fullFrameMB_Edit )
            lmb = (this.logoMB_Edit && this.logoMB_Edit.value >= 0.05) ? this.logoMB_Edit.value : 10;
         var format = "JPEG";
         if ( !flags.logoFit && this.logoFormat_Combo )
            format = asmdLogoFormatFromComboIndex( this.logoFormat_Combo.currentItem );
         if ( !flags.logoFit && format == "SOURCE" )
         {
            var spec = asmdDetectSourceFormat( this.activeFilePath ? this.activeFilePath() : "" );
            this.example_Label.text = asmdLogoSourceFileName( this.baseName_Edit.text, spec.ext );
            return;
         }
         var pseudoL = { name: "Logo only", platform: "Logo",
                         maxKB: Math.max( 10, Math.round( lmb*1000 ) ), format: format };
         this.example_Label.text = asmdBuildFileName( this.template_Edit.text,
            this.tokensFor( pseudoL, this.imgW, this.imgH ), format );
         return;
      }
      var p = this.currentPreset() || this.presets[0];
      if ( !p )
         return;
      var geo = asmdPresetGeometry( p, this.imgW, this.imgH );
      this.example_Label.text = asmdBuildFileName( this.template_Edit.text,
                                   this.tokensFor( p, geo.w, geo.h ), p.format );
   };

   dlg.updateExportModeControls = function()
   {
      if ( this._asmdModeUiLock )
         return;
      this._asmdModeUiLock = true;
      try
      {
      var paid = asmdIsLicensed();
      var mode = (this.exportMode == 1 || this.exportMode == 2) ? this.exportMode : 0;
      var social = (mode == 0);
      var logoOn = (mode == 2);
      var fit = !!(this.logoFitSize_Radio && this.logoFitSize_Radio.checked);
      if ( this.exportSocial_Radio )
         this.exportSocial_Radio.enabled = true;
      if ( this.exportFrame_Radio )
         this.exportFrame_Radio.enabled = paid;
      if ( this.exportLogo_Radio )
         this.exportLogo_Radio.enabled = paid;
      if ( this.exportHelp_Label )
         this.exportHelp_Label.text = asmdExportModeHelp( mode );
      if ( this.exportLicense_Label )
         this.exportLicense_Label.visible = !paid;
      if ( this.frameOptions_Control )
         this.frameOptions_Control.visible = (mode == 1);
      if ( this.logoOptions_Control )
         this.logoOptions_Control.visible = (mode == 2);
      if ( this.fullFrameMB_Edit )
         this.fullFrameMB_Edit.enabled = (mode == 1);
      if ( this.fullFramePriority_Combo )
         this.fullFramePriority_Combo.enabled = (mode == 1);
      if ( this.frameJpeg_Spin )
         this.frameJpeg_Spin.enabled = (mode == 1);
      if ( this.logoFormat_Combo )
      {
         if ( logoOn && fit )
         {
            if ( !this._asmdLogoFormatHold )
            {
               var shown = asmdLogoFormatFromComboIndex( this.logoFormat_Combo.currentItem );
               this._asmdLogoFormatHold = (shown == "JPEG")
                  ? asmdStoredLogoFormat( this.opts.logoFormat, "SOURCE" )
                  : shown;
            }
            var jpegIndex = asmdLogoFormatComboIndex( "JPEG" );
            if ( this.logoFormat_Combo.currentItem != jpegIndex )
               this.logoFormat_Combo.currentItem = jpegIndex;
            this.logoFormat_Combo.enabled = false;
         }
         else
         {
            this.logoFormat_Combo.enabled = logoOn;
            if ( this._asmdLogoFormatHold )
            {
               this.logoFormat_Combo.currentItem = asmdLogoFormatComboIndex( this._asmdLogoFormatHold );
               this._asmdLogoFormatHold = "";
            }
         }
      }
      if ( this.logoPriority_Combo )
         this.logoPriority_Combo.enabled = logoOn && fit;
      if ( this.logoMB_Edit )
         this.logoMB_Edit.enabled = logoOn;
      var logoFmtNow = (this.logoFormat_Combo && !fit)
         ? asmdLogoFormatFromComboIndex( this.logoFormat_Combo.currentItem )
         : (this._asmdLogoFormatHold || "JPEG");
      if ( fit )
         logoFmtNow = "JPEG";
      if ( this.logoJpeg_Spin )
         this.logoJpeg_Spin.enabled = logoOn && logoFmtNow != "PNG";
      if ( this.mode_Control )
         this.mode_Control.visible = social;
      if ( this.targets_Group )
         this.targets_Group.visible = social && this.mode != 1;
      if ( this.carousel_Group )
         this.carousel_Group.visible = social && this.mode == 1;
      if ( this.images_Group )
         this.images_Group.visible = (this.mode != 1);
      if ( this.cropButtons_Control )
         this.cropButtons_Control.visible = social;
      if ( this.preview )
      {
         this.preview.hideCrop = !social;
         if ( this.preview.update )
            this.preview.update();
      }
      if ( this.jpegProcessing_Control )
         this.jpegProcessing_Control.visible = social;
      if ( this.upscale_Control )
         this.upscale_Control.visible = social;
      if ( this.processing_Section )
         this.processing_Section.visible = !logoOn;
      if ( this.processing_Control )
      {
         if ( logoOn )
            this.processing_Control.visible = false;
         else
            this.processing_Control.visible = !!this.opts.processingExpanded;
      }
      if ( this.center_Button )
         this.center_Button.enabled = social;
      if ( this.max_Button )
         this.max_Button.enabled = social;
      if ( this.reset_Button )
         this.reset_Button.enabled = social;
      if ( this.sameCenter_Button )
         this.sameCenter_Button.enabled = social && this.mode != 1;
      if ( this.sharpenEnable_Check )
         this.sharpenEnable_Check.enabled = !logoOn;
      if ( this.sharpen_Control && this.sharpenEnable_Check )
         this.sharpen_Control.enabled = !logoOn && !!this.sharpenEnable_Check.checked;
      if ( this.updateJobButtons )
         this.updateJobButtons();
      if ( this.updateCropInfo )
         this.updateCropInfo();
      if ( this.updateExample )
         this.updateExample();
      if ( ("_asmdReady" in this) && this._asmdReady )
         this.relayoutForMode();
      }
      finally
      {
         this._asmdModeUiLock = false;
      }
   };

   dlg.wmIsChecked = function()
   {
      if ( this.wm_Section && this.wm_Section.isChecked )
         return this.wm_Section.isChecked();
      if ( this.wm_Section && this.wm_Section.checkBox )
         return !!this.wm_Section.checkBox.checked;
      return false;
   };

   dlg.updateWatermarkControls = function()
   {
      var paid = asmdIsLicensed();
      if ( this.wm_Section && this.wm_Section.checkBox )
         this.wm_Section.checkBox.enabled = paid;
      if ( this.wm_Control )
         this.wm_Control.enabled = paid;
      var logo = this.wmMode_Combo.currentItem == 1;
      this.wmText_Edit.enabled = paid && !logo;
      this.wmLogo_Control.enabled = paid && logo;
      this.updateLogoHint();
   };

   dlg.updateLogoHint = function()
   {
      var text = "";
      if ( this.wmMode_Combo.currentItem == 1 )
         text = asmdLogoHint( asmdTrim( this.wmLogo_Edit.text ),
                              asmdInspectLogo( asmdTrim( this.wmLogo_Edit.text ) ) );
      this.logoHint_Label.text = (text.length > 0) ? text : " ";
      this.logoHint_Label.visible = (text.length > 0);
   };

   dlg.collectOptions = function()
   {
      var o = this.opts;
      o.template          = asmdTrim( this.template_Edit.text );
      o.subfolderPerImage = this.subfolder_Check.checked;
      o.overwrite         = this.overwrite_Check.checked;
      o.noUpscale         = this.noUpscale_Check.checked;
      o.interpolation     = this.interp_Combo.currentItem;
      o.sharpenEnabled    = this.sharpenEnable_Check.checked;
      o.sharpenStrength   = this.sharpen_Control.value;
      o.wmEnabled         = this.wmIsChecked();
      o.watermarkExpanded  = (this.wm_Section && this.wm_Section.isExpanded) ?
                             this.wm_Section.isExpanded() : this.opts.watermarkExpanded;
      o.wmMode            = this.wmMode_Combo.currentItem;
      o.wmText            = this.wmText_Edit.text;
      o.wmLogoPath        = asmdTrim( this.wmLogo_Edit.text );
      o.wmCorner          = asmdCornerFromCombo( this.wmCorner_Combo.currentItem );
      o.wmOpacity         = this.wmOpacity_Control.value;
      o.wmSizePercent     = this.wmSize_Control.value;
      var q = this.jpegQuality_Spin ? this.jpegQuality_Spin.value : o.jpegQuality;
      if ( this.exportMode == 1 && this.frameJpeg_Spin )
         q = this.frameJpeg_Spin.value;
      else if ( this.exportMode == 2 && this.logoJpeg_Spin )
      {
         var pngOriginal = this.logoFormat_Combo && !this.logoFitSize_Radio.checked &&
                           asmdLogoFormatFromComboIndex( this._asmdLogoFormatHold
                              ? asmdLogoFormatComboIndex( this._asmdLogoFormatHold )
                              : this.logoFormat_Combo.currentItem ) == "PNG";
         if ( !pngOriginal )
            q = this.logoJpeg_Spin.value;
      }
      o.jpegQuality       = asmdClampJpegQuality( q );
      o.fullFrameMaxMB    = (this.fullFrameMB_Edit && this.fullFrameMB_Edit.value >= 0.05) ?
                            this.fullFrameMB_Edit.value : ASMD_DEFAULTS.fullFrameMaxMB;
      o.fullFramePriority = (this.fullFramePriority_Combo && this.fullFramePriority_Combo.currentItem == 1) ? 1 : 0;
      o.logoFit           = !!(this.logoFitSize_Radio && this.logoFitSize_Radio.checked);
      if ( this._asmdLogoFormatHold )
         o.logoFormat = asmdStoredLogoFormat( this._asmdLogoFormatHold, "SOURCE" );
      else if ( this.logoFormat_Combo )
         o.logoFormat = asmdLogoFormatFromComboIndex( this.logoFormat_Combo.currentItem );
      else
         o.logoFormat = asmdStoredLogoFormat( o.logoFormat, "SOURCE" );
      o.logoMaxMB         = (this.logoMB_Edit && this.logoMB_Edit.value >= 0.05) ?
                            this.logoMB_Edit.value : ASMD_DEFAULTS.logoMaxMB;
      o.logoPriority      = (this.logoPriority_Combo && this.logoPriority_Combo.currentItem == 1) ? 1 : 0;
      // Remember a licensed mode across free sessions. The free UI cannot change it.
      if ( asmdIsLicensed() )
      {
         var mode = 0;
         if ( this.exportLogo_Radio && this.exportLogo_Radio.checked )
            mode = 2;
         else if ( this.exportFrame_Radio && this.exportFrame_Radio.checked )
            mode = 1;
         o.exportMode = mode;
         this.exportMode = mode;
         o.fullFrameFit = (mode == 1);
         o.logoOnly = (mode == 2);
         if ( mode == 0 )
            o.mode = this.mode;
         else if ( this._asmdHoldCarousel )
            o.mode = 1;
      }
      if ( this.exportMode != 2 )
      {
         o.processingExpanded = (this.processing_Section && this.processing_Section.isExpanded) ?
                                this.processing_Section.isExpanded() : this.opts.processingExpanded;
      }
      if ( o.template.length == 0 )
         o.template = ASMD_DEFAULTS.template;
      o.carShape          = this.carShapeIndex();
      o.carCustomW        = this.carW_Spin.value;
      o.carCustomH        = this.carH_Spin.value;
      o.carPanels         = this.carPanels_Spin.value;
      o.carLayout         = this.carLayout_Combo.currentItem;
      o.carPlatform       = this.carPlatform_Combo.currentItem;
      o.carWatermark      = this.carWm_Combo.currentItem;
      o.carMaxKB          = Math.max( 10, Math.round( this.carMaxMB_Edit.value*1000 ) );
      o.carTemplate       = asmdTrim( this.carTemplate_Edit.text );
      if ( o.carTemplate.length == 0 )
         o.carTemplate = ASMD_DEFAULTS.carTemplate;
   };

   dlg.applyLicenseState = function()
   {
      var paid = asmdIsLicensed();
      var email = asmdLicensedEmail();
      if ( paid )
         this.licenseBanner_Label.text = "<b>Licensed to " + email + "</b>";
      else
         this.licenseBanner_Label.text = "Free version: unlimited Instagram single exports, with a small " +
            "AstroMD Social Export credit on each file. Other platforms, custom presets, saved jobs, your own " +
            "watermark, exporting several open images, carousel export, full frame size target, " +
            "and logo-only export need a license.";
      this.license_Button.text = paid ? "License..." : "Enter license key";
      this.add_Button.enabled = paid;
      this.edit_Button.enabled = paid;
      this.delete_Button.enabled = paid;
      this.updateWatermarkControls();
      if ( this.refreshJobsCombo )
         this.refreshJobsCombo();
      if ( this.showExportMode )
         this.showExportMode( this.opts.exportMode );
      else if ( this.updateExportModeControls )
         this.updateExportModeControls();
      this.fillImagesTree( this.activeImageId );
      if ( this.mode != 1 )
         this.fillTree( this.currentId );
   };

   dlg.showLicenseDialog = function()
   {
      var d = new AsmdLicenseDialog();
      d.execute();
      this.applyLicenseState();
   };

   // ---- Preset management --------------------------------------------------

   dlg.addCustomFromDialog = function( d )
   {
      var p = d.preset;
      p.id = "custom-" + (new Date).getTime();
      p.builtIn = false;
      p.enabled = true;
      this.presets.push( p );
      asmdSavePresets( this.presets );
      this.fillTree( p.id );
   };

   dlg.addPreset = function()
   {
      if ( !asmdIsLicensed() )
      {
         asmdMessage( "Custom presets require a license. Enter a license key to unlock them.", StdIcon_Information );
         return;
      }
      var base = { id: "", name: "My preset", platform: "Custom", width: 1080, height: 1350,
                   ratio: "", longEdge: 0, maxKB: 1000, format: "JPEG", sharpen: true, enabled: true };
      var d = new AsmdPresetDialog( base, true );
      if ( d.execute() )
         this.addCustomFromDialog( d );
   };

   dlg.editPreset = function()
   {
      if ( !asmdIsLicensed() )
      {
         asmdMessage( "Custom presets require a license. Enter a license key to unlock them.", StdIcon_Information );
         return;
      }
      var p = this.currentPreset();
      if ( !p )
         return;
      if ( p.builtIn )
      {
         if ( !asmdConfirm( "Built-in presets can't be changed, but you can edit a custom copy. Create one now?" ) )
            return;
         var copy = asmdClonePreset( p );
         copy.name = p.name + " (copy)";
         var d1 = new AsmdPresetDialog( copy, true );
         if ( d1.execute() )
            this.addCustomFromDialog( d1 );
         return;
      }
      var d = new AsmdPresetDialog( p, false );
      if ( d.execute() )
      {
         var e = d.preset;
         e.id = p.id;
         e.builtIn = false;
         e.enabled = p.enabled;
         for ( var i = 0; i < this.presets.length; ++i )
            if ( this.presets[i].id == p.id )
               this.presets[i] = e;
         asmdSavePresets( this.presets );
         this.fillTree( p.id );
      }
   };

   dlg.deletePreset = function()
   {
      if ( !asmdIsLicensed() )
      {
         asmdMessage( "Custom presets require a license. Enter a license key to unlock them.", StdIcon_Information );
         return;
      }
      var p = this.currentPreset();
      if ( !p )
         return;
      if ( p.builtIn )
      {
         asmdMessage( "Built-in presets can't be deleted. Uncheck the preset to skip it.", StdIcon_Warning );
         return;
      }
      if ( !asmdConfirm( "Delete the custom preset \"" + p.name + "\"?" ) )
         return;
      for ( var i = 0; i < this.presets.length; ++i )
         if ( this.presets[i].id == p.id )
         {
            this.presets.splice( i, 1 );
            break;
         }
      var suf = "\t" + p.id;
      for ( var k in this.crops )
      {
         if ( !this.crops.hasOwnProperty( k ) )
            continue;
         if ( k.length >= suf.length && k.substring( k.length - suf.length ) == suf )
            delete this.crops[k];
      }
      asmdSavePresets( this.presets );
      this.currentId = null;
      this.fillTree( null );
   };

   // ---- Export -------------------------------------------------------------

   dlg.setBusy = function( on )
   {
      this.busy = on;
      this.export_Button.enabled = !on;
      this.close_Button.enabled = !on;
      this.openFolder_Button.enabled = !on;
      this.license_Button.enabled = !on;
      this.targets_Group.enabled = !on;
      if ( this.images_Group )
         this.images_Group.enabled = !on;
      this.carousel_Group.enabled = !on;
      this.mode_Control.enabled = !on;
      this.output_Group.enabled = !on;
      if ( this.processing_Control )
         this.processing_Control.enabled = !on;
      if ( this.processing_Section )
         this.processing_Section.enabled = !on;
      if ( this.wm_Control )
         this.wm_Control.enabled = !on && asmdIsLicensed();
      if ( this.wm_Section && this.wm_Section.checkBox )
         this.wm_Section.checkBox.enabled = !on && asmdIsLicensed();
      if ( this.exportMode_Control )
         this.exportMode_Control.enabled = !on;
      if ( this.jobs_Control )
         this.jobs_Control.enabled = !on;
      this.preview.enabled = !on;
      if ( !on && this.updateExportModeControls )
         this.updateExportModeControls();
   };

   dlg.setStatus = function( text )
   {
      this.status_Label.text = text;
      processEvents();
   };

   dlg.runExport = function()
   {
      if ( this.mode == 1 )
      {
         this.runCarouselExport();
         return;
      }
      this.collectOptions();
      if ( this.syncBaseNameFromEdit )
         this.syncBaseNameFromEdit( this.baseName_Edit.text );
      var licensed = asmdIsLicensed();
      var opts = asmdRuntimeOptions( this.opts, licensed );
      var frameKB = Math.max( 10, Math.round( ((opts.fullFrameMaxMB >= 0.05) ? opts.fullFrameMaxMB : 10)*1000 ) );
      var logoKB = Math.max( 10, Math.round( ((opts.logoMaxMB >= 0.05) ? opts.logoMaxMB : 10)*1000 ) );

      var plan;
      if ( opts.logoOnly )
         plan = asmdLogoOnlyPlan( this.batchImages || [], licensed, opts.logoFormat,
                                  opts.fullFrameFit ? frameKB : logoKB );
      else if ( opts.fullFrameFit )
         plan = asmdFullFramePlan( this.batchImages || [], licensed, frameKB );
      else
         plan = asmdBatchExportPlan( this.batchImages || [], this.presets, licensed );
      var checkedImages = 0, i;
      if ( this.batchImages )
         for ( i = 0; i < this.batchImages.length; ++i )
            if ( this.batchImages[i].checked && (licensed || this.batchImages[i].isSource) )
               ++checkedImages;
      var checkedTargets = 0;
      for ( i = 0; i < this.presets.length; ++i )
         if ( this.presets[i].enabled && (licensed || asmdPresetIsFree( this.presets[i] )) )
            ++checkedTargets;
      if ( checkedImages == 0 )
      {
         asmdMessage( licensed ? "Check at least one image to export." :
            "The free version can export the current image only. Check it, or enter a license key to export several open images.",
            StdIcon_Warning );
         return;
      }
      if ( !opts.fullFrameFit && !opts.logoOnly && checkedTargets == 0 )
      {
         asmdMessage( licensed ? "Check at least one target to export." :
            "The free version can export Instagram presets only. Check an Instagram target, or enter a license key.",
            StdIcon_Warning );
         return;
      }
      if ( opts.logoOnly )
      {
         if ( !opts.wmEnabled )
         {
            asmdMessage( "Logo only needs a watermark. Turn on Watermark / signature and choose a logo or text.",
                         StdIcon_Warning );
            return;
         }
         if ( opts.wmMode != 1 && asmdTrim( opts.wmText ).length == 0 )
         {
            asmdMessage( "Logo only needs watermark text, or switch the type to Logo image and choose a file.",
                         StdIcon_Warning );
            return;
         }
      }
      for ( i = 0; i < plan.length; ++i )
      {
         if ( asmdTrim( plan[i].baseName ).length == 0 )
         {
            asmdMessage( "Please enter a base name for " + plan[i].imageId + ".", StdIcon_Warning );
            return;
         }
      }
      if ( opts.wmEnabled && opts.wmMode == 1 && !File.exists( opts.wmLogoPath ) )
      {
         asmdMessage( "The watermark logo file was not found:\n" + opts.wmLogoPath, StdIcon_Warning );
         return;
      }

      var rootDir = asmdCleanDir( this.outDir_Edit.text );
      if ( rootDir.length == 0 )
      {
         asmdMessage( "Please choose an output folder.", StdIcon_Warning );
         return;
      }
      var made = {};
      for ( i = 0; i < plan.length; ++i )
      {
         var imgDir = rootDir;
         if ( opts.subfolderPerImage )
            imgDir += "/" + asmdSafeFileToken( plan[i].baseName );
         if ( made[imgDir] )
            continue;
         try
         {
            if ( !File.directoryExists( imgDir ) )
               File.createDirectory( imgDir, true );
            made[imgDir] = true;
         }
         catch ( x )
         {
            asmdMessage( "Could not create the output folder:\n" + imgDir + "\n\n" + x.message, StdIcon_Error );
            return;
         }
      }

      this.opts.save();
      asmdSavePresets( this.presets );

      if ( opts.logoOnly && !opts.fullFrameFit && opts.logoFormat == "SOURCE" )
      {
         var fallbackIds = [], seenFb = {}, fp, specFb;
         for ( i = 0; i < plan.length; ++i )
         {
            if ( seenFb[plan[i].imageId] )
               continue;
            fp = "";
            try
            {
               if ( plan[i].window && ("filePath" in plan[i].window) && plan[i].window.filePath )
                  fp = plan[i].window.filePath;
            }
            catch ( eFp ) {}
            specFb = asmdDetectSourceFormat( fp );
            if ( specFb.fallback )
            {
               seenFb[plan[i].imageId] = true;
               fallbackIds.push( plan[i].imageId );
            }
         }
         if ( fallbackIds.length > 0 )
         {
            var verb = (fallbackIds.length == 1) ? "has" : "have";
            asmdMessage( "Same as source uses the file type of each image. " +
               fallbackIds.join( ", " ) + " " + verb +
               " no saved file this export can match, so those files will be 16-bit TIFF. " +
               "Choose JPEG or PNG in Format if you want a different file.",
               StdIcon_Warning );
         }
      }

      this.setBusy( true );
      console.show();
      console.abortEnabled = true;
      console.writeln( "" );
      console.writeln( "<b>" + ASMD_TITLE + " " + ASMD_VERSION + "</b>" );
      this.lastOutDir = rootDir;
      console.writeln( "Output folder: " + rootDir );
      if ( checkedImages == 1 )
         console.writeln( "Source: " + plan[0].imageId + " (" + plan[0].w + " x " + plan[0].h + ")" );
      else
      {
         console.writeln( "Images: " + checkedImages + "." );
         var listed = {};
         for ( i = 0; i < plan.length; ++i )
         {
            if ( listed[plan[i].imageId] )
               continue;
            listed[plan[i].imageId] = true;
            console.writeln( "   " + plan[i].imageId + " (" + plan[i].w + " x " + plan[i].h + ")" );
         }
      }
      if ( opts.fullFrameFit )
      {
         var priorityName = (opts.fullFramePriority == 1) ? "Largest size" : "Highest quality";
         console.writeln( "Full frame fit (" + priorityName + "): JPEG quality " +
                          asmdClampJpegQuality( opts.jpegQuality ) +
                          ", target " + asmdMB( frameKB ) +
                          ". Crop and preset sizes are not used. Files: " + plan.length +
                          (opts.logoOnly ? ". Logo only: watermark, then fit." : ".") +
                          " Press the Process Console's Pause/Abort button to stop." );
      }
      else if ( opts.logoOnly && opts.logoFormat == "SOURCE" )
         console.writeln( "Logo only (same as source): no crop, no sharpening, no preset resize, " +
                          "and no 8-bit sRGB conversion. The file keeps the source format, bit depth, " +
                          "and pixel size. The name adds _logo so the original is not overwritten. " +
                          "Files: " + plan.length +
                          ". Press the Process Console's Pause/Abort button to stop." );
      else if ( opts.logoOnly )
         console.writeln( "Logo only (" + opts.logoFormat + "): no crop, no sharpening, no preset resize. " +
                          "Target " + asmdMB( logoKB ) +
                          ". Files: " + plan.length +
                          ". JPEG quality " + asmdClampJpegQuality( opts.jpegQuality ) +
                          " down to " + ASMD_JPEG_SEARCH_FLOOR +
                          ". Press the Process Console's Pause/Abort button to stop." );
      else
         console.writeln( "Targets: " + checkedTargets + (checkedImages > 1 ? " each" : "") +
                          ". Files: " + plan.length +
                          ". JPEG quality " + asmdClampJpegQuality( opts.jpegQuality ) +
                          " down to " + ASMD_JPEG_SEARCH_FLOOR +
                          ". Pixel size stays exact unless quality " + ASMD_JPEG_SEARCH_FLOOR + " is still over. " +
                          "Press the Process Console's Pause/Abort button to stop." );

      var results = [];
      var t0 = (new Date).getTime();
      var self = this;
      try
      {
         var lastImageId = "";
         for ( var t = 0; t < plan.length; ++t )
         {
            var jobPlan = plan[t];
            var p = jobPlan.preset;
            var imgW = jobPlan.w, imgH = jobPlan.h;
            if ( jobPlan.imageId != lastImageId )
            {
               lastImageId = jobPlan.imageId;
               console.writeln( "" );
               console.writeln( "<b>Image " + jobPlan.imageIndex + " of " + jobPlan.imageCount +
                                ": " + jobPlan.imageId + " (" + imgW + " x " + imgH + ")</b>" );
            }
            var progress = asmdBatchProgressText( jobPlan.imageIndex, jobPlan.imageCount,
                                                  jobPlan.presetIndex, jobPlan.presetCount );
            var head = progress + " - " + p.name;
            console.writeln( "" );
            console.writeln( "<b>" + head + "</b>" );
            this.setStatus( head + "..." );

            // Starting pixel size baked into the file name. A JPEG that has to
            // shrink to meet the target is renamed to the final size.
            var whole = !!(opts.fullFrameFit || opts.logoOnly);
            var geo, crop, w, h;
            if ( whole )
            {
               w = imgW;
               h = imgH;
               crop = { x: 0, y: 0, w: imgW, h: imgH };
            }
            else
            {
               geo = asmdPresetGeometry( p, imgW, imgH );
               crop = this.cropFor( p, jobPlan.imageId );
               var r = asmdCropRect( crop, imgW, imgH );
               w = geo.w;
               h = geo.h;
               if ( opts.noUpscale && r.width < w )
               {
                  var f = r.width/w;
                  w = Math.max( 1, Math.round( w*f ) );
                  h = Math.max( 1, Math.round( h*f ) );
               }
            }
            var srcPath = "";
            try
            {
               if ( jobPlan.window && ("filePath" in jobPlan.window) && jobPlan.window.filePath )
                  srcPath = jobPlan.window.filePath;
            }
            catch ( eSrc ) {}
            var fileName;
            if ( opts.logoOnly && !opts.fullFrameFit && opts.logoFormat == "SOURCE" )
            {
               var nameSpec = asmdDetectSourceFormat( srcPath );
               fileName = asmdLogoSourceFileName( jobPlan.baseName, nameSpec.ext );
            }
            else
               fileName = asmdBuildFileName( opts.template, this.tokensFor( p, w, h, jobPlan.baseName ), p.format );
            var outDir = rootDir;
            if ( opts.subfolderPerImage )
               outDir += "/" + asmdSafeFileToken( jobPlan.baseName );
            var outPath = asmdSafeOutputPath( outDir + "/" + fileName, srcPath, opts.overwrite );

            var job = { preset: p, crop: crop, outPath: outPath, opts: opts,
                        srcWindow: jobPlan.window || this.srcWindow };
            try
            {
               var res = asmdExportOne( job, function( msg )
               {
                  console.writeln( "   " + msg );
                  self.setStatus( head + ": " + msg );
               } );
               results.push( res );
               console.writeln( "   <b>Saved</b> <raw>" + res.path + "</raw>" );
               var savedLine = "   " + res.w + " x " + res.h + ", " +
                               (res.detail ? res.detail : asmdSummaryQuality( res.quality )) + ", " +
                               asmdMB( res.bytes/1024 );
               if ( !res.sameSource )
                  savedLine += " (target " + asmdMB( res.maxKB ) + ")";
               console.writeln( savedLine );
               for ( var k = 0; k < res.notes.length; ++k )
                  console.warningln( "   ** " + res.notes[k] );
            }
            catch ( x )
            {
               var msg = (x && x.message) ? x.message : String( x );
               console.criticalln( "   *** Error: " + msg );
               results.push( { name: p.name, ok: false, error: msg, path: outPath } );
               if ( console.abortRequested || /abort/i.test( msg ) )
                  break;
            }
            processEvents();
         }
      }
      finally
      {
         console.abortEnabled = false;
         this.setBusy( false );
      }

      this.printSummary( results, rootDir, ((new Date).getTime() - t0)/1000 );
   };

   dlg.printSummary = function( results, outDir, secs )
   {
      var ok = 0, over = 0, failed = 0;
      console.writeln( "" );
      console.writeln( "<b>" + ASMD_TITLE + " summary</b>" );
      console.writeln( "<raw>" + asmdPad( "Target", 32 ) + asmdPad( "Pixels", 12 ) + asmdPad( "Quality", 9 ) +
                       asmdPad( "Size", 10, true ) + asmdPad( "Limit", 10, true ) + "  Status  File</raw>" );
      for ( var i = 0; i < results.length; ++i )
      {
         var r = results[i];
         if ( !r.ok )
         {
            ++failed;
            console.writeln( "<raw>" + asmdPad( r.name, 32 ) + asmdPad( "-", 12 ) + asmdPad( "-", 9 ) +
                             asmdPad( "-", 10, true ) + asmdPad( "-", 10, true ) + "  ERROR   " + r.error + "</raw>" );
            continue;
         }
         if ( r.fits ) ++ok; else ++over;
         console.writeln( "<raw>" + asmdPad( r.name, 32 ) + asmdPad( r.w + "x" + r.h, 12 ) +
                          asmdPad( String( r.quality ), 9 ) + asmdPad( asmdMB( r.bytes/1024 ), 10, true ) +
                          asmdPad( asmdMB( r.maxKB ), 10, true ) + "  " + (r.fits ? "OK    " : "OVER  ") + "  " +
                          File.extractNameAndExtension( r.path ) + "</raw>" );
      }
      console.writeln( "<raw>Folder: " + outDir + "</raw>" );
      console.writeln( "Done in " + secs.toFixed( 1 ) + " s: " + ok + " OK, " + over + " over target, " + failed + " failed." );

      var text = "Exported " + (ok + over) + " of " + results.length + " file(s) to:\n" + outDir;
      if ( over > 0 )
         text += "\n\n" + over + " file(s) are over the target. See the Process Console for the size and quality that were saved.";
      if ( failed > 0 )
         text += "\n\n" + failed + " target(s) failed. See the Process Console for details.";
      this.setStatus( "Done: " + ok + " OK, " + over + " over target, " + failed + " failed." );
      asmdMessage( text, (failed > 0 || over > 0) ? StdIcon_Warning : StdIcon_Information );
   };
}

// ============================================================================
// Carousel behavior
// ============================================================================

function asmdAttachCarouselBehavior( dlg )
{
   dlg.carFilling = false;
   dlg.carFillingShapes = false;

   dlg.carPlatformSpec = function()
   {
      return asmdCarouselPlatform( this.carPlatform_Combo.currentItem );
   };

   // Recompute sizer sizes after a platform, shape, or layout change.
   // Never lock the main dialog with setFixedSize. Grow the window up
   // to the screen cap if the settings need more height; do not shrink
   // below the current size (a manual resize is kept).
   dlg.carRelayout = function()
   {
      try
      {
         if ( this.carousel_Group && this.carousel_Group.adjustToContents )
            this.carousel_Group.adjustToContents();
      }
      catch ( x ) {}
      if ( ("_asmdReady" in this) && this._asmdReady )
         asmdFitDialogSize( this, false );
      else if ( this.updateSettingsScroll )
         this.updateSettingsScroll();
   };

   dlg.carShapeIndex = function()
   {
      var spec = this.carPlatformSpec();
      var i = this.carShape_Combo.currentItem;
      if ( i >= 0 && i < spec.shapes.length )
         return spec.shapes[i];
      return spec.defaultShape;
   };

   dlg.carFillShapeCombo = function( preferIndex )
   {
      var spec = this.carPlatformSpec();
      var want = (preferIndex >= 0) ? preferIndex : spec.defaultShape;
      if ( !asmdCarouselPlatformAllowsShape( this.carPlatform_Combo.currentItem, want ) )
         want = spec.defaultShape;
      this.carFillingShapes = true;
      try
      {
         if ( this.carShape_Combo.clear )
            this.carShape_Combo.clear();
         var sel = 0;
         for ( var i = 0; i < spec.shapes.length; ++i )
         {
            this.carShape_Combo.addItem( ASMD_CAROUSEL_SHAPES[spec.shapes[i]].name );
            if ( spec.shapes[i] == want )
               sel = i;
         }
         this.carShape_Combo.currentItem = sel;
      }
      finally
      {
         this.carFillingShapes = false;
      }
      this.carCustom_Control.enabled = (this.carShapeIndex() == ASMD_CAROUSEL_SHAPES.length - 1);
   };

   dlg.carApplyPlatform = function( fromUser )
   {
      var spec = this.carPlatformSpec();
      var want;
      if ( fromUser )
      {
         want = spec.defaultShape;
         this.carMaxMB_Edit.setValue( spec.maxKB/1000 );
      }
      else
         want = this.opts.carShape;
      this.carFillShapeCombo( want );
      var maxP = Math.min( ASMD_CAROUSEL_MAX_PANELS, this.carMaxSlides() );
      this.carPanels_Spin.setRange( ASMD_CAROUSEL_MIN_PANELS, Math.max( ASMD_CAROUSEL_MIN_PANELS, maxP ) );
      if ( this.carPanels_Spin.value > maxP )
      {
         this.carPanels_Spin.value = maxP;
         this.carPanelsChanged( maxP );
      }
      this.carNote_Label.text = spec.shortNote ? spec.shortNote : spec.note;
      this.carNote_Label.toolTip = "<p>" + spec.note + "</p>";
      if ( this.mode == 1 && this.carItems.length > 0 )
      {
         if ( asmdCarouselCount( this.carItems ) > this.carMaxSlides() )
            asmdMessage( "This platform allows at most " + this.carMaxSlides() + " slides. Remove some slides " +
                         "or use a smaller panorama or grid before exporting.", StdIcon_Warning );
         this.carFillTree( this.carSel );
      }
      else
         this.carUpdateExample();
      this.carRelayout();
   };

   dlg.carSlideSize = function()
   {
      var idx = this.carShapeIndex();
      var z = asmdCarouselShape( idx, this.carW_Spin.value, this.carH_Spin.value );
      var spec = this.carPlatformSpec();
      if ( spec.forceWidth > 0 && idx != ASMD_CAROUSEL_SHAPES.length - 1 )
      {
         var h = Math.max( 16, Math.round( spec.forceWidth*z.h/z.w ) );
         z = { w: spec.forceWidth, h: h };
      }
      return z;
   };

   dlg.carMaxSlides = function()
   {
      return asmdCarouselMaxSlides( this.carPlatform_Combo.currentItem );
   };

   dlg.carPanoIndex = function()
   {
      for ( var i = 0; i < this.carItems.length; ++i )
         if ( this.carItems[i].type == "pano" )
            return i;
      return -1;
   };

   // Index of the single panorama or grid item, or -1 if none.
   dlg.carLayoutIndex = function()
   {
      for ( var i = 0; i < this.carItems.length; ++i )
         if ( asmdCarouselIsLayout( this.carItems[i] ) )
            return i;
      return -1;
   };

   dlg.carLayoutSpec = function()
   {
      var i = this.carLayout_Combo.currentItem;
      if ( i < 0 || i >= ASMD_CAROUSEL_LAYOUTS.length )
         i = 0;
      return ASMD_CAROUSEL_LAYOUTS[i];
   };

   dlg.carMakeLayoutItem = function()
   {
      var spec = this.carLayoutSpec();
      if ( spec.type == "pano" )
         return { type: "pano", n: this.carPanels_Spin.value, crop: null };
      return { type: "grid", cols: spec.cols, rows: spec.rows, crop: null };
   };

   dlg.carSyncLayoutControls = function()
   {
      var spec = this.carLayoutSpec();
      this.carPanels_Spin.enabled = (spec.type == "pano");
      this.carAddLayout_Button.text = (spec.type == "pano") ? "Add panorama"
         : ("Add " + spec.cols + "x" + spec.rows + " grid");
      this.carAddLayout_Button.enabled = this.carLayoutIndex() < 0;
   };

   dlg.carItemImage = function( item )
   {
      return (item.type == "other") ? item.window.mainView.image : this.srcWindow.mainView.image;
   };

   dlg.carItemAspect = function( item )
   {
      var z = this.carSlideSize();
      if ( item.type == "pano" )
         return asmdPanoramaGeometry( item.n, z.w, z.h ).aspect;
      if ( item.type == "grid" )
         return asmdGridGeometry( item.cols, item.rows, z.w, z.h ).aspect;
      return z.w/z.h;
   };

   // Crop of an item, created on first use. Panorama and grid boxes jump to
   // the largest fit (same center) when their aspect changes. Detail and
   // other-image boxes keep their size as much as the new aspect allows.
   // Fitted whole-image slides have no crop.
   dlg.carEnsureCrop = function( item )
   {
      if ( item.type == "other" && item.fit )
         return null;
      var image = this.carItemImage( item );
      var W = image.width, H = image.height;
      var aspect = this.carItemAspect( item );
      if ( !item.crop )
         item.crop = (item.type == "detail") ? asmdDefaultDetailCrop( W, H, aspect )
                                             : asmdDefaultCrop( W, H, aspect );
      else if ( Math.abs( item.crop.w/item.crop.h - aspect ) > 1e-6 )
      {
         if ( asmdCarouselIsLayout( item ) )
            asmdMaxFitCrop( item.crop, W, H, aspect );
         else
            asmdRefitCrop( item.crop, W, H, aspect );
      }
      return item.crop;
   };

   dlg.carBitmapFor = function( item )
   {
      if ( item.type != "other" )
         return this.mainBitmap;
      var id = item.window.mainView.id;
      if ( !this.carBitmaps[id] )
         this.carBitmaps[id] = asmdRenderPreviewBitmap( item.window.mainView.image );
      return this.carBitmaps[id];
   };

   dlg.carTypeText = function( item )
   {
      if ( item.type == "pano" )
         return "Panorama, " + item.n + " slides";
      if ( item.type == "grid" )
         return item.cols + "x" + item.rows + " grid, " + (item.cols*item.rows) + " slides";
      if ( item.type == "detail" )
         return "Detail";
      return item.fit ? "Other image, whole" : "Other image, cropped";
   };

   dlg.carSourceText = function( item )
   {
      return (item.type == "other") ? item.window.mainView.id : this.srcWindow.mainView.id;
   };

   dlg.carFillTree = function( selIndex )
   {
      this.carFilling = true;
      try
      {
         this.car_Tree.clear();
         var selNode = null;
         for ( var i = 0; i < this.carItems.length; ++i )
         {
            var it = this.carItems[i];
            var n = new TreeBoxNode( this.car_Tree );
            n.setText( 0, asmdCarouselItemRange( this.carItems, i ) );
            n.setText( 1, this.carTypeText( it ) );
            n.setText( 2, this.carSourceText( it ) );
            n.slideIndex = i;
            if ( i == selIndex )
               selNode = n;
         }
         for ( var c = 0; c < 3; ++c )
            this.car_Tree.adjustColumnWidthToContents( c );
         if ( selNode )
            this.car_Tree.currentNode = selNode;
      }
      finally
      {
         this.carFilling = false;
      }
      var z = this.carSlideSize();
      this.carTotal_Label.text = "Total: " + asmdCarouselCount( this.carItems ) + " of " + this.carMaxSlides() +
                                 " slides, each " + z.w + " x " + z.h + ".";
      this.carSyncLayoutControls();
      this.carSelect( (selIndex >= 0 && selIndex < this.carItems.length) ? selIndex : -1 );
      this.carUpdateExample();
   };

   // Shows a carousel item in the preview (index -1 clears it).
   // Detail (and cropped other-image) boxes that share the previewed image.
   dlg.carPeerCrops = function( item, selIndex )
   {
      var out = [];
      if ( !item || (item.type == "other" && item.fit) )
         return out;
      var srcOther = (item.type == "other");
      for ( var i = 0; i < this.carItems.length; ++i )
      {
         var it = this.carItems[i];
         if ( it.type == "detail" && !srcOther )
         {
            var c = this.carEnsureCrop( it );
            if ( c )
               out.push( { crop: c, number: asmdCarouselItemFirst( this.carItems, i ),
                           selected: (i == selIndex) } );
         }
         else if ( it.type == "other" && !it.fit && srcOther && it.window === item.window )
         {
            var oc = this.carEnsureCrop( it );
            if ( oc )
               out.push( { crop: oc, number: asmdCarouselItemFirst( this.carItems, i ),
                           selected: (i == selIndex) } );
         }
      }
      return out;
   };

   dlg.carSelect = function( index )
   {
      if ( this.mode != 1 )
         return;
      this.carSel = index;
      if ( index < 0 || index >= this.carItems.length )
      {
         this.carSel = -1;
         this.preview.setImage( this.imgW, this.imgH, this.mainBitmap );
         this.preview.setTarget( null, 1, "", 0 );
         this.cropInfo_Label.text = "Add a panorama, a grid, a detail, or another image to the slide list.";
         this.updateUpscaleHint();
         return;
      }
      var it = this.carItems[index];
      var image = this.carItemImage( it );
      this.preview.setImage( image.width, image.height, this.carBitmapFor( it ) );
      var z = this.carSlideSize();
      var crop = this.carEnsureCrop( it );
      var label = asmdCarouselItemRange( this.carItems, index ) + "  " + this.carTypeText( it );
      var cols = 0, rows = 0;
      if ( it.type == "pano" )
      {
         label += "  " + (it.n*z.w) + " x " + z.h;
         cols = it.n; rows = 1;
      }
      else if ( it.type == "grid" )
      {
         label += "  " + (it.cols*z.w) + " x " + (it.rows*z.h);
         cols = it.cols; rows = it.rows;
      }
      else
         label += "  " + z.w + " x " + z.h;
      this.preview.setTarget( crop, this.carItemAspect( it ), label, cols, rows );
      if ( asmdCarouselIsLayout( it ) )
      {
         var layoutIndex = asmdCarouselLayoutIndexOf( it );
         if ( this.carLayout_Combo.currentItem != layoutIndex )
            this.carLayout_Combo.currentItem = layoutIndex;
         this.carPanels_Spin.enabled = (it.type == "pano");
         if ( it.type == "pano" && this.carPanels_Spin.value != it.n )
            this.carPanels_Spin.value = it.n;
      }
      this.preview.setPeers( this.carPeerCrops( it, index ) );
      this.carUpdateCropInfo();
   };

   dlg.carUpdateCropInfo = function()
   {
      if ( this.carSel < 0 || this.carSel >= this.carItems.length )
         return;
      var it = this.carItems[this.carSel];
      var z = this.carSlideSize();
      if ( it.type == "other" && it.fit )
      {
         var im = this.carItemImage( it );
         this.cropInfo_Label.text = "Whole image " + im.width + " x " + im.height +
                                    " fitted inside " + z.w + " x " + z.h + " with black bars.";
         this.updateUpscaleHint();
         return;
      }
      var image = this.carItemImage( it );
      var r = asmdCropRect( it.crop, image.width, image.height );
      var outW, desc;
      if ( it.type == "pano" )
      {
         outW = it.n*z.w;
         desc = it.n + " slides of " + z.w + " x " + z.h;
      }
      else if ( it.type == "grid" )
      {
         outW = it.cols*z.w;
         desc = it.cols + "x" + it.rows + " tiles of " + z.w + " x " + z.h;
      }
      else
      {
         outW = z.w;
         desc = z.w + " x " + z.h;
      }
      var s = outW/r.width;
      var t = "Crop " + r.width + " x " + r.height + " at (" + r.x0 + ", " + r.y0 + ")  >  " +
              desc + "  (scale " + s.toFixed( 3 ) + ")";
      if ( s > 2.0001 )
         t += "   Warning: enlarged more than 2x, it may look soft.";
      else if ( s > 1.0001 )
         t += "   Note: the crop will be enlarged.";
      var overlap = asmdCropOverlapText( asmdCropOverlapPairs( this.carPeerCrops( it, this.carSel ) ) );
      if ( overlap.length > 0 )
         t += "   Warning: " + overlap + " Overlap is allowed.";
      this.cropInfo_Label.text = t;
      this.updateUpscaleHint();
   };

   dlg.carCanAdd = function( slides )
   {
      var max = this.carMaxSlides();
      if ( asmdCarouselCount( this.carItems ) + slides > max )
      {
         asmdMessage( "This platform allows at most " + max + " slides. Remove a slide or use a smaller panorama or grid.",
                      StdIcon_Warning );
         return false;
      }
      return true;
   };

   dlg.carAddLayout = function()
   {
      if ( this.carLayoutIndex() >= 0 )
         return;
      var item = this.carMakeLayoutItem();
      if ( !this.carCanAdd( asmdCarouselItemSlides( item ) ) )
         return;
      this.carItems.unshift( item );
      this.carFillTree( 0 );
   };

   dlg.carAddPano = function()
   {
      this.carAddLayout();
   };

   dlg.carAddDetail = function()
   {
      if ( !this.carCanAdd( 1 ) )
         return;
      this.carItems.push( { type: "detail", crop: null } );
      this.carFillTree( this.carItems.length - 1 );
   };

   dlg.carAddOther = function()
   {
      var k = this.carOther_Combo.currentItem;
      if ( k < 0 || k >= this.carOtherWindows.length )
         return;
      if ( !this.carCanAdd( 1 ) )
         return;
      this.carItems.push( { type: "other", window: this.carOtherWindows[k], fit: this.carFit_Check.checked, crop: null } );
      this.carFillTree( this.carItems.length - 1 );
   };

   dlg.carMove = function( d )
   {
      var i = this.carSel, j = i + d;
      if ( i < 0 || j < 0 || j >= this.carItems.length )
         return;
      var t = this.carItems[i];
      this.carItems[i] = this.carItems[j];
      this.carItems[j] = t;
      this.carFillTree( j );
   };

   dlg.carRemove = function()
   {
      var i = this.carSel;
      if ( i < 0 || i >= this.carItems.length )
         return;
      this.carItems.splice( i, 1 );
      this.carFillTree( Math.min( i, this.carItems.length - 1 ) );
   };

   dlg.carPanelsChanged = function( n )
   {
      var pi = this.carPanoIndex();
      if ( pi < 0 )
         return;
      var it = this.carItems[pi];
      if ( n == it.n )
         return;
      var total = asmdCarouselCount( this.carItems ) - it.n + n;
      if ( total > this.carMaxSlides() )
      {
         this.carPanels_Spin.value = it.n;
         asmdMessage( "That would make " + total + " slides. A carousel can have at most " +
                      this.carMaxSlides() + ".", StdIcon_Warning );
         return;
      }
      it.n = n;
      // carEnsureCrop max-fits the box to the new aspect, same center.
      this.carFillTree( pi );
   };

   dlg.carLayoutChanged = function()
   {
      this.carSyncLayoutControls();
      var li = this.carLayoutIndex();
      if ( li < 0 )
         return;
      var it = this.carItems[li];
      var spec = this.carLayoutSpec();
      if ( it.type == spec.type && (spec.type == "pano" || (it.cols == spec.cols && it.rows == spec.rows)) )
         return;
      var n = (spec.type == "pano") ? this.carPanels_Spin.value : (spec.cols*spec.rows);
      var total = asmdCarouselCount( this.carItems ) - asmdCarouselItemSlides( it ) + n;
      if ( total > this.carMaxSlides() )
      {
         this.carLayout_Combo.currentItem = asmdCarouselLayoutIndexOf( it );
         this.carSyncLayoutControls();
         asmdMessage( "That would make " + total + " slides. A carousel can have at most " +
                      this.carMaxSlides() + ".", StdIcon_Warning );
         return;
      }
      if ( spec.type == "pano" )
      {
         it.type = "pano";
         it.n = this.carPanels_Spin.value;
         it.cols = undefined;
         it.rows = undefined;
      }
      else
      {
         it.type = "grid";
         it.cols = spec.cols;
         it.rows = spec.rows;
         it.n = undefined;
      }
      var image = this.carItemImage( it );
      if ( it.crop )
         asmdMaxFitCrop( it.crop, image.width, image.height, this.carItemAspect( it ) );
      this.carFillTree( li );
      this.carRelayout();
   };

   dlg.carShapeChanged = function()
   {
      if ( this.carFillingShapes )
         return;
      this.carCustom_Control.enabled = (this.carShapeIndex() == ASMD_CAROUSEL_SHAPES.length - 1);
      if ( this.carItems.length > 0 && asmdCarouselCount( this.carItems ) > this.carMaxSlides() )
         asmdMessage( "This platform allows at most " + this.carMaxSlides() + " slides. Remove some slides " +
                      "or use a smaller panorama or grid before exporting.", StdIcon_Warning );
      if ( this.mode == 1 )
         this.carFillTree( this.carSel );
      else
         this.carUpdateExample();
      this.carRelayout();
   };

   dlg.carTokens = function( number, total, w, h, date, time, kb, type )
   {
      return {
         name:     asmdSafeFileToken( this.baseName_Edit.text ),
         platform: this.carPlatformSpec().token,
         preset:   "Carousel",
         w:        w,
         h:        h,
         date:     date,
         time:     time,
         kb:       kb,
         slide:    asmdTwo( number ),
         count:    total,
         type:     type
      };
   };

   dlg.carUpdateExample = function()
   {
      var z = this.carSlideSize();
      var total = Math.max( 1, asmdCarouselCount( this.carItems ) );
      this.carExample_Label.text = asmdBuildFileName( asmdCarouselTemplate( this.carTemplate_Edit.text ),
         this.carTokens( 1, total, z.w, z.h, asmdDateString(), asmdTimeString(),
                         Math.round( this.carMaxMB_Edit.value*1000 ), "Panorama" ), "JPEG" );
   };

   dlg.showMode = function( mode )
   {
      var car = (mode == 1);
      if ( car && this.mode != 1 )
      {
         this.syncPresetChecksFromTree();
         asmdSavePresets( this.presets );
      }
      this.treeSyncing = true;
      this.mode = car ? 1 : 0;
      this.targets_Group.visible = !car;
      if ( this.images_Group )
         this.images_Group.visible = !car;
      this.carousel_Group.visible = car;
      this.sameCenter_Button.enabled = !car;
      this.carCustom_Control.enabled = (this.carShapeIndex() == ASMD_CAROUSEL_SHAPES.length - 1);
      this.treeSyncing = false;
      if ( this.template_Control )
         this.template_Control.visible = !car;
      if ( this.example_Control )
         this.example_Control.visible = !car;
      if ( car )
      {
         if ( this.carItems.length == 0 )
            this.carItems.push( this.carMakeLayoutItem() );
         this.carFillTree( (this.carSel >= 0) ? this.carSel : 0 );
      }
      else
      {
         this.fillTree( this.currentId );
         if ( this.selectBatchImage )
            this.selectBatchImage( this.activeImageId || this.srcWindow.mainView.id );
         else
            this.preview.setImage( this.imgW, this.imgH, this.mainBitmap );
      }
      this.carRelayout();
      if ( this.updateExportModeControls )
         this.updateExportModeControls();
   };

   // ---- Carousel export ----------------------------------------------------

   dlg.runCarouselExport = function()
   {
      if ( !asmdIsLicensed() )
      {
         asmdMessage( "Carousel export requires a license. You can still preview the slides here. " +
                      "Enter a license key to export.", StdIcon_Information );
         return;
      }
      this.collectOptions();
      var opts = this.opts;
      var items = this.carItems;
      var total = asmdCarouselCount( items );
      var z = this.carSlideSize();
      var maxKB = opts.carMaxKB;

      if ( total == 0 )
      {
         asmdMessage( "Add at least one slide to the carousel.", StdIcon_Warning );
         return;
      }
      if ( total > this.carMaxSlides() )
      {
         asmdMessage( "The carousel has " + total + " slides. The limit for this shape is " +
                      this.carMaxSlides() + ".", StdIcon_Warning );
         return;
      }
      if ( asmdTrim( this.baseName_Edit.text ).length == 0 )
      {
         asmdMessage( "Please enter a base name.", StdIcon_Warning );
         return;
      }
      var wmChoice = opts.carWatermark;
      var wmActive = opts.wmEnabled && wmChoice != 0;
      if ( wmActive && opts.wmMode == 1 && !File.exists( opts.wmLogoPath ) )
      {
         asmdMessage( "The watermark logo file was not found:\n" + opts.wmLogoPath, StdIcon_Warning );
         return;
      }
      for ( var vi = 0; vi < items.length; ++vi )
         if ( items[vi].type == "other" && (!items[vi].window || items[vi].window.isNull) )
         {
            asmdMessage( "Slide image " + (vi + 1) + " is no longer open. Remove it and try again.", StdIcon_Warning );
            return;
         }

      var outDir = asmdCleanDir( this.outDir_Edit.text );
      if ( outDir.length == 0 )
      {
         asmdMessage( "Please choose an output folder.", StdIcon_Warning );
         return;
      }
      if ( opts.subfolderPerImage )
         outDir += "/" + asmdSafeFileToken( this.baseName_Edit.text );
      try
      {
         if ( !File.directoryExists( outDir ) )
            File.createDirectory( outDir, true );
      }
      catch ( x )
      {
         asmdMessage( "Could not create the output folder:\n" + outDir + "\n\n" + x.message, StdIcon_Error );
         return;
      }

      this.opts.save();
      asmdSavePresets( this.presets );

      var template = asmdCarouselTemplate( opts.carTemplate );
      var date = asmdDateString(), time = asmdTimeString();   // same for every slide

      this.setBusy( true );
      console.show();
      console.abortEnabled = true;
      console.writeln( "" );
      console.writeln( "<b>" + ASMD_TITLE + " " + ASMD_VERSION + ": Carousel</b>" );
      console.writeln( "Source: " + this.srcWindow.mainView.id + " (" + this.imgW + " x " + this.imgH + ")" );
      this.lastOutDir = outDir;
      console.writeln( "Output folder: " + outDir );
      console.writeln( "Slides: " + total + " at " + z.w + " x " + z.h + ", up to " + asmdMB( maxKB ) +
                       " each. Watermark: " + (wmActive ? ASMD_CAROUSEL_WATERMARKS[wmChoice] :
                       (wmChoice != 0 ? "off (Watermark / signature is unchecked)" : "none")) + "." );

      var results = [];
      var t0 = (new Date).getTime();
      var self = this;
      var number = 0, aborted = false;

      function slideJob( srcWin, crop, sharpen, name, type )
      {
         ++number;
         var head = "[" + number + "/" + total + "] " + name;
         console.writeln( "" );
         console.writeln( "<b>" + head + "</b>" );
         self.setStatus( head + "..." );
         var o = asmdCloneOpts( opts );
         o.noUpscale = false;   // carousel slides always match the shared size
         o.fullFrameFit = false;
         o.logoOnly = false;
         o.wmEnabled = wmActive && asmdCarouselWatermarkOn( wmChoice, number, total );
         var preset = { name: name, platform: self.carPlatformSpec().token, width: z.w, height: z.h, maxKB: maxKB,
                        format: "JPEG", sharpen: sharpen };
         var fileName = asmdBuildFileName( template,
                           self.carTokens( number, total, z.w, z.h, date, time, maxKB, type ), "JPEG" );
         var carSrc = "";
         try
         {
            if ( self.srcWindow && ("filePath" in self.srcWindow) && self.srcWindow.filePath )
               carSrc = self.srcWindow.filePath;
         }
         catch ( eCar ) {}
         var outPath = asmdSafeOutputPath( outDir + "/" + fileName, carSrc, opts.overwrite );
         try
         {
            var res = asmdExportOne( { preset: preset, crop: crop, outPath: outPath, opts: o,
                                       srcWindow: srcWin, carouselSlide: true },
               function( msg )
               {
                  console.writeln( "   " + msg );
                  self.setStatus( head + ": " + msg );
               } );
            results.push( res );
            console.writeln( "   <b>Saved</b> <raw>" + res.path + "</raw>" );
            console.writeln( "   " + res.w + " x " + res.h + ", quality " + res.quality + ", " +
                             asmdMB( res.bytes/1024 ) + " (target " + asmdMB( res.maxKB ) + ")" +
                             (o.wmEnabled ? ", watermarked" : "") );
            for ( var k = 0; k < res.notes.length; ++k )
               console.warningln( "   ** " + res.notes[k] );
         }
         catch ( x )
         {
            var msg = (x && x.message) ? x.message : String( x );
            console.criticalln( "   *** Error: " + msg );
            results.push( { name: name, ok: false, error: msg, path: outPath } );
            if ( console.abortRequested || /abort/i.test( msg ) )
               aborted = true;
         }
         processEvents();
      }

      function failItem( item, msg )
      {
         for ( var j = 0; j < asmdCarouselItemSlides( item ); ++j )
         {
            ++number;
            results.push( { name: asmdTwo( number ) + " " + self.carTypeText( item ), ok: false, error: msg, path: "" } );
         }
      }

      try
      {
         for ( var i = 0; i < items.length && !aborted; ++i )
         {
            var it = items[i];
            if ( asmdCarouselIsLayout( it ) )
            {
               var strip = null;
               var isPano = (it.type == "pano");
               var cols = isPano ? it.n : it.cols;
               var rows = isPano ? 1 : it.rows;
               var tileCount = cols*rows;
               var kind = isPano ? "panorama" : "grid";
               var heading = isPano ? ("Panorama: " + it.n + " slides from one strip")
                                    : (it.cols + "x" + it.rows + " grid: " + tileCount + " tiles from one crop");
               try
               {
                  this.carEnsureCrop( it );
                  console.writeln( "" );
                  console.writeln( "<b>" + heading + "</b>" );
                  strip = asmdMakeGridStrip( this.srcWindow, it.crop, cols, rows, z.w, z.h, opts, function( msg )
                  {
                     console.writeln( "   " + msg );
                     self.setStatus( (isPano ? "Panorama" : (it.cols + "x" + it.rows + " grid")) + ": " + msg );
                  }, kind );
                  if ( strip.scale > 2.0001 )
                     console.warningln( "   ** The " + kind + " crop is enlarged " + strip.scale.toFixed( 2 ) +
                                        "x, so the slides may look soft." );
                  var tiles = strip.geo.tiles;
                  for ( var p = 0; p < tiles.length && !aborted; ++p )
                  {
                     var pn = tiles[p];
                     var tname = isPano ? (asmdTwo( number + 1 ) + " Panorama " + (p + 1) + " of " + it.n)
                                        : (asmdTwo( number + 1 ) + " " + it.cols + "x" + it.rows +
                                           " grid " + (p + 1) + " of " + tileCount);
                     slideJob( strip.window, { x: pn.x, y: pn.y, w: pn.w, h: pn.h }, false,
                               tname, isPano ? "Panorama" : "Grid" );
                  }
               }
               catch ( x )
               {
                  var m = (x && x.message) ? x.message : String( x );
                  console.criticalln( "   *** Error: " + m );
                  failItem( it, m );
                  if ( console.abortRequested || /abort/i.test( m ) )
                     aborted = true;
               }
               finally
               {
                  if ( strip )
                     asmdClose( strip.window );
               }
            }
            else if ( it.type == "detail" )
            {
               var c = this.carEnsureCrop( it );
               var r = asmdCropRect( c, this.imgW, this.imgH );
               if ( z.w/r.width > 2.0001 )
                  console.warningln( "** Slide " + asmdTwo( number + 1 ) + ": the detail crop is enlarged " +
                                     (z.w/r.width).toFixed( 2 ) + "x, so it may look soft." );
               slideJob( this.srcWindow, c, true, asmdTwo( number + 1 ) + " Detail", "Detail" );
            }
            else
            {
               var label = asmdTwo( number + 1 ) + " " + it.window.mainView.id;
               var type = asmdSafeFileToken( it.window.mainView.id );
               if ( it.fit )
               {
                  var pad = null;
                  try
                  {
                     pad = asmdMakePaddedWindow( it.window, z.w/z.h );
                     var pim = pad.mainView.image;
                     slideJob( pad, { x: 0, y: 0, w: pim.width, h: pim.height }, true, label, type );
                  }
                  catch ( x2 )
                  {
                     var m2 = (x2 && x2.message) ? x2.message : String( x2 );
                     console.criticalln( "   *** Error: " + m2 );
                     failItem( it, m2 );
                  }
                  finally
                  {
                     asmdClose( pad );
                  }
               }
               else
               {
                  var oc = this.carEnsureCrop( it );
                  var oim = it.window.mainView.image;
                  var orr = asmdCropRect( oc, oim.width, oim.height );
                  if ( z.w/orr.width > 2.0001 )
                     console.warningln( "** Slide " + asmdTwo( number + 1 ) + ": the crop is enlarged " +
                                        (z.w/orr.width).toFixed( 2 ) + "x, so it may look soft." );
                  slideJob( it.window, oc, true, label, type );
               }
            }
         }
      }
      finally
      {
         console.abortEnabled = false;
         this.setBusy( false );
      }

      this.printSummary( results, outDir, ((new Date).getTime() - t0)/1000 );
   };
}

// ============================================================================
// Entry point
// ============================================================================

function asmdMain()
{
   console.writeln( "<b>" + ASMD_TITLE + " " + ASMD_VERSION +
                    "</b>  Copyright (c) 2026 Astrophotography MD LLC. All rights reserved." );

   var window = ImageWindow.activeWindow;
   if ( window == null || window.isNull )
   {
      asmdMessage( "Open your finished, stretched image first, then run " + ASMD_TITLE + ".", StdIcon_Error );
      return;
   }
   var img = window.mainView.image;
   if ( img.width < 16 || img.height < 16 )
   {
      asmdMessage( "The active image is too small to export.", StdIcon_Error );
      return;
   }

   // Gentle check for unstretched data: a linear image renders nearly black.
   try
   {
      if ( img.median() < 0.02 )
         if ( !asmdConfirm( "This image looks linear (very dark, median below 0.02).\n\n" +
                            ASMD_TITLE + " expects a finished, stretched image. Continue anyway?" ) )
            return;
   }
   catch ( x ) {}

   var dialog = new AsmdSocialExportDialog( window );
   dialog.execute();
}

asmdMain();
