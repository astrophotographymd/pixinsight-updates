# AstroMD Social Export: Test Checklist

Version 1.5.6. This version fixes a crash on open in PixInsight 1.9.6 (`Illegal call to Control.setSizer`). The 1.5.5 layout stays: the settings column follows its scroll viewport, notes wrap, the tables fit, labels line up, and the divider between the preview and that column can be dragged and is remembered. Export behavior is unchanged. Updates still download through Astrophotography MD's download server, which started in 1.5.4, so the export checks below are the same as in 1.5.3. Sections 1 to 12 cover single exports, which already work in PixInsight. Section 6 covers JPEG quality (start at 90 to 100, drop to 75, resize only as a last resort). Section 13 covers Carousel mode, including the 1.2.1 layout fix when switching Platform. Section 14 covers the free and licensed split added in 1.2.0. Section 15 covers the window size, scrolling, and collapsible sections, including mouse wheel scrolling of the settings column in 1.5.2 and the section arrows plus scrollbar clearance in 1.5.3. Section 16 covers the Images list and batch export in Single exports. Section 17 covers the export mode selector at the top of the window (social, full frame, and add logo only), including Same as source in 1.5.1. Section 18 covers saved jobs. Version 1.1.5 fixed a Process Console warning (162, undefined property info.hasAlpha) when a logo was selected. When something goes wrong, stop at that step and send back what's listed in "What to send back" at the end.

Before you start, write down:

* PixInsight version (shown on the first lines of the Process Console, or in Help > About PixInsight)
* Operating system (for example Windows 11 or macOS 15)
* Screen scaling, if you use any (for example Windows display scaling at 150%)

Use a copy of a finished image, for example the Fish Head or Lobster Claw master, saved as XISF or TIFF.

## 1. Install

- [ ] 1.1 Copy the `AstroMD-SocialExport` folder to your laptop.
- [ ] 1.2 In PixInsight: **Script > Feature Scripts... > Add**, choose the folder, then **Done**.
- [ ] 1.3 **Script > Astrophotography MD > Social Export** appears in the menu.

If the menu entry does not appear, run it with **Script > Execute Script File...** instead and note that the menu step failed.

## 2. Opening

- [ ] 2.1 With no image open, run the script. You get a message asking you to open an image, and nothing else happens.
- [ ] 2.2 Open your finished image and click on it so it is the active window. Run the script.
- [ ] 2.3 The dialog opens without errors and shows your image in the preview, with an orange crop box.
- [ ] 2.4 The title line shows the image name and its pixel size.
- [ ] 2.5 In Single exports, an **Images** list shows every open image. The current image is checked. If you have other images open, they appear in the list (locked with "Unlock with a license" until you enter a key).
- [ ] 2.6 Optional: open a linear (unstretched) image and run the script. You get a "looks linear" warning and can cancel.

## 3. Crop box

Select **Instagram Portrait 4:5** in the Targets list.

- [ ] 3.1 Drag inside the box. It moves smoothly and stops at the image edges.
- [ ] 3.2 Drag each of the four corner handles. The box resizes from the opposite corner and stays 4:5.
- [ ] 3.3 Scroll the mouse wheel over the preview. The box grows and shrinks around its center. Hold Shift for smaller steps.
- [ ] 3.4 Click outside the box. The box jumps so it is centered on that spot.
- [ ] 3.5 The cursor changes over the box (open hand), over a corner (resize arrows), and while dragging (closed hand).
- [ ] 3.6 **Center**, **Max size** and **Reset** each do what they say.
- [ ] 3.7 The line under the preview updates as you move the box (crop size, position, output size, scale).
- [ ] 3.8 Make the box small enough that the crop is under 1080 px wide. With **Don't upscale small crops (recommended)** checked (the new default), a hint under the box names the smaller export size, for example "Your crop is 820 px wide, so this export will be 820 x 1025 instead of 1080 x 1350." Uncheck the box: the hint says the crop will be enlarged, for example "Your crop will be enlarged 1.3x to 1080 x 1350." Click **Max size**: the hint disappears.
- [ ] 3.9 Resize the whole dialog. The preview grows or shrinks and the box stays in the right place on the image.

## 4. Targets

- [ ] 4.1 Select **Instagram Story/Reel 9:16**. The box changes to a tall 9:16 shape.
- [ ] 4.2 Move it somewhere, then select **Instagram Portrait 4:5** again. The 4:5 box is still where you left it.
- [ ] 4.3 Select **Facebook Feed (2048 long edge)**. The box covers the whole image (it uses the image's own shape).
- [ ] 4.4 **Same center for all**: move one box off center, click the button, then click other targets. Their boxes are centered on the same point.
- [ ] 4.5 Check and uncheck a few targets with their checkboxes. **All** and **None** check and uncheck everything.

## 5. First export (the most important test)

Check only **Instagram Portrait 4:5**. Leave every other setting at its default. Click **Export**.

- [ ] 5.1 The Process Console opens and shows the steps: cropping, resampling, converting to sRGB (plus sharpening only if you checked Apply output sharpening), converting to 8-bit, and a line like "quality 95 at 1080 x 1350: N.NN MB". If that file fits, the next line says "Kept 1080 x 1350 at quality 95, ...". The file is exactly 1080 x 1350. Quality is 95 unless you changed the starting quality, and a normal 1.6 MB target should not need to go under 90.
- [ ] 5.2 A summary table appears at the end and a message box says how many files were exported.
- [ ] 5.3 A `Social` folder exists next to your image, containing a file named like `FishHead_Instagram-Portrait_1080x1350_2026-11-15.jpg`.
- [ ] 5.4 Open the JPEG in another program. It is exactly 1080 x 1350 unless the console said quality 75 was still over and the image was resized. The crop matches what you chose, and it looks sharp but not crunchy (no dark rings around stars).
- [ ] 5.5 Its file size is at or under 1.6 MB and matches the size in the summary in the summary (within a few KB; macOS Finder shows slightly bigger numbers).
- [ ] 5.6 Your original image in PixInsight is unchanged: same size, no new history steps, not marked as modified.
- [ ] 5.7 No extra image windows were left open in PixInsight, and no files with `_asmdtmp_` in the name were left in the folder.
- [ ] 5.8 Color check: the JPEG's colors look the same in a web browser as in PixInsight. If you have a tool that shows metadata (Photoshop, Affinity, or the exiftool command), check that it says sRGB is embedded.

## 6. JPEG quality and file size (changed in 1.4.0)

Open **Processing**. **JPEG quality** should read 95. The control does not go below 90 or above 100. That value is the starting quality. Presets can drop from it down to 75.

- [ ] 6.1 **Add...** a custom preset: name "Test 0.8MB", exact pixels 1080 x 1350, max 0.8 MB, JPEG. Check only it and export. Leave JPEG quality at 95.
- [ ] 6.2 The file is still exactly 1080 x 1350. The console shows a quality search and a "Kept 1080 x 1350 at quality NN" line. Quality is under 95 and at least 75. The file is at or under 0.8 MB.
- [ ] 6.3 Edit the preset to 0.05 MB and export again. The console says quality 75 is still over 1080 x 1350, so the image was resized, and it names the new size, quality 75, and the file size. The file is smaller than 1080 x 1350 and the file name matches that size. Quality is 75, not a very low number.
- [ ] 6.4 Set JPEG quality to 100, set the preset back to a size that fits at a high quality (for example 1.6 MB), and export. The search starts at 100. The control will not go below 90. Set JPEG quality back to 95.
- [ ] 6.5 Export Instagram Portrait again with its normal 1.6 MB target. The console says "Kept 1080 x 1350 at quality 95" (or another quality from 75 to 95 if 95 did not fit) and the file is exactly 1080 x 1350.

## 7. All built-in targets

- [ ] 7.1 Click **All** (you can uncheck the custom test presets), and export.
- [ ] 7.2 Every file has the pixel size shown in the Targets list, and the Facebook Feed file has 2048 px on its long side.
- [ ] 7.3 Note the time it took (shown on the "Done in" line).

## 8. Custom presets and settings

- [ ] 8.1 **Add...** a preset with "Aspect ratio + long edge": ratio `3:4`, long edge 1440. The Targets list shows it and the crop box is 3:4.
- [ ] 8.2 **Add...** a PNG preset (for example 1080 x 1080, 3 MB, PNG). Export it. A `.png` file is saved and the summary shows PNG.
- [ ] 8.3 Select a built-in preset and click **Edit...**. You are offered a custom copy instead.
- [ ] 8.4 **Delete** a custom preset. It disappears. Try deleting a built-in: you get a message that it can't be deleted.
- [ ] 8.5 Close the dialog, run the script again. Your custom presets, checked targets, template and other options are all still there.

## 9. Output options

- [ ] 9.1 Change the template to `{name}-{platform}-{date}-{time}` and watch the Example line update. Export and check the file name.
- [ ] 9.2 Export the same target twice without **Overwrite**. The second file gets `_2` added.
- [ ] 9.3 Check **Overwrite existing files** and export again. The file is replaced.
- [ ] 9.4 Check **Subfolder per image**. Files go into a folder named after the base name.
- [ ] 9.5 Change the base name to `Test Name` and export. The file name uses `Test-Name`.
- [ ] 9.6 Use **Browse...** to pick a different folder, and try **Image folder** and **Social subfolder**.

## 10. Processing options

- [ ] 10.1 Set Sharpening to 0 and export. Compare with the default 0.25 export: the 0 version is a little softer.
- [ ] 10.2 Set Sharpening to 1 and export. It should be noticeably sharper but still free of dark rings around stars. Tell me whether 0.25 feels right as the default.
- [ ] 10.3 Try each Resampling choice once on the same target and note any visible difference.
- [ ] 10.4 Leave **Don't upscale small crops (recommended)** checked if it is on, or check it if it is off (if you already closed an earlier version of the script, the old default of off may still be saved). Make a crop smaller than the output and export. The file is smaller than the preset size, the hint under the box names that size, and the console says the output was reduced to avoid enlarging. Then uncheck the box and export again: the file is the exact preset size, and the hint says the crop was enlarged.

## 11. Watermark

- [ ] 11.1 Turn on **Watermark / signature** with the default text. Export. The text appears in the bottom right corner at about 60% opacity.
- [ ] 11.2 Try each position in the dropdown: Top left, Top center, Top right, Left center, Center, Right center, Bottom left, Bottom center, and Bottom right. Top center and Bottom center sit on the top or bottom edge, horizontally centered, with the same margin as the corners. Left center and Right center should be vertically centered. Also try a higher opacity and a bigger size.
- [ ] 11.3 Switch to **Logo image** (this used to say PNG logo; if you already had a logo selected, it should still be selected). Hover the type menu, the path box, or **Browse...** and confirm the tip mentions a transparent PNG at least 1000 px wide, JPEG, BMP, GIF, TIFF, XISF, FITS, and that SVG is not supported. Click **Browse...**: the file window lists Images (png, jpg, jpeg, bmp, gif, tif, tiff, xisf, fits, fit) and All files. Pick a PNG logo with a transparent background (ideally 1000 px wide or more) and export. The logo appears with transparency intact. The Process Console should not show warning 162 about an undefined property.
- [ ] 11.4 Pick a logo path that doesn't exist. Export shows a "not found" message.
- [ ] 11.5 With **Logo image** selected, point the path at a JPEG. A note under the path says JPEG has no transparency and will show as a solid rectangle. Point it at an .svg file: the note says SVG is not supported. If you have a logo under 400 px wide, the note says it may look soft. Switch back to a large transparent PNG, or back to **Text**: the note disappears.

## 12. Upload test (optional but useful)

- [ ] 12.1 Post the Instagram Portrait file to Instagram (or save it as a draft) and compare its sharpness to your usual export.
- [ ] 12.2 Post the Facebook Feed file and compare.

## 13. Carousel (new in 1.1.0, grids and overlap in 1.1.1, platform in 1.1.2, upscale hint in 1.1.3)

Before running the script, open your finished image and, if you have one, a second version of it (for example the starless version). Click the finished image so it is the active window, then run the script.

- [ ] 13.1 The window opens in **Single exports** mode, exactly as in 1.0.9. Do one Instagram Portrait export to confirm nothing changed.
- [ ] 13.2 Check that **TikTok Photo 9:16** is in the Targets list (unchecked), shows 1080 x 1920 and 2.4 MB, and exports a 1080 x 1920 file named with `TikTok`.
- [ ] 13.3 In **Single exports**, check at least two targets, for example Instagram Portrait and TikTok Photo. Click **Carousel**. The Targets list is replaced by the Carousel panel, **Platform** is Instagram, and the slide list has one row: 01-03, Panorama, 3 slides.
- [ ] 13.4 The preview shows a wide box with two cyan cut lines and the numbers 1, 2, 3 along the bottom. Drag, resize, and wheel it. It stays locked to three 4:5 slides side by side.
- [ ] 13.5 Change **Panorama slides** to 5. The box gets wider, shows four cut lines, and the row reads 01-05. Set it back to 3.
- [ ] 13.6 Click **Add detail**. A smaller 4:5 box appears with no cut lines. Move it onto a detail. The row reads 04, Detail.
- [ ] 13.7 Make the detail box very small. The line under the preview warns that it is enlarged more than 2x. The hint under **Don't upscale small crops** also says the crop will be enlarged, and that carousel slides stay at the platform size so they match. The export stays at the platform pixel size. Quality may drop from the starting value down to 75 to meet the size target. A slide is resized only if quality 75 is still over, and the console says so, including that it may not match the other slides.
- [ ] 13.8 Pick your second image in **Other image**, leave **Whole image** unchecked, and click **Add image**. The preview switches to that image with its own crop box. Click the panorama row: the preview switches back.
- [ ] 13.9 Add the second image again with **Whole image** checked. Selecting it shows the image with no crop box, and the line under the preview says it will be fitted with black bars.
- [ ] 13.10 **Move up**, **Move down**, and **Remove** change the list. The slide numbers update. **Select** shows the selected slide's crop.
- [ ] 13.11 Add details until the total reaches 20. The next add shows a "at most 20 slides" message.
- [ ] 13.12 Remove the extra slides. Turn on **Watermark / signature** and set the carousel **Watermark** to **First slide only**. Click **Export**.
- [ ] 13.13 The Process Console shows "resampling the whole strip to 3240 x 1350" once for the panorama, then one section per slide, then the summary table.
- [ ] 13.14 The folder contains `FishHead_Carousel_01_1080x1350_<date>.jpg`, `_02`, and so on in swipe order. Each file is exactly 1080 x 1350 and at or under 1.6 MB, unless the console said quality 75 was still over and that slide was resized. Slides that were not resized match each other. Only slide 01 has the watermark. Quality is from 75 to 95 (or up to 100 if you set the starting quality there).
- [ ] 13.15 Open slides 01, 02, and 03 side by side in an image viewer, or post them as a draft carousel. The nebula continues across the cuts with no gap, jump, or doubled column of pixels.
- [ ] 13.16 The whole-image slide shows your second image complete, with black bars. The detail slide matches the box you drew.
- [ ] 13.17 Try **Every slide** and **Last slide only**. The watermark appears where expected. With **Watermark / signature** unchecked, no slide is watermarked.
- [ ] 13.18 With **Platform** still set to Instagram, switch **Slide shape** to 3:4, 1:1, and Custom. The boxes change shape. 9:16 should not be in the Instagram list.
- [ ] 13.19 **Open folder** opens the carousel's folder.
- [ ] 13.20 No extra image windows are left open, and no `_asmdtmp_` files are left in the folder.
- [ ] 13.21 Close and reopen the script. The mode, platform, slide shape, layout, panorama slide count, watermark choice, max size, and carousel file name template come back. (Detail crops do not, by design.)
- [ ] 13.22 Switch back to **Single exports**. The Targets list, the checkmarks you had before you opened Carousel, and each target's crop are as you left them.

The rest of this section is new in 1.1.1. Switch back to **Carousel** first.

- [ ] 13.23 Set **Panorama slides** to 6. The box becomes a short, wide strip (it has to fit six 4:5 slides side by side on your image). Then set it to 2. The box should grow to the largest 2-panel size that fits, centered where the 6-panel box was, not stay the short 6-panel height. Shrink it with the corner handles or the mouse wheel, then grow it again with **Max size**. Set it back to 3 when you are done.
- [ ] 13.24 Set **Layout** to **2x2 grid**. The crop box becomes a 4:5 rectangle (the same shape as one slide) with one vertical and one horizontal cyan cut line, and the numbers 1, 2, 3, 4 in reading order (top left, top right, bottom left, bottom right). The list row reads 01-04.
- [ ] 13.25 Drag and resize the 2x2 box. It stays locked to 4:5. Click **Export**. The Process Console shows "resampling the whole grid to 2160 x 2700" once, and the folder has four slides of 1080 x 1350, `_01` through `_04`. Open them in a 2x2 or swipe through them: the image continues across the cuts with no gap or doubled pixels.
- [ ] 13.26 Set **Layout** to **3x3 grid**. Even if you had shrunk the 2x2 box, the 3x3 box should jump to the largest 4:5 size that fits, with two rows and two columns of cut lines and numbers 1 to 9. The list row reads 01-09. Export if you want; the strip is 3240 x 4050, cut into nine 1080 x 1350 tiles.
- [ ] 13.27 Add a detail after the grid. The list has the grid row plus the detail, and the total counts the tiles plus 1 (5 of 20 for a 2x2, or 10 of 20 for a 3x3).
- [ ] 13.28 Turn on **Watermark / signature** and leave the carousel **Watermark** on **First slide only**. Export a 2x2. Only tile 1 (top left) has the watermark. If that looks odd, try **Every slide** or **Last slide only**.
- [ ] 13.29 Remove extra slides until you have no details, then click **Add detail** twice. Both boxes start in the same place. The preview shows two boxes: the selected one is the bright orange box, the other is a dim cyan outline with its slide number. The line under the preview warns that the two slides overlap by 100%. Move one box off the other. The orange overlap tint should shrink and then disappear, and the warning should go away. The other box's outline stays visible. Overlap is allowed; you do not have to separate them to export.
- [ ] 13.30 Close and reopen the script. **Layout** (Panorama, 2x2, or 3x3) comes back with the other carousel settings.

The rest of this section is new in 1.1.2.

- [ ] 13.31 In **Single exports**, check a distinctive set of targets (for example only TikTok Photo and Facebook Cover). Switch to **Carousel**, then back to **Single exports**. Those same boxes should still be checked, and the others unchecked.
- [ ] 13.32 In **Carousel**, set **Platform** to **TikTok**. The default shape becomes 9:16 at 1080 x 1920, the max size becomes 2.4 MB, and the total line shows a limit of 35.
- [ ] 13.33 Set **Platform** to **X**. The note says the script stays at 4 slides. Remove extra slides, then try **3x3 grid**: you get a message that 9 slides is over the limit, and the 3x3 is not added. **2x2 grid** is allowed (4 slides).
- [ ] 13.34 Set **Platform** to **Facebook**. The note warns that Facebook shows a collage, not a swipeable carousel, so panorama and grid seams will not line up as a swipe.
- [ ] 13.35 Set **Platform** to **Threads**. The default shape is 3:4, and the size is 1440 x 1920 (1440 px wide). The limit is 20.
- [ ] 13.36 Add `{platform}` to the file name template, for example `{name}_{platform}_{slide}_{w}x{h}_{date}.jpg`. The Example line uses Instagram, TikTok, Facebook, Threads, or X, depending on the platform. Export if you want and check the file names.
- [ ] 13.37 Close and reopen. **Platform** comes back, and the single-export checkmarks from 13.31 are still there.
- [ ] 13.38 In **Carousel**, set **Platform** to **Instagram**, then **X**, then back to **Instagram**, then **TikTok**, then **Facebook**. The platform note should stay the same height (a short 2-3 line summary; hover it for the full text). The slide list should not shrink, and the Add detail / Select / Move up / Move down / Remove row should not overlap the list. The Other image / Whole image / Add image row should stay aligned. The layout should not stay broken after you return to Instagram.
- [ ] 13.39 While still in **Carousel**, the Output section should not show the single-export **Name template** or its **Example** (those belong to Single exports). The Carousel panel's **File names** field and its **Example** should still be visible. Switch back to **Single exports** and confirm **Name template** and **Example** return.

## What to send back

When any step fails or looks wrong, send me:

1. **The step number** (for example "5.4") and what you expected versus what happened.
2. **The Process Console text.** Click in the Process Console, press Ctrl+A (Cmd+A on a Mac) to select everything, then Ctrl+C (Cmd+C) to copy, and paste it into a message or a text file. Error lines are shown in red and usually include a line number in `AstroMD-SocialExport.js`. Those line numbers are what I need most.
3. **A screenshot** of the dialog or the error message, if there is one.
4. Your **PixInsight version**, **operating system**, and any display scaling.
5. For quality problems, the exported file itself.

If PixInsight shows an error before the dialog even opens, the Process Console text is still the most useful thing to send.

## 14. Free version and license key (new in 1.2.0)

Start with no license stored (use **Remove license** if you already entered one).

- [ ] 14.1 The banner says this is the free version. Non-Instagram targets in the list are visible, unchecked, and marked "Unlock with a license." Instagram targets can still be checked. In the **Images** list, the current image can be checked; other open images are visible and marked "Unlock with a license."
- [ ] 14.2 **Add...**, **Edit...**, and **Delete** tell you that custom presets require a license.
- [ ] 14.3 The watermark controls are locked. Export an Instagram Portrait. The file has a small "AstroMD Social Export" credit in the bottom right. The Process Console should stay free of warning 162.
- [ ] 14.4 Switch to **Carousel**, set up a short panorama or a detail, and confirm the preview still works. Click **Export**: you get a message that carousel export requires a license, and no new files are written.
- [ ] 14.5 Click **Enter license key**. Enter a valid email and key. **Unlock** should change the banner to "Licensed to" that email. Other platforms become checkable, watermark controls work, and a carousel export writes files.
- [ ] 14.6 Close and reopen the script. The license is still there.
- [ ] 14.7 **Remove license** returns the free banner and the locks. Your saved crops and Instagram checks should still be there.
- [ ] 14.8 A wrong email, a typo in the key, or a key with one character changed, should be rejected with a clear message.

## 15. Window size, scrolling, and collapsible sections (new in 1.2.2, opening size in 1.2.3, leftover scrollbar in 1.3.1, mouse wheel in 1.5.2, section arrows in 1.5.3)

Start the script in PixInsight on your laptop so the dialog is in the same window you normally use.

- [ ] 15.1 The dialog opens large enough that the right-hand settings are fully visible without scrolling (Processing starts collapsed, Watermark starts open). On a normal screen it should open at least about 1100 by 750 pixels (scaled for your display), and the preview should be at least about 400 pixels tall, not a short strip. **What do you want to do?** and the **Jobs** row sit above the preview and the target list. There should be no leftover vertical slider on the settings column that only moves a few pixels; if the screen has room, that bar should not appear at all. This should still hold if Windows display scaling is 125% or 150%. You can see the preview's **Center**, **Max size**, and **Reset** buttons, and the **Enter license key** / **Open folder** / **Export** / **Close** row. The window should still fit in the PixInsight workspace (it stays inside the screen with a small margin, and it will not exceed about 95% of the screen). Switching between the three export modes should grow the window if it needs to, up to that cap, and should not shrink it back to a tiny window. It should not leave a scrollbar that only moves a few pixels.
- [ ] 15.1b The line under the preview (crop size, or the note that the crop box is not used) sits in its own row under the image. It must not be drawn on top of the preview. Close the script and open it again. If the previous window still fit on this screen, it should come back at that size and position. A size that no longer fits is ignored and the default size is used.
- [ ] 15.2 There is no horizontal scrollbar on that column. If you later make the window shorter than the settings, or expand Processing so the column no longer fits, a vertical scrollbar appears on that column only. The bottom button row and the preview crop buttons stay put.
- [ ] 15.3 **Processing** starts collapsed. Click its bar to open it; the window should grow (up to the screen cap) rather than start scrolling, if there is room. **Watermark / signature** starts open. Click its bar to collapse it; the window should not shrink. The checkbox on that bar still turns the watermark on and off.
- [ ] 15.4 Expand Processing, collapse Watermark, then close and reopen the script. Those open/closed states should come back. The window should still fit and should again avoid scrolling if the screen allows.
- [ ] 15.5 In **Carousel**, switch **Platform** from Instagram to X and back (then TikTok and Facebook if you like). The layout from 13.38 should still hold: the note stays the same height, the slide list does not shrink, and the button rows do not overlap.
- [ ] 15.6 In **Carousel**, add a **2x2 grid** and select it. The preview shows cyan cut lines and the numbers 1, 2, 3, and 4, each at the bottom center of its tile. The 1 and 2 in the top row should be easy to read (not missing or sitting on the cut line). A **3x3 grid** should show 1 through 9 the same way.
- [ ] 15.7 On Windows, make the window short enough that the settings column shows a vertical scrollbar (or expand Processing until it does). Roll the mouse wheel with the pointer over a label (for example Folder or Mode), over a section title (Processing or Watermark / signature), over the section arrow, and over a group box title (Images, Targets, Output, or Carousel). The settings column scrolls. It stops at the top and at the bottom. One notch moves about three lines. Roll the wheel over the Images list, the Targets list, or the carousel slide list: that list scrolls, and the settings column does not take the wheel. Roll the wheel over a dropdown, a number box (including Sharpening, Opacity, and JPEG quality), or a text field: that control keeps the wheel. Roll the wheel over the preview: the crop box still grows and shrinks, and the settings column does not move.
- [ ] 15.8 Set the window to 1100 by 750, then make it larger. On Processing and on Watermark / signature, the expand and collapse arrow sits on the left of the title. The title is to the right of the arrow. The checkbox on Watermark / signature stays beside the title and still turns the watermark on and off. When the vertical scrollbar is showing, it does not cover the arrow, the title, or a control at the right of a row (for example Browse). There is still no horizontal scrollbar. Mouse wheel scrolling from 1.5.2 still works.
- [ ] 15.9 At 1100 by 750, and again after you make the window wider, nothing in the right-hand column is cut off on the right. The Targets headers read Target, Pixels, Max size, and Format, and that list has no horizontal scrollbar. Add, Edit, Delete, All, and None are all visible. Folder's Browse button is visible. The Processing note about dropping to 75 is fully visible and wraps. The JPEG quality box is fully visible. Resampling, Type, and Position show their drop-down arrows. The Sharpening, Opacity, and Size sliders end inside the column. Watermark's Browse button is visible. The Images list above Targets shows the open image, its pixel size, and its base name, with those three headers readable. Repeat the right-edge check in Full frame, fit to file size and in Add logo only, and in Carousel (slide list, Add detail, Move down, Remove). The Jobs row and the license dialog do not clip their buttons. Long notes wrap instead of running off the edge.
- [ ] 15.10 A thin vertical line sits between the preview and the settings column. Rest the pointer on it: the pointer becomes a left-right resize cursor. Drag the line left. The settings column gets wider and the preview gets narrower. While you drag, and after you let go, nothing on the right edge of the settings is clipped (Browse, the JPEG quality box, the drop-down arrows, the sliders, and the Targets headers still fit). Only a vertical scrollbar appears, and only when the column is taller than the window. Drag the line right. The settings column gets narrower but not narrower than it is the first time you open the script, and the preview stays large enough to use (the crop box and its buttons remain usable). Close the script and open it again. The line comes back where you left it. If you then make the window narrower than that split allows, the line moves in just enough that the preview and the settings both still fit. Widen the window again and the split you dragged comes back.

## 16. Images list and batch export (new in 1.3.0)

This is a licensed feature in **Single exports**. Start with at least two open images (for example your finished color image and a starless version), and a license entered.

- [ ] 16.1 The **Images** list is visible in Single exports and hidden when you switch to Carousel. It does not change the Targets list height or shift the action row.
- [ ] 16.2 The current image is checked. Other open images are listed, unchecked, with their pixel size and a base name (file name or window id).
- [ ] 16.3 Remove the license (or start in the free version). Other images stay visible, are not checkable, and show "Unlock with a license." Enter the key again; they become checkable.
- [ ] 16.4 Click a second image in the list. The preview and title switch to that image, and the Output **Base name** field shows that image's name. Drag its crop for Instagram Portrait. Click the first image again. Its crop should be where you left it, not the second image's crop.
- [ ] 16.5 Change the base name for the second image (in the Output field, or in the Base name column if your PixInsight build lets you edit it). The list column and the field should stay in sync for the selected image.
- [ ] 16.6 Check two images and two targets (for example Instagram Portrait and Instagram Story). Click **Export**. You should get four files, named with each image's base name. The Process Console and status line should read like "Image 2 of 2, preset 1 of 2" and then "Image 2 of 2, preset 2 of 2".
- [ ] 16.7 If **Watermark / signature** is on, every file in that batch has the watermark. If **Subfolder per image** is on, each image's files land in a folder named after that image's base name.
- [ ] 16.8 With only the current image checked, Export should still behave like a normal single export (one file per checked target).

## 17. Export modes (new in 1.5.0; full frame and logo only stay licensed)

Start with no license. At the top of the window you should see **What do you want to do?** with three choices. **Social media export** is selected. **Full frame, fit to file size** and **Add logo only** are visible but cannot be selected, and a note says **Requires a license key.** The line under the choices describes social export. The target list and the crop box are showing. **Processing** does not contain the old full frame or logo checkboxes.

- [ ] 17.1 Enter a license key. The note goes away and the other two choices can be selected. The line under the choices changes when you pick one.
- [ ] 17.2 Choose **Full frame, fit to file size**. **Target (MB)**, **Priority**, and **JPEG quality** appear on the next line. The target list, the crop buttons, and the crop box are hidden. The line under the preview says the crop box is not used. The Example line uses Full-Frame. **Processing** is still there for resampling and sharpening. Its JPEG quality row is hidden, because quality is next to the target.
- [ ] 17.3 Set **Target (MB)** to 10, **JPEG quality** to 95, and **Priority** to **Highest quality** (the default). Export with one image checked. The Process Console says full frame fit (Highest quality), quality 95, target 10 MB. If the full image is under 10 MB, the line says Kept and the file matches the original pixel size. If it is over, the line says Resized, with the original size, the new size, quality 95, and the file size (for example "Resized 6000 x 4000 to 4620 x 3080 at quality 95, 9.8 MB"). Quality stays at 95. The file is at or under 10 MB. It is the whole frame, not a crop. Your original image is unchanged.
- [ ] 17.4 Set **Priority** to **Largest size** and export the same image again. If the original pixel size fits at some quality from 75 to 95, the file keeps that pixel size and the console says Kept, with that quality and the file size. If quality 75 is still over, the console says so and names the smaller size at quality 75. The file is at or under 10 MB.
- [ ] 17.5 Choose **Add logo only**. The target list and crop controls stay hidden. **Processing** (including sharpening) is hidden. **Watermark / signature** is open. You see **Original size** and **Fit to file size**, plus **Format**, **Target (MB)**, **Priority**, and **JPEG quality**. Priority is disabled until Fit to file size is selected. Try to export with **Watermark / signature** off. You get a message that logo only needs a watermark, and no file is written.
- [ ] 17.6 Turn the watermark on, choose **Logo image**, and pick a transparent PNG. Set the position, size, and opacity. Leave **Original size** selected and set **Format** to JPEG (the default is Same as source). Set **Target (MB)** to 10. Export. The file name uses Logo, not a platform preset. The file is the whole image plus the logo: no crop, no sharpening. The console says Logo only. The original pixel size is kept if some quality from 75 to 95 fits the target. If quality 75 is still over, the console says the image was resized at quality 75. sRGB is still applied.
- [ ] 17.7 Repeat 17.6 with **Format** set to PNG. The file is PNG at the original pixel size (PNG is not resized to chase the target), with the logo only. JPEG quality does not apply.
- [ ] 17.8 Stay in **Add logo only** and choose **Fit to file size**. Format shows JPEG and cannot be changed. Set **Target (MB)** to 10 and try both Priority settings. One JPEG per checked image, whole frame, logo applied, at or under 10 MB. The console says full frame fit and that the logo is applied, then the image is fit. Highest quality stays at quality 95 and may shrink. Largest size keeps the pixels when it can, and otherwise says quality 75 was still over.
- [ ] 17.11 Choose **Original size** again and set **Format** to **Same as source**. Open a saved 16-bit TIFF (or use the 4063 x 6125 16-bit TIFF). Turn the watermark on. Export. The new file is named like `YourName_logo.tif`, next to the output folder you picked, not on top of the original. The original file is unchanged even if **Overwrite existing files** is checked. The new TIFF is still 16-bit, the same pixel size, and still has its ICC profile if the original had one. The console does not say it converted to sRGB or to 8-bit. The logo is on the image.
- [ ] 17.12 Repeat 17.11 with a 32-bit floating point XISF if you have one. The file should be `Name_logo.xisf`, still floating point, same pixel size, with FITS keywords still present. A PNG source should come back as PNG. A JPEG source should come back as JPEG at the JPEG quality shown (95 unless you changed it).
- [ ] 17.13 Create a new image that has never been saved (**Image > New**), or duplicate the view so it has no file path. **Same as source** should tell you it will write 16-bit TIFF. The file is a 16-bit TIFF with `_logo` in the name. Choose JPEG in **Format** and export again: you get a JPEG instead, with no extra question.
- [ ] 17.14 Go back to **Fit to file size**. Format shows JPEG again. Export still writes a JPEG under the size target.
- [ ] 17.9 Choose **Social media export** again. The target list, crop box, and crop buttons come back. Close the script and open it again. It should open on the mode you last used (social, if that is what you left selected).
- [ ] 17.10 Remove the license. Full frame and Add logo only are disabled again, with **Requires a license key.** Social media export is selected. Export an Instagram Portrait. The file is still the cropped Instagram size with the small "AstroMD Social Export" credit. Full frame and logo only are not applied. Enter the key again and the other two choices work. If you had last used full frame or logo only while licensed, that mode comes back when the key is entered.

## 18. Saved jobs (new in 1.5.0, license required)

Saved jobs use the same kind of PixInsight setting as custom presets, so they require a license. There is no import or export to a separate JSON file.

Start with no license. The **Jobs** row is under **What do you want to do?** The list says "(No saved jobs)" until you save one. **Save as...** and the other buttons do not run.

- [ ] 18.1 Click **Save as...** with no license. You get a message that saved jobs require a license, and nothing is stored.
- [ ] 18.2 Enter a license key. Set up a social export you would actually reuse (for example Instagram Portrait checked, your logo on, a folder, and a file name template). Click **Save as...** and name it `Instagram + logo`. It appears in the Jobs list.
- [ ] 18.3 Change the mode to **Add logo only**, set **Fit to file size** and **Target (MB)** to 10, and save that as `Logo only, 10 MB`.
- [ ] 18.4 Pick `Instagram + logo` and click **Load**. The window returns to social export with the targets, logo, folder, template, and quality you saved.
- [ ] 18.5 Change one setting (for example the logo opacity), select that job, and click **Update**. Confirm. Load it again and confirm the new opacity stuck and the name did not change.
- [ ] 18.6 Click **Rename** and change `Logo only, 10 MB` to another name. The list shows the new name. Try to save a second job with that same name. You are told it already exists.
- [ ] 18.7 Click **Delete** and confirm. The job leaves the list.
- [ ] 18.8 Close the script and open it again. The jobs you did not delete are still in the list, and the last mode is still selected.
- [ ] 18.9 Remove the license. The job buttons stop working. Your saved jobs are still stored. Enter the key again and **Load** still works.
